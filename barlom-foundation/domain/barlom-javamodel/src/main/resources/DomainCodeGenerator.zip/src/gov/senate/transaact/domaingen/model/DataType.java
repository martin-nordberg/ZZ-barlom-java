
package gov.senate.transaact.domaingen.model;

/** A primitive data type (String, integer, date, etc.). */
public abstract class DataType
  extends ModelElement {

  DataType( String name, String sqlName, boolean isBlobType, boolean isDateType ) {
    this.setName( name );
    this.setSqlName( sqlName );
    this.isBlobType = isBlobType;
    this.isDateType = isDateType;
  }

  /** Returns the isBlobType. */
  public boolean getIsBlobType() {
    return this.isBlobType;
  }

  /** Returns the isDateType. */
  public boolean getIsDateType() {
    return this.isDateType;
  }

  @Override
  public ModelElement getParent() {
    return null;
  }

  /** Validates this data type. */
  @Override
  public void validate() {
    assert this.getName() != null && !this.getName().isEmpty() : "Data type has no name.";
  }

  /** Converts a given value of this type to Java. */
  public abstract String valueForJava( Object value );

  /** Converts a given value of this type to SQL. */
  public abstract String valueForSql( Object value );

  /** Java type byte[]; SQL type BLOB. */
  public static DataType blobDataType = new BlobDataType();

  /** Java type Boolean. */
  public static DataType booleanDataType = new BooleanDataType();

  /** Java type Date; SQL type DATE. */
  public static DataType dateDataType = new DateDataType();

  /** Java type Integer; SQL type INTEGER. */
  public static DataType integerDataType = new IntegerDataType();

  /** Java type Long; SQL type INTEGER. */
  public static DataType longDataType = new LongDataType();

  /** TranSAAct type Money; SQL type NUMBER(10,2). */
  public static DataType moneyDataType = new MoneyDataType();

  /** Java type String; SQL type VARCHAR2(maxLength). */
  public static DataType stringDataType = new StringDataType();

  /** Java type Date; SQL type TIMESTAMP. */
  public static DataType timeStampDataType = new TimeStampDataType();

  /** Java type String; SQL type NVARCHAR2(maxLength). */
  public static DataType unicodeStringDataType = new UnicodeStringDataType();

  /** Whether this is a SQL BLOB type, needing special treatment in O/RM code. */
  private boolean isBlobType = false;

  /** Whether this is a Java Date type, needing special treatment in O/RM code. */
  private boolean isDateType = false;
}
