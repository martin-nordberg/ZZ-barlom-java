
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaField
  extends JavaMember {

  /**
   * Constructs a new field.
   * @param parent
   * @param name
   * @param description
   */
  JavaField(
      JavaConcreteComponent parent,
      String name,
      String description,
      EJavaAccessibility accessibility,
      Boolean isStatic,
      Boolean isFinal,
      JavaType type,
      String initialValueCode ) {
    super( parent, name, description, accessibility, isStatic, isFinal, type );

    this.initialValueCode = initialValueCode;

    parent.onAddChild( this );
  }

  /** Returns the initialValueCode. */
  public String getInitialValueCode() {
    return this.initialValueCode;
  }

  /** {@inheritDoc} */
  @Override
  public JavaConcreteComponent getParent() {
    return (JavaConcreteComponent) super.getParent();
  }

  private String initialValueCode;

}
