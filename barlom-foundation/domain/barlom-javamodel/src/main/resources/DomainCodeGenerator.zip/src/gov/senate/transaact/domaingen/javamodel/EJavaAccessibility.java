
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
@SuppressWarnings( "javadoc" )
public enum EJavaAccessibility {

  PUBLIC("public"),

  PROTECTED("protected"),

  DEFAULT("/*default*/"),

  PRIVATE("private");

  EJavaAccessibility( String keyWord ) {
    this.keyWord = keyWord;
  }

  public String getKeyWord() {
    return this.keyWord;
  }

  private String keyWord;

}
