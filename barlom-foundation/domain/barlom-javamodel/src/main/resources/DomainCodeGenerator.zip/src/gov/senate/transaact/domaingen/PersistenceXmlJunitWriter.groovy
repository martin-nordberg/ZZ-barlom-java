
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Writes a persistence.xml file suitable for unit testing. **/
class PersistenceXmlJunitWriter
extends PersistenceXmlWriter {

  /** Writes the opening portion of the XML with the persistence unit name. */
  protected void writeFileHeader( String jpaPersistenceUnit ) {
    sameLine() << '<?xml version="1.0" encoding="UTF-8" ?>';
    nextLine() << '<persistence xmlns="http://java.sun.com/xml/ns/persistence"';
    nextLine() << '             xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"';
    nextLine() << '             xsi:schemaLocation="http://java.sun.com/xml/ns/persistence http://java.sun.com/xml/ns/persistence/persistence_1_0.xsd"';
    nextLine() << '             version="1.0">';
    indent++;
    nextLine() << '<!-- NOTE: This file has been generated automatically; do not hand edit. -->';
    nextLine() << '<persistence-unit name="' << jpaPersistenceUnit << '" transaction-type="RESOURCE_LOCAL">';
    indent++;
    nextLine() << '<provider>';
    nextLine() << indent() << 'org.eclipse.persistence.jpa.PersistenceProvider';
    nextLine() << '</provider>';
    nextLine() << '<non-jta-data-source>jdbc/TranSAActDS</non-jta-data-source>';
  }

  /** Writes the closing properties portion of the XML. */
  protected void writeFileFooter( List<Domain> domains ) {
    nextLine();
    nextLine() << '<properties>';
    ++indent;
    nextLine() << '<property name="eclipselink.target-database" value="Oracle"/>';
    nextLine() << '<property name="eclipselink.cache.shared.default" value="false"/>';
    --indent;
    nextLine() << '</properties>';
    nextLine();
    --indent;
    nextLine() << '</persistence-unit>';
    --indent;
    nextLine() << '</persistence>';
  }
}
