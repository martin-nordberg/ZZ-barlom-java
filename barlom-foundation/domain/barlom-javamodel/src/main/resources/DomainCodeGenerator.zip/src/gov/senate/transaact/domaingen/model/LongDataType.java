
package gov.senate.transaact.domaingen.model;

/** Concrete date type for long integers. */
public class LongDataType
  extends DataType {

  public LongDataType() {
    super( "Long", "INTEGER", false, false );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    return value.toString() + "L";
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    return value.toString();
  }
}
