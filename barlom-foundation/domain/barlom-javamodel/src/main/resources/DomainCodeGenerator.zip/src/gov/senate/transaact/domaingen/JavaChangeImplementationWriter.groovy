
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

class JavaChangeImplementationWriter
extends JavaEntitiesWriter {

  protected String getClassName( Entity entity ) {
    return entity.javaName.changeImplementationClass;
  }

  /** Determines whether a given entity needs to be written. */
  protected boolean isWriteable( Entity entity ) {
    return entity.isTemporal();
  }

  private void writeAttribute( Attribute attribute ) {
    writeAttributeImplementation( attribute.description, attribute.dataType, attribute.javaName, attribute.sqlName );
  }

  private void writeAttribute( TemporalAttribute attribute ) {
    writeAttributeImplementation( attribute.description + " (after change)", attribute.dataType, new JavaName( 'New ' + attribute.name ), new SqlName( 'NEW ' + attribute.sqlName.column ) );
    writeAttributeImplementation( attribute.description + " (before change)", attribute.dataType, new JavaName( 'Old ' + attribute.name ), new SqlName( 'OLD ' + attribute.sqlName.column ) );

    nextLine() << '/** @return whether the value of ' << attribute.description << ' was changed. */';
    nextLine() << 'public boolean ' << new JavaName( "Was " + attribute.name + " Changed" ).field << '() {';
    nextLine() << indent() << 'return areDifferent( this.' << new JavaName( 'Old ' + attribute.name ).field << ', this.' << new JavaName( 'New ' + attribute.name ).field << ' );';
    nextLine() << '}';
    nextLine();
  }

  private void writeChangeMethods( Entity entity ) {
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public void ' << JavaName.ABANDON_UNPERSISTED_CHANGES << '() {';
    nextLine() << '}';
    nextLine();

    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public boolean ' << JavaName.NEEDS_PERSISTING << '() {';
    nextLine() << indent() << 'return false;';
    nextLine() << '}';
    nextLine();

    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public void ' << JavaName.STAGE_UNPERSISTED_CHANGES << '() {';
    nextLine() << '}';
    nextLine();
  }

  private void writeRelationship( Relationship relationship ) {
    if ( relationship.relatedEntity.enumerated ) {
      writeRelationshipToEnum( relationship );
      return;
    }

    writeRelationshipImplementation( relationship.description, relationship.required, false, relationship.javaName, relationship.parent.javaName, relationship.relatedEntity.javaName, relationship.sqlName );
  }

  private void writeRelationship( TemporalRelationship relationship ) {
    writeRelationshipImplementation( relationship.description + ' (after change)', relationship.required, false, new JavaName( 'New ' + relationship.name ), relationship.parent.javaName, relationship.relatedEntity.javaName, new SqlName( 'NEW ' + relationship.sqlName.column ) );
    writeRelationshipImplementation( relationship.description + ' (before change)', relationship.required, false, new JavaName( 'Old ' + relationship.name ), relationship.parent.javaName, relationship.relatedEntity.javaName, new SqlName( 'OLD ' + relationship.sqlName.column ) );

    nextLine() << '/** @return whether the value of ' << relationship.description << ' has changed. */';
    nextLine() << 'public boolean ' << new JavaName( "Was " + relationship.name + " Changed" ).field << '() {';
    nextLine() << indent() << 'return areDifferent( this.' << new JavaName( 'Old ' + relationship.name ).field << ', this.' << new JavaName( 'New ' + relationship.name ).field << ' );';
    nextLine() << '}';
    nextLine();
  }

  private void writeRelationshipToEnum( Relationship relationship ) {
    nextLine() << '/** ' << relationship.description << '. */';
    nextLine() << '@Column( name = "' << relationship.sqlName.column << '" )';
    nextLine() << 'private Long ' << relationship.javaName.field << 'Id;';
    nextLine();
    nextLine() << '/** @return the value of ' << relationship.description << '. */';
    nextLine() << 'public ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.getter << '() {';
    nextLine() << indent() << 'return ' << relationship.relatedEntity.javaName.implementationClass << '.getByUniqueId( this.' << relationship.javaName.field << 'Id );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << relationship.description << '.';
    nextLine() << ' * @param ' << relationship.javaName.setterParameter << ' The new value for ' << relationship.javaName.asDescription << '.';
    nextLine() << ' */';
    nextLine() << 'public void ' << relationship.javaName.setter << '( ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.setterParameter << ' ) {';
    ++indent;
    nextLine() << 'Long ' << relationship.javaName.setterParameter << 'Id = null;';
    nextLine() << 'if ( ' << relationship.javaName.setterParameter << ' != null ) {';
    nextLine() << indent() << relationship.javaName.setterParameter << 'Id = ' << relationship.javaName.setterParameter <<'.getUniqueId();';
    nextLine() << '}';
    nextLine() << 'this.' << relationship.javaName.field << 'Id = ' << relationship.javaName.setterParameter << 'Id;';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  protected void writeEntity( Entity entity ) {
    assert false;
  }

  protected void writeEntity( TemporalEntity entity ) {
    nextLine() << 'package ' << entity.parent.javaName.changeImplementationPackage << ';';
    nextLine();

    getImportedPackages( entity ).each {
      nextLine() << 'import ' << it << ';';
    }

    nextLine();
    nextLine() << '/**';
    nextLine() << ' * ' << entity.description;
    nextLine() << ' * @author Vangent, Inc. (NOTE: SCRIPT-GENERATED CODE; DO NOT HAND EDIT)';
    nextLine() << ' */';
    nextLine() << '@Entity';
    nextLine() << '@Table( name = "' << entity.sqlName.changesView << '" )';
    nextLine() << 'public ';
    if ( entity.isAbztract() ) {
      sameLine() << 'abstract ';
    }
    else {
      sameLine() << 'final ';
    }
    sameLine() << 'class ' << getClassName( entity );
    ++indent;
    writeExtends( entity );
    sameLine() << ' {';
    nextLine();

    // serialization version
    nextLine() << '/** Serialization version number. */';
    nextLine() << 'private static final long serialVersionUID = 1L;';
    nextLine();

    // the unique ID for the entity
    nextLine() << '/** The unique ID of this ' << entity.javaName.asDescription << '. */';
    nextLine() << '@Id';
    nextLine() << '@Column( name = "' << entity.sqlName.changesUniqueId << '" )';
    nextLine() << 'private Long uniqueId;';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public Long getUniqueId() {';
    nextLine() << indent() << 'return this.uniqueId;';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public void setUniqueId( Long uniqueId ) {';
    nextLine() << indent() << 'this.uniqueId = uniqueId;';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** The type of change: CREATE/UPDATE/DELETE. */';
    nextLine() << '@Column( name = "CHANGE_TYPE" )';
    nextLine() << 'private String changeType;';
    nextLine();
    nextLine() << '/** @return whether this change was a creation of the entity. */';
    nextLine() << 'public boolean wasCreation() {';
    nextLine() << '  return "CREATE".equals( this.changeType );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** @return whether this change was a deletion of the entity. */';
    nextLine() << 'public boolean wasDeletion() {';
    nextLine() << '  return "DELETE".equals( this.changeType );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public List<String> getValidationMessages() {';
    nextLine() << indent() << 'throw new UnsupportedOperationException();';
    nextLine() << '}';
    nextLine();

    String javaIdName = entity.javaName.uniqueId;
    String sqlIdName = entity.sqlName.uniqueId;
    if ( entity.baseClass != null ) {
      javaIdName = entity.baseClass.javaName.uniqueId;
      sqlIdName = entity.baseClass.sqlName.uniqueId;
    }
    String javaIdMethodName = javaIdName[0].toUpperCase() + javaIdName.substring(1);

    nextLine() << '/** The entity ID of this ' << entity.javaName.asDescription << '. */';
    nextLine() << '@Column( name = "' << sqlIdName << '" )';
    nextLine() << 'private Long ' << javaIdName << ';';
    nextLine();
    nextLine() << '/** @return the changed entity\'s unique ID */';
    nextLine() << 'public Long get' << javaIdMethodName << '() {';
    nextLine() << indent() << 'return this.' << javaIdName << ';';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << " * Sets the changed entity's unique ID.";
    nextLine() << ' * @param ' << javaIdName << ' the unique ID value.';
    nextLine() << ' */';
    nextLine() << 'public void set' << javaIdMethodName << '( Long ' << javaIdName << ' ) {';
    nextLine() << indent() << 'this.' << javaIdName << ' = ' << javaIdName<< ';';
    nextLine() << '}';
    nextLine();

    nextLine() << '/** The user action that affected this ' << entity.javaName.asDescription << '. */';
    nextLine() << '@ManyToOne( optional = false )';
    nextLine() << '@JoinColumn( name = "USER_ACTION_ID" )';
    nextLine() << 'private UserAction userAction;';
    nextLine();
    nextLine() << '/** @return the user action associated with this change. */';
    nextLine() << 'public UserAction getUserAction() {';
    nextLine() << indent() << 'return this.userAction;';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Sets the user action associated with this change.';
    nextLine() << ' * @param action The new user action.';
    nextLine() << ' */';
    nextLine() << 'public void setUserAction( UserAction action ) {';
    nextLine() << indent() << 'this.userAction = action;';
    nextLine() << '}';
    nextLine();

    entity.relationships.each { writeRelationship( it ); }

    entity.attributes.each { writeAttribute( it ); }

    writeChangeMethods( entity );

    --indent;
    nextLine() << '}';
    nextLine();
  }

  private List<String> getImportedPackages( Entity entity ) {

    Set result = new HashSet();

    result.add( 'java.util.List' );

    result.add( 'javax.persistence.Entity' );
    result.add( 'javax.persistence.JoinColumn' );
    result.add( 'javax.persistence.ManyToOne' );
    result.add( 'javax.persistence.Table' );
    result.add( 'gov.senate.transaact.common.organization.domainmodel.UserAction' );

    result.add( entity.javaName.changeImplementationClassFullyQualified );

    if ( entity.baseClass != null ) {
      if ( entity.parent != entity.baseClass.parent ) {
        result.add( entity.baseClass.javaName.changeImplementationClassFullyQualified );
      }
    }

    result.add( 'javax.persistence.Id' );
    result.add( 'gov.senate.transaact.jpa.datamodel.JpaDomainModelEntity' );

    if ( entity.attributes || entity.baseClass == null ) {
      result.add( 'javax.persistence.Column' );
    }

    // java.util.Date, if needed
    entity.attributes.each {
      if ( it.dataType.isDateType ) {
        result.add( 'java.util.Date' );
        result.add( 'javax.persistence.Temporal' );
        result.add( 'javax.persistence.TemporalType' );
      }
    }

    entity.relationships.each {
      result.add( it.relatedEntity.javaName.implementationClassFullyQualified );
    }

    return result.sort();
  }

  private void writeExtends( Entity entity ) {
    nextLine() << 'extends JpaDomainModelEntity';
  }

}