
package gov.senate.transaact.domaingen.dbgen;

import gov.senate.transaact.domaingen.dbmodel.DbAttributeColumn
import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbForeignKeyColumn
import gov.senate.transaact.domaingen.dbmodel.DbRecord
import gov.senate.transaact.domaingen.dbmodel.DbTable
import gov.senate.transaact.domaingen.dbmodel.EDbDataType
import gov.senate.transaact.domaingen.model.*

/**
 * Writer generates code to define TranSAAct pre-defined database records.
 * @author GDIT, Inc.
 */
public class DbRecordsDmlWriter
extends DbWriter {

  /** Whether this writer instance will write unit test values (vs. reference values). */
  boolean writeUnitTestValues;

  /** Writes the reference table INSERT statements to the writer's output. */
  void writeDomain( DbDomain domain ) {

    String title = (writeUnitTestValues ? 'TEST' : 'REFERENCE') + ' VALUES FOR ' + domain.sqlName;

    String purpose = 'Creates reference table records for the ' + domain.sqlName + ' schema.';
    if ( writeUnitTestValues ) {
      purpose = 'Creates unit test records for the ' + domain.sqlName + ' schema.';
    }

    writeFileHeader( title, purpose, true );

    nextLine() << '------------------------------';
    nextLine() << '-- Predefined Record Values --';
    nextLine() << '------------------------------';
    nextLine();

    boolean userActionCreated = false;
    domain.tables.each { table ->
      if ( table.historyTable != null && !userActionCreated && hasRelevantInstances( table ) ) {
        this.createUserAction();
        userActionCreated = true;
      }

      createReferenceValues( table );
    }
    nextLine();

    writeFileFooter();
  }

  /** Writes the instance record values for one entity. */
  private void createReferenceValues( DbTable table ) {

    // find relevant instances (unit test or full)
    List<DbRecord> records = relevantInstances( table );

    if ( !records ) {
      return;
    }

    String tableName = table.sqlName;
    String uniqueIdField = table.primaryKeyColumn.sqlName;

    nextLine() << '-- ' << tableName;

    nextLine() << 'MERGE INTO';
    nextLine() << indent() << tableName;
    nextLine() << 'USING (';
    ++indent;

    boolean first = true;

    // for each instance ...
    records.each { record ->
      String uniqueIdValue = record.getColumnValue( 'UNIQUEID' );

      assert uniqueIdValue : "Reference value in entity '" + table.name + "' must have a specified unique ID.\r\n" + record.getColumnValue( 'UNIQUEID' );

      if ( first ) {
        first = false;
      }
      else {
        nextLine() << 'UNION ALL';
      }

      nextLine() << 'SELECT ' << uniqueIdValue << ' AS ' << uniqueIdField;

      indent +=3;

      if ( table.discriminatorColumn != null ) {
        sameLine() << ',';
        nextLine() << "'" << record.getColumnValue( 'discriminator' ) << "' AS DISCRIMINATOR";
      }
      table.attributeColumns.each { attributeColumn ->
        if ( !isTemporal( attributeColumn ) ) {
          sameLine() << ','
          def value = record.getColumnValue( attributeColumn.attributeName );
          if ( value == null ) {
            if ( attributeColumn.defaultValue == null ) {
              nextLine() << 'NULL';
            }
            else {
              nextLine() << makeInsertValue( attributeColumn, attributeColumn.defaultValue );
            }
          }
          else {
            nextLine() << makeInsertValue( attributeColumn, value );
          }
          sameLine() << ' AS ' << attributeColumn.sqlName;
        }
      }
      table.foreignKeyColumns.each { foreignKeyColumn ->
        if ( !isTemporal( foreignKeyColumn ) ) {
          def relatedRecordId = findRelatedRecordId( record, foreignKeyColumn )
          if ( relatedRecordId == null ) {
            sameLine() << ','
            nextLine() << 'NULL AS ' << foreignKeyColumn.sqlName;
          }
          else {
            sameLine() << ','
            nextLine() << relatedRecordId << ' AS ' << foreignKeyColumn.sqlName;
          }
        }
      }

      indent -=3;

      nextLine() << 'FROM DUAL'

    }

    nextLine() << ') NEW_VALUE';

    --indent;

    nextLine() << 'ON'
    nextLine() << indent() << '( ' << tableName << '.' << uniqueIdField << ' = NEW_VALUE.' << uniqueIdField << ' )';
    if ( table.discriminatorColumn != null || !table.attributeColumns.isEmpty() || !table.foreignKeyColumns.isEmpty() || table.historyTable != null ) {
      nextLine() << 'WHEN MATCHED THEN';
      nextLine() << indent() << 'UPDATE SET ';
      indent += 6;
      String delimiter = '';
      if ( table.discriminatorColumn != null ) {
        delimiter = ',';
        sameLine() << tableName << '.DISCRIMINATOR = NEW_VALUE.DISCRIMINATOR';
      }
      table.attributeColumns.each { attributeColumn ->
        if ( !isTemporal( attributeColumn ) ) {
          sameLine() << delimiter;
          delimiter = ',';
          nextLine() << tableName << '.' << attributeColumn.sqlName << ' = NEW_VALUE.' << attributeColumn.sqlName;
        }
      }
      table.foreignKeyColumns.each { foreignKeyColumn ->
        if ( !isTemporal( foreignKeyColumn ) ) {
          sameLine() << delimiter;
          delimiter = ',';
          nextLine() << tableName << '.' << foreignKeyColumn.sqlName << ' = NEW_VALUE.' << foreignKeyColumn.sqlName;
        }
      }
      if ( table.historyTable != null ) {
        sameLine() << ',';
        nextLine() << tableName << '.LATEST_ACTION_ID = SEQ_USER_ACTION.CURRVAL'
        sameLine() << ',';
        nextLine() << tableName << '.UPDATE_DATE = SYSDATE';
      }
      indent -= 6;
    }
    nextLine() << 'WHEN NOT MATCHED THEN';
    ++indent;
    nextLine() << 'INSERT ( ';
    sameLine() << uniqueIdField;
    if ( table.discriminatorColumn != null ) {
      sameLine() << ', DISCRIMINATOR';
    }
    table.attributeColumns.each { attributeColumn ->
      if ( !isTemporal( attributeColumn ) ) {
        sameLine() << ', ' << attributeColumn.sqlName;
      }
    }
    table.foreignKeyColumns.each { foreignKeyColumn ->
      if ( !isTemporal( foreignKeyColumn ) ) {
        sameLine() << ', ' << foreignKeyColumn.sqlName;
      }
    }
    if ( table.historyTable != null ) {
      sameLine() << ', LATEST_ACTION_ID, UPDATE_DATE';
    }
    sameLine() << ' )';
    nextLine() << 'VALUES ( '
    sameLine() << 'NEW_VALUE.' << uniqueIdField;
    if ( table.discriminatorColumn != null ) {
      sameLine() << ', NEW_VALUE.DISCRIMINATOR';
    }
    table.attributeColumns.each { attributeColumn ->
      if ( !isTemporal( attributeColumn ) ) {
        sameLine() << ', NEW_VALUE.' << attributeColumn.sqlName;
      }
    }
    table.foreignKeyColumns.each { foreignKeyColumn ->
      if ( !isTemporal( foreignKeyColumn ) ) {
        sameLine() << ', NEW_VALUE.' << foreignKeyColumn.sqlName;
      }
    }
    if ( table.historyTable != null ) {
      sameLine() << ', SEQ_USER_ACTION.CURRVAL, SYSDATE';
    }
    sameLine() << ' );';
    --indent;
    nextLine();
    nextLine();
  }

  /** Inserts a user action for changes to temporal instances. */
  private void createUserAction() {
    nextLine() << '-- User action to represent the reference data loading (user 1 is "SYSTEM") --';
    nextLine() << 'INSERT INTO USER_ACTION';
    nextLine() << '          ( USER_ACTION_ID, DESCRIPTION, EFFECTIVE_DATE_AND_TIME, USER_ID )';
    nextLine() << "   VALUES ( SEQ_USER_ACTION.NEXTVAL, 'Reference table data loading.', SYSDATE, 1 );";
    nextLine();
  }

  /** Constructs a test value for the given attribute. */
  private String makeInsertValue( DbAttributeColumn attributeColumn, Object value ) {

    if ( attributeColumn.type == EDbDataType.VARCHAR2 ) {
      return "'" + this.escaped( value ) + "'";
    }
    else if ( attributeColumn.type == EDbDataType.NVARCHAR2 ) {
      return "'" + this.escaped( value ) + "'";
    }
    else if ( attributeColumn.type == EDbDataType.DATE ) {
      java.text.DateFormat dateFormat = new java.text.SimpleDateFormat( 'MM-dd-yyyy' );
      assert value instanceof Date;
      return "TO_DATE('" << dateFormat.format( value ) << "','MM-DD-YYYY')";
    }
    else if ( attributeColumn.type == EDbDataType.TIMESTAMP ) {
      java.text.DateFormat dateFormat = new java.text.SimpleDateFormat( 'MM-dd-yyyy HH:mm:ss' );
      assert value instanceof Date;
      return "TO_DATE('" << dateFormat.format( value ) << "','MM-DD-YYYY HH24:MI:SS')";
    }
    else if ( attributeColumn.type == EDbDataType.INTEGER ) {
      return value;
    }
    else if ( attributeColumn.type == EDbDataType.BOOLEAN ) {
      if ( value ) {
        return "1";
      }
      else {
        return "0";
      }
    }
    else {
      assert false : attributeColumn.type.name + " " + attributeColumn.name;
    }
  }

  /** Finds the unique ID for a related instance. */
  private String findRelatedRecordId( DbRecord record, DbForeignKeyColumn foreignKeyColumn ) {

    String relatedInstanceName1 = record.getColumnValue( foreignKeyColumn.relationshipName );
    DbRecord relatedRecord = foreignKeyColumn.relatedTable.records.find { rec ->
      rec.getColumnValue( rec.getColumnValue("nameAttributeName") ).toString() == relatedInstanceName1;
    }

    String relatedInstanceName2 = "";
    if ( relatedRecord == null ) {
      relatedInstanceName2 = record.getColumnValue( foreignKeyColumn.relatedTable.name );
      relatedRecord = foreignKeyColumn.relatedTable.records.find { rec ->
        rec.getColumnValue( rec.getColumnValue("nameAttributeName") ).toString() == relatedInstanceName2;
      }
    }


    if ( relatedRecord == null ) {
      if ( !foreignKeyColumn.isNullable && "Latest Action Id" != foreignKeyColumn.name ) {
        System.out.println( "Table: " + foreignKeyColumn.parent.name );
        System.out.println( "Foreign Key Name: " + foreignKeyColumn.name );
        System.out.println( "Related Table: " + foreignKeyColumn.relatedTable.name );
        System.out.println( "Record: " + record.toString() );
        System.out.println( "Potential Related Records:" );
        foreignKeyColumn.relatedTable.records.each { rec ->
          System.out.println( rec.toString() );
        }
        assert false : "Could not find related record for required foreign key above";
      }
      return null;
    }

    return relatedRecord.getColumnValue( 'UniqueId' );
  }

  private boolean isTemporal( DbAttributeColumn attributeColumn ) {
    return "IS_DELETED" == attributeColumn.sqlName || "UPDATE_DATE" == attributeColumn.sqlName;
  }

  private boolean isTemporal( DbForeignKeyColumn foreignKeyColumn ) {
    return "LATEST_ACTION_ID" == foreignKeyColumn.sqlName;
  }

  /** Determines whether a table has records of relevance for this writer. */
  private boolean hasRelevantInstances( DbTable table ) {
    boolean result = false;
    table.records.each { record ->
      if ( record.isUnitTestValue.equals( this.writeUnitTestValues ) ) {
        result = true;
      }
    };
    return result;
  }

  /** Filters an entity's instances to those of relevance for this writer. */
  private List<DbRecord> relevantInstances( DbTable table ) {
    def result = table.records.findAll { record -> record.isUnitTestValue == writeUnitTestValues };
    return new ArrayList<DbRecord>( result );
  }

}
