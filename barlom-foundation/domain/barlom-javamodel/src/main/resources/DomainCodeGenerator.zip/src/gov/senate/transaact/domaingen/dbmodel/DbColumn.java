
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public abstract class DbColumn
  extends DbNamedModelElement {

  /**
   * Constructs a new database column.
   */
  DbColumn( DbRelation parent, String name, String description ) {
    super( parent, name, description );
  }

  /** {@inheritDoc} */
  @Override
  public DbRelation getParent() {
    return (DbRelation) super.getParent();
  }

}
