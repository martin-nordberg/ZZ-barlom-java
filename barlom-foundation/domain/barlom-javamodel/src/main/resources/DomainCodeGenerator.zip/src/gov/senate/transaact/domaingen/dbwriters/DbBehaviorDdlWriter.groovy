
package gov.senate.transaact.domaingen.dbwriters

import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbSequence
import gov.senate.transaact.domaingen.dbmodel.DbTable
import gov.senate.transaact.domaingen.dbmodel.DbTrigger
import gov.senate.transaact.domaingen.dbmodel.EDbTriggerType
import gov.senate.transaact.domaingen.model.*

/**
 * Writer for SQL sequences, views, indexes, triggers, etc.
 * @author Vangent, Inc.
 */
public class DbBehaviorDdlWriter
extends DbWriter {

  /** Writes a schema definition to the writer's output. */
  void writeDomain( DbDomain domain ) {

    String title = 'SCHEMA DEFINITION FOR ' + domain.sqlName;
    String purpose = 'Defines the ' + domain.sqlName + ' schema.'

    writeFileHeader( title, purpose, true );

    nextLine() << '----------------------';
    nextLine() << '-- Create Sequences --';
    nextLine() << '----------------------';
    nextLine();

    domain.tables.each { table ->
      this.createSequence( table.sequence );
    }
    nextLine();

    nextLine() << '--------------------';
    nextLine() << '-- Create Indexes --';
    nextLine() << '--------------------';
    nextLine();

    domain.tables.each { table ->
      createIndexes( table );
    }
    nextLine();

    // TBD: views and triggers still TBD for db model & generation code

    nextLine() << '------------------';
    nextLine() << '-- Create Views --';
    nextLine() << '------------------';
    nextLine();

    domain.modelDomain.entities.each { createViews( it ); }
    nextLine();

    nextLine() << '---------------------';
    nextLine() << '-- Create Triggers --';
    nextLine() << '---------------------';
    nextLine();

    domain.tables.each { table ->
      table.triggers.each{ trigger ->
        createTrigger( trigger );
      }
    }
    nextLine();

    if ( domain.hasSqlCustomizations ) {
      nextLine() << '----------------------------';
      nextLine() << '-- Include Customizations --';
      nextLine() << '----------------------------';
      nextLine();
      nextLine() << '@@ ' << domain.name.replaceAll(" ","") << 'Customizations.sql';
      nextLine();
    }

    writeFileFooter();
  }

  private void createIndexes( DbTable table ) {
    table.indexes.each { index ->
      nextLine() << 'CREATE INDEX ' << index.sqlName << ' ON ' << index.parent.sqlName << '(' << index.column.sqlName << ');';
    }
  }

  private void createSequence( DbSequence sequence ) {
    nextLine() << 'CREATE SEQUENCE ' << sequence.sqlName << ' START WITH 10000;';
    nextLine();
  }

  private void createViews( Entity entity ) {
  }

  private void createViews( TemporalEntity entity ) {

    String keyName = getUniqueId(entity);
    nextLine() << '-- Create the transactional view for ' << entity.sqlName.table;
    nextLine() << 'CREATE OR REPLACE VIEW ' << entity.sqlName.changesView;
    nextLine() << 'AS';
    ++indent;
    nextLine() << "SELECT 'CREATE' CHANGE_TYPE,";
    nextLine() << '       3*NEW.' << entity.sqlName.historyUniqueId << ' ' << entity.sqlName.changesUniqueId << ',';
    nextLine() << '       NEW.' << keyName << ',';
    nextLine() << '       NEW.START_ACTION_ID USER_ACTION_ID';
    entity.attributes.each { attribute ->
      sameLine() << ','
      if ( attribute.isTemporal() ) {
        nextLine() << '       NULL ' << attribute.sqlName.columnOld << ',';
        nextLine() << '       NEW.' << attribute.sqlName.column << ' ' << attribute.sqlName.columnNew;
      }
      else {
        nextLine() << '       NEW.' << attribute.sqlName.column << ' ' << attribute.sqlName.column;
      }
    }
    entity.relationships.each { relationship ->
      sameLine() << ','
      if ( relationship.isTemporal() ) {
        nextLine() << '       NULL ' << relationship.sqlName.columnOld << ',';
        nextLine() << '       NEW.' << relationship.sqlName.column << ' ' << relationship.sqlName.columnNew;
      }
      else {
        nextLine() << '       NEW.' << relationship.sqlName.column << ' ' << relationship.sqlName.column;
      }
    }
    nextLine() << '  FROM ' << entity.sqlName.historyTable << ' NEW';
    nextLine() << ' WHERE NEW.START_ACTION_ID NOT IN';
    nextLine() << '       (SELECT DISTINCT END_ACTION_ID';
    nextLine() << '          FROM ' << entity.sqlName.historyTable;
    nextLine() << '         WHERE ' << keyName << ' = ' << 'NEW.' << keyName;
    nextLine() << '           AND END_ACTION_ID IS NOT NULL)';
    nextLine() << 'UNION';
    nextLine() << "SELECT 'UPDATE' CHANGE_TYPE,";
    nextLine() << '       3*NEW.' << entity.sqlName.historyUniqueId << '+1 ' << entity.sqlName.changesUniqueId << ',';
    nextLine() << '       OLD.' << keyName << ',';
    nextLine() << '       NEW.START_ACTION_ID USER_ACTION_ID';
    entity.attributes.each { attribute ->
      sameLine() << ','
      if ( attribute.isTemporal() ) {
        nextLine() << '       OLD.' << attribute.sqlName.column << ' ' << attribute.sqlName.columnOld << ',';
        nextLine() << '       NEW.' << attribute.sqlName.column << ' ' << attribute.sqlName.columnNew;
      }
      else {
        nextLine() << '       NEW.' << attribute.sqlName.column << ' ' << attribute.sqlName.column;
      }
    }
    entity.relationships.each { relationship ->
      sameLine() << ','
      if ( relationship.isTemporal() ) {
        nextLine() << '       OLD.' << relationship.sqlName.column << ' ' << relationship.sqlName.columnOld << ',';
        nextLine() << '       NEW.' << relationship.sqlName.column << ' ' << relationship.sqlName.columnNew;
      }
      else {
        nextLine() << '       NEW.' << relationship.sqlName.column << ' ' << relationship.sqlName.column;
      }
    }
    nextLine() << '  FROM ' << entity.sqlName.historyTable << ' OLD, ' << entity.sqlName.historyTable << ' NEW';
    nextLine() << ' WHERE OLD.END_ACTION_ID = NEW.START_ACTION_ID';
    nextLine() << '   AND OLD.' << keyName << ' = NEW.' << keyName;
    nextLine() << 'UNION';
    nextLine() << "SELECT 'DELETE' CHANGE_TYPE,";
    nextLine() << '       3*OLD.' << entity.sqlName.historyUniqueId << '+2 ' << entity.sqlName.changesUniqueId << ',';
    nextLine() << '       OLD.' << keyName << ',';
    nextLine() << '       OLD.END_ACTION_ID USER_ACTION_ID';
    entity.attributes.each { attribute ->
      sameLine() << ','
      if ( attribute.isTemporal() ) {
        nextLine() << '       OLD.' << attribute.sqlName.column << ' ' << attribute.sqlName.columnOld << ',';
        nextLine() << '       NULL ' << attribute.sqlName.columnNew;
      }
      else {
        nextLine() << '       OLD.' << attribute.sqlName.column << ' ' << attribute.sqlName.column;
      }
    }
    entity.relationships.each { relationship ->
      sameLine() << ','
      if ( relationship.isTemporal() ) {
        nextLine() << '       OLD.' << relationship.sqlName.column << ' ' << relationship.sqlName.columnOld << ',';
        nextLine() << '       NULL ' << relationship.sqlName.columnNew;
      }
      else {
        nextLine() << '       OLD.' << relationship.sqlName.column << ' ' << relationship.sqlName.column;
      }
    }
    nextLine() << '  FROM ' << entity.sqlName.historyTable << ' OLD';
    nextLine() << ' WHERE OLD.END_ACTION_ID NOT IN'
    nextLine() << '       (SELECT DISTINCT START_ACTION_ID'
    nextLine() << '          FROM ' << entity.sqlName.historyTable;
    nextLine() << '         WHERE ' << keyName << ' = ' << 'OLD.' << keyName << ');';
    --indent;
    nextLine() << 'SHOW ERRORS VIEW ' << entity.sqlName.changesView << ';';
    nextLine();
  }

  private void createTrigger( DbTrigger trigger ) {
    nextLine() << '-- ' << trigger.description;
    nextLine() << 'CREATE OR REPLACE TRIGGER ' << trigger.sqlName;
    switch ( trigger.triggerType ) {
      case EDbTriggerType.AFTER_INSERT:
        nextLine() << 'AFTER INSERT ON ' << trigger.parent.sqlName;
        break;
      case EDbTriggerType.AFTER_UPDATE:
        nextLine() << 'AFTER UPDATE ON ' << trigger.parent.sqlName;
        break;
    }
    nextLine() << 'FOR EACH ROW';
    nextLine() << 'BEGIN';
    ++indent;
    trigger.code.split('\n').each{ line ->
      nextLine() << line;
    }
    --indent;
    nextLine() << 'END;';
    nextLine() << '/';
    nextLine() << 'SHOW ERRORS TRIGGER ' << trigger.sqlName << ';'
    nextLine();
  }

  /** Returns the unique ID for an entity; uses the base class if present. */
  private String getUniqueId( Entity entity ) {
    if ( entity.baseClass != null ) {
      return getUniqueId( entity.baseClass );
    }

    return entity.sqlName.uniqueId;
  }

}
