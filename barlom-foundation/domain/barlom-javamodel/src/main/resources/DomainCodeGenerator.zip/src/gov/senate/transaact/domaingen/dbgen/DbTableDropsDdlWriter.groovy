package gov.senate.transaact.domaingen.dbgen

import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbTable


/**
 * @author Vangent, Inc.
 */
class DbTableDropsDdlWriter
extends DbWriter {

  /** Writes the table column drops portion of a schema definition to the writer's output. */
  void writeDomain( DbDomain domain ) {

    String title = 'SCHEMA TABLES DEFINITION FOR ' + domain.sqlName;
    String purpose = 'Defines the ' + domain.sqlName + ' schema table drops.'

    writeFileHeader( title, purpose, true );

    nextLine() << '---------------------------';
    nextLine() << '-- Drop Obsolete Columns --';
    nextLine() << '---------------------------';
    nextLine();
    domain.tables.each { table ->
      alterTable( table );
    }
    nextLine();

    writeFileFooter();
  }

  private void alterTable( DbTable table ) {

    String keyName = table.primaryKeyColumn.sqlName;

    nextLine() << '-- Alter the table for ' << table.sqlName;
    nextLine() << 'DECLARE';
    nextLine() << indent() << 'COLUMN_NAMES DATAMODEL.IDENTIFIER_ARRAY;';
    nextLine() << 'BEGIN';
    ++indent;

    def delimiter = "";
    nextLine() << "COLUMN_NAMES := DATAMODEL.IDENTIFIER_ARRAY("
    table.columns.each { column ->
      sameLine() << delimiter << " '" << column.sqlName << "'";
      delimiter = ",";
    }
    sameLine() << " );";

    nextLine() << "DATAMODEL.DROP_UNUSED_COLUMNS( '" << table.sqlName << "', COLUMN_NAMES );";
    --indent;
    nextLine() << 'END;';
    nextLine() << '/';
    nextLine();
  }
}
