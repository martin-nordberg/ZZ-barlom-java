
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
@SuppressWarnings( "javadoc" )
public class JavaBuiltinType
  extends JavaType {

  /**
   * Constructs a new built in type.
   * @param javaName
   */
  private JavaBuiltinType( String javaName ) {
    super();

    this.javaName = javaName;
  }

  /** {@inheritDoc} */
  @Override
  public String getFullyQualifiedJavaName() {
    return this.javaName;
  }

  @Override
  public boolean getIsImplicitlyImported() {
    return true;
  }

  /** {@inheritDoc} */
  @Override
  public String getJavaName() {
    return this.javaName;
  }

  public static JavaBuiltinType BOOLEAN = new JavaBuiltinType( "boolean" );

  public static JavaBuiltinType DOUBLE = new JavaBuiltinType( "double" );

  public static JavaBuiltinType FLOAT = new JavaBuiltinType( "float" );

  public static JavaBuiltinType INT = new JavaBuiltinType( "int" );

  public static JavaBuiltinType LONG = new JavaBuiltinType( "long" );

  public static JavaBuiltinType VOID = new JavaBuiltinType( "void" );

  private String javaName;

}
