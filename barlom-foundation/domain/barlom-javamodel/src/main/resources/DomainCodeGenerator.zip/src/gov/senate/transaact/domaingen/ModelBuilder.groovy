
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Builder for a domain model. */
class ModelBuilder
extends BuilderSupport {

  /** Unused */
  def createNode( name ) {
    assert false;
  }

  /** Unused */
  def createNode( name, value ) {
    assert false;
  }

  /** Creates a model node with given properties. */
  def createNode( name, Map<String,Object> nodeProperties ) {

    // convert the temporal property to a flag to control instantiation logic below
    def properties = nodeProperties.clone();
    boolean temporal = false;
    boolean enumerated = false;

    if ( properties.containsKey( 'temporal' ) ) {
      temporal = properties.temporal;
      properties.remove( 'temporal' );
    }
    if ( properties.containsKey( 'enumerated' ) ) {
      enumerated = properties.enumerated;
      properties.remove( 'enumerated' );
    }

    // create the appropriate type of node
    switch ( name ) {
      case 'attribute':
        if ( temporal ) {
          return new TemporalAttribute( properties );
        }
        return new Attribute( properties );
      case 'constraint':
        return new Constraint( properties );
      case 'domain':
        return new Domain( properties );
      case 'entity':
        if ( temporal ) {
          return new TemporalEntity( properties );
        }
        if ( enumerated ) {
          return new EnumeratedEntity( properties );
        }
        return new Entity( properties );
      case 'instance':
        return new Instance( nodeProperties );
      case 'relationship':
        if ( temporal ) {
          return new TemporalRelationship( properties );
        }
        return new Relationship( properties );
      case 'related':
        return new RelatedInstance( nodeProperties );
      default:
        assert false : "Unknown type of model element: " + name;
    }

    return null;
  }

  /** Unused */
  def createNode( name, Map<String,Object> attributes, value ) {
    assert false : name;
  }

  /** Sets the parent node for a given child node. */
  void setParent( parent, child ) {
    child.setParent( parent );
  }
}
