
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaImplementedInterface
  extends JavaModelElement {

  /**
   * Constructs a new base interface (extends/implements)
   * @param parent
   */
  JavaImplementedInterface( JavaComponent parent, JavaInterface implementedInterface ) {
    super( parent, "" );

    this.implementedInterface = implementedInterface;

    parent.onAddChild( this );
  }

  /** Returns the implementedInterface. */
  public JavaInterface getImplementedInterface() {
    return this.implementedInterface;
  }

  /** {@inheritDoc} */
  @Override
  public JavaComponent getParent() {
    return (JavaComponent) super.getParent();
  }

  private JavaInterface implementedInterface;

}
