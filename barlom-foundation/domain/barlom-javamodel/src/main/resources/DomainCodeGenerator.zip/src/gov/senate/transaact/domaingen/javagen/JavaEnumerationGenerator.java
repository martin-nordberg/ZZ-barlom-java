
package gov.senate.transaact.domaingen.javagen;

import gov.senate.transaact.domaingen.javamodel.EJavaAccessibility;
import gov.senate.transaact.domaingen.javamodel.JavaBuiltinType;
import gov.senate.transaact.domaingen.javamodel.JavaClass;
import gov.senate.transaact.domaingen.javamodel.JavaConstructor;
import gov.senate.transaact.domaingen.javamodel.JavaEnumeration;
import gov.senate.transaact.domaingen.javamodel.JavaField;
import gov.senate.transaact.domaingen.javamodel.JavaMethod;
import gov.senate.transaact.domaingen.javamodel.JavaPackage;
import gov.senate.transaact.domaingen.javamodel.JavaRootPackage;
import gov.senate.transaact.domaingen.javamodel.JavaType;
import gov.senate.transaact.domaingen.model.Attribute;
import gov.senate.transaact.domaingen.model.DataType;
import gov.senate.transaact.domaingen.model.Entity;
import gov.senate.transaact.domaingen.model.Instance;
import gov.senate.transaact.domaingen.model.StringDataType;

/**
 * @author GDIT, Inc.
 */
public class JavaEnumerationGenerator {

  /**
   * Adds an enumeration from a given enumerated entity.
   * @param domainModelPackage
   * @param entity
   */
  static void addEmptyEnumeration( JavaPackage domainModelPackage, Entity entity ) {
    domainModelPackage.addEnumeration(
        entity.getJavaName().getImplementationClass(),
        entity.getDescription(),
        false );
  }

  /**
   * Adds an enumeration from a given enumerated entity.
   * @param domainModelPackage
   * @param entity
   */
  static void defineEnumeration( JavaPackage domainModelPackage, Entity entity ) {

    JavaRootPackage rootPackage = domainModelPackage.getRootPackage();

    JavaEnumeration enumerationClass = (JavaEnumeration) domainModelPackage
        .findComponent( entity.getJavaName().getImplementationClass() );

    assert enumerationClass != null;

    // each enum constant
    JavaEnumerationGenerator.defineEnumConstants( entity, enumerationClass );

    // constructor
    JavaEnumerationGenerator.defineConstructor( rootPackage, entity, enumerationClass );

    // useful types
    JavaType javaLongType = domainModelPackage.getRootPackage()
        .findComponent( "java.lang.Long" ).makeJavaType();
    JavaType javaStringType = domainModelPackage.getRootPackage()
        .findComponent( "java.lang.String" ).makeJavaType();

    // unique ID
    JavaEnumerationGenerator.defineUniqueId( rootPackage, entity, enumerationClass );

    // attributes
    JavaEnumerationGenerator.defineAttributes( rootPackage, entity, enumerationClass );

    // boolean tests

    // instances by ID

    // instances by name

    // all instances

  }

  /**
   * @param entity
   * @param enumerationClass
   */
  private static void defineConstructor( JavaRootPackage rootPackage, Entity entity, JavaEnumeration enumerationClass ) {

    String uniqueId = entity.getJavaName().getUniqueId();

    // initializer code
    String code = "    this." + uniqueId + " = " + uniqueId + ";\r\n";

    for ( Attribute attribute : entity.getAttributes() ) {
      code += "    this." + attribute.getJavaName().getField() + " = " + attribute.getJavaName().getField() + ";\r\n";
    }
    // TBD: relationships

    // constructor itself
    JavaConstructor constructor = enumerationClass.addConstructor(
        "Constructs a " + entity.getDescription(),
        EJavaAccessibility.PRIVATE,
        code
    );

    constructor.addParameter(
        uniqueId,
        "the unique ID of this " + entity.getJavaName().getAsDescription() ,
        rootPackage.findComponent( "java.lang.Long" ).makeJavaType()
    );
    for ( Attribute attribute : entity.getAttributes() ) {
      JavaType fieldType = JavaModelGeneratorUtilities.getType( rootPackage, attribute );
      String fieldName = attribute.getJavaName().getField();

      constructor.addParameter( fieldName, attribute.getDescription(), fieldType );
    }
    // TBD: relationships
  }

  /**
   * @param enumerationClass
   */
  private static void defineEnumConstants( Entity entity, JavaEnumeration enumerationClass ) {
    for ( Instance instance : entity.getInstances() ) {

      String parametersCode = DataType.longDataType.valueForJava( instance.get( "UniqueId") );

      for ( Attribute attribute : entity.getAttributes() ) {
        parametersCode += ", ";
        parametersCode += attribute.getDataType().valueForJava( instance.get( attribute.getJavaName().getAsIdentifier() ) );
      }

      enumerationClass.addEnumConstant(
          (String) instance.get( "Name" ),
          (String) instance.get( "Description" ),
          (Integer) instance.get( "UniqueId" ),
          parametersCode,
          instance.getReferencePrefix() );
    }
  }

  private static void defineUniqueId(
      JavaRootPackage rootPackage,
      Entity entity,
      JavaEnumeration enumerationClass
  ) {
    String fieldName = entity.getJavaName().getUniqueId();
    JavaType fieldType = rootPackage.findComponent( "java.lang.Long" ).makeJavaType();

    // field
    enumerationClass.addField(
        fieldName,
        "The unique ID of this " + entity.getJavaName().getAsDescription() + ".",
        EJavaAccessibility.PRIVATE,
        false,
        false,
        fieldType,
        ""
    );

    // getter
    enumerationClass.addMethod(
        "getUniqueId",
        "@return the unique ID of this instance",
        EJavaAccessibility.PUBLIC,
        false,
        false,
        false,
        rootPackage.findComponent( "java.lang.Long" ).makeJavaType(),
        "    return this." + fieldName + ";"
    );
  }

  /**
   * @param enumerationClass
   */
  private static void defineAttributes(
      JavaRootPackage rootPackage,
      Entity entity,
      JavaEnumeration enumerationClass
  ) {
    JavaType javaLongType = rootPackage.findComponent( "java.lang.Long" ).makeJavaType();

    Long index = 1L;
    for ( Instance instance : entity.getInstances() ) {

      String referencePrefix = instance.getReferencePrefix();
      String instanceName = ( String ) instance.get( instance.get( "nameAttributeName" ) );

      // constant field per instance
      enumerationClass.addField(
          referencePrefix + "_ID",
          "The unique ID for " + instanceName + ".",
          EJavaAccessibility.PUBLIC,
          true,
          true,
          javaLongType,
          DataType.longDataType.valueForJava( index )
      );

      if ( referencePrefix != null ) {
        // self test per instance
        enumerationClass.addMethod(
            instance.getJavaName().getInstanceTest(),
            "@return whether this instance matches " + instanceName + ".",
            EJavaAccessibility.PUBLIC,
            false,
            false,
            false,
            JavaBuiltinType.BOOLEAN,
            "    return " + enumerationClass.getJavaName() + "." + referencePrefix + "_ID.equals( this.getUniqueId() );"
        );

        for ( Attribute attribute : entity.getAttributes() ) {

          // constant field
          if ( attribute.getUnique() ) {
            String refName = attribute.getJavaName().getReferenceConstant( referencePrefix );

            enumerationClass.addField(
                refName,
                "The reference constant for " + instanceName + " instance " + attribute.getJavaName()
                    .getAsDescription() + ".",
                EJavaAccessibility.PUBLIC,
                true,
                true,
                JavaModelGeneratorUtilities.getType( rootPackage, attribute ),
                attribute.getDataType()
                    .valueForJava( instance.get( attribute.getJavaName().getAsIdentifier() ) )
            );
          }
        }
      }

      index += 1L;
    }

    for ( Attribute attribute : entity.getAttributes() ) {
      // attribute field
      enumerationClass.addField(
          attribute.getJavaName().getField(),
          attribute.getDescription(),
          EJavaAccessibility.PUBLIC,
          false,
          false,
          JavaModelGeneratorUtilities.getType( rootPackage, attribute ),
          null
      );
    }
  }

}
