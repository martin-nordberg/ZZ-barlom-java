
package gov.senate.transaact.domaingen.model;

/**
 * An attribute is a Java field with a simple type (as opposed to a relationship) or the
 * corresponding SQL non-key column.
 */
public class Attribute
  extends ModelElement {

  public Boolean getAutoTruncated() {
    return this.autoTruncated;
  }

  public DataType getDataType() {
    return this.dataType;
  }

  public Object getDefaultValue() {
    return this.defaultValue;
  }

  public String getDescription() {
    return this.description;
  }

  public Boolean getIndexed() {
    return this.indexed;
  }

  public Integer getMaxLength() {
    return this.maxLength;
  }

  public Boolean getObfuscated() {
    return this.obfuscated;
  }

  public Boolean getOptional() {
    return this.optional;
  }

  @Override
  public Entity getParent() {
    return this.parent;
  }

  public Integer getPrecision() {
    return this.precision;
  }

  public Boolean getRequired() {
    return this.required;
  }

  public Boolean getUnique() {
    return this.unique;
  }

  /** Whether changes to this attribute over time are stored for later recall. */
  public boolean isTemporal() {
    return false;
  }

  public void setAutoTruncated( Boolean autoTruncated ) {
    this.autoTruncated = autoTruncated;
  }

  public void setDataType( DataType dataType ) {
    this.dataType = dataType;
  }

  public void setDefaultValue( Object defaultValue ) {
    this.defaultValue = defaultValue;
  }

  public void setDescription( String description ) {
    this.description = description;
  }

  public void setIndexed( Boolean indexed ) {
    this.indexed = indexed;
  }

  public void setMaxLength( Integer maxLength ) {
    this.maxLength = maxLength;
  }

  public void setObfuscated( Boolean obfuscated ) {
    this.obfuscated = obfuscated;
  }

  public void setOptional( Boolean optional ) {
    this.optional = optional;
  }

  /**
   * Sets the parent entity for this attribute. (Also adds this attribute to the parent's list of
   * attributes.) (This method is needed by the model builder code.)
   */
  public void setParent( Entity parent ) {
    assert this.parent == null : "Cannot change the parent of an attribute.";
    this.parent = parent;
    parent.getAttributes().add( this );
  }

  public void setPrecision( Integer precision ) {
    this.precision = precision;
  }

  public void setRequired( Boolean required ) {
    this.required = required;
  }

  public void setUnique( Boolean unique ) {
    this.unique = unique;
  }

  /** Validates this attribute. */
  @Override
  public void validate() {
    String name = this.getName();

    assert name != null && !name.isEmpty() : "Attribute has no name.";
    assert this.description != null && !this.description.isEmpty() : "Attribute " + name
        + " has no description.";
    assert this.dataType != null : "Attribute " + name + " has no data type.";
    if ( this.dataType == DataType.stringDataType ) {
      assert this.maxLength > 0 : "String attribute " + name
          + " needs a maximum allowed length.";
    }
    else if ( this.dataType == DataType.unicodeStringDataType ) {
      assert this.maxLength > 0 : "String attribute " + name
          + " needs a maximum allowed length.";
    }
    else if ( this.dataType == DataType.moneyDataType ) {
      assert this.maxLength > 0 : "Money attribute " + name
          + " needs a maximum allowed length.";
      assert this.precision > 0 : "Money attribute " + name + " needs a precision.";
    }
    else {
      assert this.maxLength == null : "Non-String attribute " + name
          + " can not have a maximum allowed length.";
    }

    if ( this.unique ) {
      assert this.required : "Unique attribute " + name + " should not allow empty values.";
    }
  }

  /** Whether a string attribute should be automatically truncated to fit its database column. */
  private Boolean autoTruncated = false;

  /** The type of this attribute (string by default). */
  private DataType dataType = DataType.stringDataType;

  /** The default value of this attribute (an object of the right type). */
  private Object defaultValue;

  /** A short description of this attribute. */
  private String description;

  /** Whether this attribute should be indexed in the database for faster queries. */
  private Boolean indexed = false;

  /** The maximum length of this attribute (required for strings). */
  private Integer maxLength;

  /** Whether this attribute should be encrypted in the database. */
  private Boolean obfuscated = false;

  /**
   * Whether this attribute should be wrapped in Optional<> for NPE avoidance. TBD: As time permits
   * for refactoring & testing this should become !required and disappear.
   */
  private Boolean optional = false;

  /** The entity with this attribute. */
  private Entity parent;

  /** The precision of this attribute (e.g. for money). */
  private Integer precision;

  /** Whether this is a required (non-null) attribute. */
  private Boolean required = false;

  /**
   * Whether this attribute must have a unique value among all entity instances with this attribute.
   */
  private Boolean unique = false;
}
