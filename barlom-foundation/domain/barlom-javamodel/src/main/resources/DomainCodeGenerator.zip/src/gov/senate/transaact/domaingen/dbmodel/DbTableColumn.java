
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public abstract class DbTableColumn
  extends DbColumn {

  /**
   * Constructs a new database column.
   */
  DbTableColumn(
      DbTable parent,
      String name,
      String description,
      EDbDataType type,
      Integer size,
      Integer precision,
      Boolean isNullable,
      Object defaultValue ) {
    super( parent, name, description );

    this.type = type;
    this.size = size;
    this.precision = precision;
    this.isNullable = isNullable;
    this.defaultValue = defaultValue;
  }

  /** Returns the defaultValue. */
  public Object getDefaultValue() {
    return this.defaultValue;
  }

  /** Returns the isNullable. */
  public Boolean getIsNullable() {
    return this.isNullable;
  }

  /** Returns the precision. */
  public Integer getPrecision() {
    return this.precision;
  }

  /** Returns the size. */
  public Integer getSize() {
    return this.size;
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( this.getName() );
  }

  /** Returns the type. */
  public EDbDataType getType() {
    return this.type;
  }

  private Object defaultValue;

  private Boolean isNullable;

  private Integer precision;

  private Integer size;

  private EDbDataType type;

}
