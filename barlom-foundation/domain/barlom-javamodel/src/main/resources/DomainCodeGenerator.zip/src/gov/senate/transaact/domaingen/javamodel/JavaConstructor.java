
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaConstructor
  extends JavaFunction {

  /**
   * Constructs a new constructor.
   * @param parent
   * @param name
   * @param description
   */
  JavaConstructor(
      JavaConcreteComponent parent,
      String description,
      EJavaAccessibility accessibility,
      String code ) {
    super(
        parent,
        parent.getName(),
        description,
        accessibility,
        false,
        false,
        JavaBuiltinType.VOID,
        code );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public JavaConcreteComponent getParent() {
    return (JavaConcreteComponent) super.getParent();
  }

}
