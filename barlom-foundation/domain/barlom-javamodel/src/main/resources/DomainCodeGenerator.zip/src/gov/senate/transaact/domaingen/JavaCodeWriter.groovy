
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Abstract class to write Java code for a domain. */
abstract class JavaCodeWriter
extends IndentingWriter {

  /** The folder to write each entity's source file to. */
  File sourceFolder;

  /** Writes the Java code for entities in a given domain. */
  abstract void writeDomain( Domain domain );

  /** Determines whether a given class is in a given package. */
  protected boolean isInSamePackage( String className, String packageName ) {
    if ( !className.startsWith( packageName ) ) {
      return false;
    }

    return className.indexOf( '.', packageName.length()+1 ) == -1;
  }

  /** Writes a custom code segment placeholder with given name. */
  protected void writeCustomCodeSegment( String name ) {
    int oldIndent = indent;
    indent = 0;
    nextLine() << FileRewriter.HAND_WRITTEN_CODE_TOKEN << ' hand-written code begins: ' << name;
    nextLine() << FileRewriter.HAND_WRITTEN_CODE_TOKEN << ' ' << name;
    nextLine() << FileRewriter.HAND_WRITTEN_CODE_TOKEN << ' hand-written code ends';
    indent = oldIndent;
  }
}