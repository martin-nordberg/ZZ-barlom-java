
package gov.senate.transaact.domaingen.dbgen;

import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbSchema
import gov.senate.transaact.domaingen.model.*

/** This class writes the SQL code to drop and recreate a schema **/
class DbCreateSchemaWriter
extends DbWriter {

  /** Writes a schema definition to the writer's output. */
  void writeDomain( DbDomain domain ) {

    DbSchema schema = domain.schema;
    String schemaName = schema.sqlName + '_' + this.SCHEMA_VERSION;

    String title = 'SCHEMA CREATION FOR ' + schemaName;
    String purpose = 'Drops and restores the ' + schemaName + ' user and schema.'

    writeFileHeader( title, purpose, false );

    nextLine() << "-- Drop the user, but ignore any error if user doesn't yet exist.";
    nextLine() << 'BEGIN';
    nextLine() << indent() << "EXECUTE IMMEDIATE 'DROP USER " << schemaName << " CASCADE';";
    nextLine() << 'EXCEPTION';
    ++indent;
    nextLine() << 'WHEN OTHERS THEN';
    ++indent;
    nextLine() << 'IF ( SQLCODE <> -1918/*User does not exist*/ ) THEN';
    nextLine() << indent() << 'RAISE;';
    nextLine() << 'END IF;';
    --indent;
    --indent;
    nextLine() << 'END;';
    nextLine() << '/';
    nextLine();

    nextLine() << '-- Create the user.';
    nextLine() << 'CREATE USER ' << schemaName;
    ++indent;
    nextLine() << 'IDENTIFIED BY ' << this.password;
    nextLine() << 'DEFAULT TABLESPACE TRANSAACT_DATA';
    nextLine() << 'TEMPORARY TABLESPACE TEMP';
    nextLine() << 'ACCOUNT UNLOCK;';
    --indent;
    nextLine();

    nextLine() << '-- Grant the user basic privileges to manage their own schema.';
    nextLine() << 'GRANT CONNECT TO ' << schemaName << ';';
    nextLine() << 'GRANT RESOURCE TO ' << schemaName << ';';
    nextLine() << 'GRANT CREATE SYNONYM TO ' << schemaName << ';';
    nextLine() << 'GRANT CREATE TABLE TO ' << schemaName << ';';
    nextLine() << 'GRANT CREATE VIEW TO ' << schemaName << ';';
    nextLine();

    writeFileFooter();
  }

  String password;
}