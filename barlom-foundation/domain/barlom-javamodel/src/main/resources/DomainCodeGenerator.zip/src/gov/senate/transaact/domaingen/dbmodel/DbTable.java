
package gov.senate.transaact.domaingen.dbmodel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author GDIT, Inc.
 */
public class DbTable
  extends DbRelation {

  /** Constructs a new table. */
  DbTable( DbDomain parent, String name, String description ) {
    super( parent, name, description );

    this.attributeColumns = new ArrayList<>();
    this.foreignKeyColumns = new ArrayList<>();
    this.foreignKeyConstraints = new ArrayList<>();
    this.indexes = new ArrayList<>();
    this.indexesByName = new HashMap<>();
    this.records = new ArrayList<>();
    this.triggers = new ArrayList<>();
    this.uniquenessConstraints = new ArrayList<>();

    parent.onAddChild( this );
  }

  /**
   * Creates an attribute column within this table.
   */
  public DbAttributeColumn addAttributeColumn(
      String name,
      String attributeName,
      String description,
      EDbDataType type,
      Integer size,
      Integer precision,
      boolean isNullable,
      Object defaultValue ) {
    return new DbAttributeColumn(
        this,
        name,
        attributeName,
        description,
        type,
        size,
        precision,
        isNullable,
        defaultValue );
  }

  /**
   * Creates the primary key column within this table.
   */
  public DbColumn addDiscriminatorColumn( String defaultValue ) {
    return new DbDiscriminatorColumn( this, defaultValue );
  }

  /**
   * Creates a foreign key within this table.
   */
  public DbForeignKeyColumn addForeignKeyColumn(
      String name,
      String relationshipName,
      String description,
      Boolean isNullable ) {
    return new DbForeignKeyColumn( this, name, relationshipName, description, isNullable );
  }

  /**
   * @param name
   * @param description
   * @param relatedTable
   * @param isCascadeDelete
   * @param result
   * @return The newly added constraint
   */
  public DbForeignKeyConstraint addForeignKeyConstraint(
      String name,
      String description,
      DbTableColumn foreignKeyColumn,
      DbTable relatedTable,
      Boolean isCascadeDelete ) {
    return new DbForeignKeyConstraint(
        this,
        name,
        description,
        foreignKeyColumn,
        relatedTable,
        isCascadeDelete );
  }

  /**
   * Creates a new index on the given column within this table.
   */
  public DbIndex addIndex( DbColumn column ) {
    return new DbIndex( this, column );
  }

  /**
   * Creates the primary key column within this table.
   */
  public DbPrimaryKeyColumn addPrimaryKeyColumn( String name ) {
    return new DbPrimaryKeyColumn( this, name );
  }

  /**
   * Creates the primary key column within this table.
   */
  public DbPrimaryKeyConstraint addPrimaryKeyConstraint( String name ) {
    return new DbPrimaryKeyConstraint( this, name, "Primary key", this.primaryKeyColumn );
  }

  /**
   * Creates a pre-defined record within this table.
   */
  public DbRecord addRecord( Map<String, Object> values, Boolean isUnitTestValue ) {
    return new DbRecord( this, values, isUnitTestValue );
  }

  /**
   * Creates a new sequence within this schema.
   */
  public DbSequence addSequence() {
    return new DbSequence( this );
  }

  /**
   * Creates a new index on the given column within this table.
   */
  public DbTrigger addTrigger( EDbTriggerType triggerType, String description, String code ) {
    return new DbTrigger( this, triggerType, description, code );
  }

  /**
   * Creates a foreign key within this table.
   */
  public DbUniquenessConstraint addUniquenessConstraint( DbTableColumn uniqueColumn ) {
    String name = DbNamedModelElement.makeSqlName( this.getName(), uniqueColumn.getName() );
    String description = "Unique column: " + uniqueColumn.getSqlName();

    return this.addUniquenessConstraint(
        name,
        description,
        DbConstraint.makeListOfOneColumn( uniqueColumn ) );
  }

  /**
   * Creates a foreign key within this table.
   */
  public DbUniquenessConstraint addUniquenessConstraint(
      String name,
      String description,
      DbTableColumn uniqueColumn1,
      DbTableColumn uniqueColumn2 ) {
    return new DbUniquenessConstraint(
        this,
        name,
        description,
        DbConstraint.makeListOfTwoColumns( uniqueColumn1, uniqueColumn2 ) );
  }

  /**
   * Creates a foreign key within this table.
   */
  public DbUniquenessConstraint addUniquenessConstraint(
      String name,
      String description,
      List<DbTableColumn> uniqueColumns ) {
    return new DbUniquenessConstraint( this, name, description, uniqueColumns );
  }

  /** Returns the attributeColumns. */
  public List<DbAttributeColumn> getAttributeColumns() {
    return this.attributeColumns;
  }

  /** {@inheritDoc} */
  @Override
  public DbTableColumn getColumnByName( String name ) {
    return (DbTableColumn) super.getColumnByName( name );
  }

  /** Returns the discriminatorColumn. */
  public DbDiscriminatorColumn getDiscriminatorColumn() {
    return this.discriminatorColumn;
  }

  /** Returns the foreignKeyColumns. */
  public List<DbForeignKeyColumn> getForeignKeyColumns() {
    return this.foreignKeyColumns;
  }

  /** Returns the foreign key constraints. */
  public List<DbForeignKeyConstraint> getForeignKeyConstraints() {
    return this.foreignKeyConstraints;
  }

  /** Returns the historyTable. */
  public DbTable getHistoryTable() {
    return this.historyTable;
  }

  /** Returns the indexes. */
  public List<DbIndex> getIndexes() {
    return this.indexes;
  }

  /** Returns the primaryKeyColumn. */
  public DbPrimaryKeyColumn getPrimaryKeyColumn() {
    return this.primaryKeyColumn;
  }

  /** Returns the primaryKeyConstraint. */
  public DbPrimaryKeyConstraint getPrimaryKeyConstraint() {
    return this.primaryKeyConstraint;
  }

  /** Returns the records. */
  public List<DbRecord> getRecords() {
    return this.records;
  }

  /** Returns the sequence. */
  public DbSequence getSequence() {
    return this.sequence;
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( this.getName() );
  }

  /** Returns the uniqueness constraints. */
  public List<DbUniquenessConstraint> getUniquenessConstraints() {
    return this.uniquenessConstraints;
  }

  /**
   * Sets the historyTable.
   * @param historyTable The new value for historyTable.
   */
  public void setHistoryTable( DbTable historyTable ) {
    this.historyTable = historyTable;
  }

  /**
   * Creates a new column within this relation.
   */
  void onAddChild( DbAttributeColumn column ) {
    super.onAddChild( column );

    this.attributeColumns.add( column );
  }

  /**
   * Creates the primary key column within this table.
   */
  void onAddChild( DbDiscriminatorColumn discriminatorCol ) {
    assert this.discriminatorColumn == null;

    super.onAddChild( discriminatorCol );

    this.discriminatorColumn = discriminatorCol;
  }

  /**
   * Creates a new column within this relation.
   */
  void onAddChild( DbForeignKeyColumn column ) {
    super.onAddChild( column );

    this.foreignKeyColumns.add( column );
  }

  /**
   * Creates the primary key column within this table.
   */
  void onAddChild( DbForeignKeyConstraint foreignKeyConstraint ) {
    super.onAddChild( foreignKeyConstraint );

    this.foreignKeyConstraints.add( foreignKeyConstraint );
  }

  /**
   * Creates a new index on the given column within this table.
   */
  void onAddChild( DbIndex index ) {
    String indexName = index.getSqlName();

    assert this.indexesByName.get( indexName ) == null : "Duplicate index name: " + indexName;

    super.onAddChild( index );

    this.indexes.add( index );
    this.indexesByName.put( indexName, index );
  }

  /**
   * Creates the primary key column within this table.
   */
  void onAddChild( DbPrimaryKeyColumn primaryKeyCol ) {
    assert this.primaryKeyColumn == null;

    super.onAddChild( primaryKeyCol );

    this.primaryKeyColumn = primaryKeyCol;
  }

  /**
   * Creates the primary key column within this table.
   */
  void onAddChild( DbPrimaryKeyConstraint primaryKeyCon ) {
    assert this.primaryKeyConstraint == null;

    super.onAddChild( primaryKeyCon );

    this.primaryKeyConstraint = primaryKeyCon;
  }

  /**
   * Creates a new record within this table.
   */
  void onAddChild( DbRecord record ) {
    super.onAddChild( record );

    this.records.add( record );
  }

  /**
   * Creates a new sequence within this schema.
   */
  void onAddChild( DbSequence seq ) {
    assert this.sequence == null;

    super.onAddChild( seq );

    this.sequence = seq;
  }

  /**
   * Creates a new index on the given column within this table.
   */
  void onAddChild( DbTrigger trigger ) {
    super.onAddChild( trigger );

    this.triggers.add( trigger );
  }

  /**
   * Creates a foreign key within this table.
   */
  void onAddChild( DbUniquenessConstraint constraint ) {
    super.onAddChild( constraint );

    this.uniquenessConstraints.add( constraint );
  }

  private List<DbAttributeColumn> attributeColumns;

  private DbDiscriminatorColumn discriminatorColumn;

  private List<DbForeignKeyColumn> foreignKeyColumns;

  private List<DbForeignKeyConstraint> foreignKeyConstraints;

  private DbTable historyTable;

  private List<DbIndex> indexes;

  private Map<String, DbIndex> indexesByName;

  private DbPrimaryKeyColumn primaryKeyColumn;

  private DbPrimaryKeyConstraint primaryKeyConstraint;

  private List<DbRecord> records;

  private DbSequence sequence;

  private List<DbTrigger> triggers;

  private List<DbUniquenessConstraint> uniquenessConstraints;
}
