
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GDIT, Inc.
 */
public class JavaEnumeration
  extends JavaConcreteComponent {

  /**
   * Constructs a new class.
   * @param parent
   * @param name
   * @param description
   */
  JavaEnumeration( JavaPackage parent, String name, String description, Boolean isExternal ) {
    super( parent, name, description, isExternal );

    this.enumConstants = new ArrayList<JavaEnumConstant>();

    parent.onAddChild( this );
  }

  /** Creates an new enum constant within this enumeration. */
  public JavaEnumConstant addEnumConstant(
      String name,
      String description,
      Integer uniqueId,
      String parametersCode,
      String referencePrefix ) {
    return new JavaEnumConstant( this, name, description, uniqueId, parametersCode, referencePrefix );
  }

  /** @return the enum constants within this enumeration. */
  public List<JavaEnumConstant> getEnumConstants() {
    return this.enumConstants;
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaEnumConstant child ) {
    super.onAddChild( child );
    this.enumConstants.add( child );
  }

  private List<JavaEnumConstant> enumConstants;
}
