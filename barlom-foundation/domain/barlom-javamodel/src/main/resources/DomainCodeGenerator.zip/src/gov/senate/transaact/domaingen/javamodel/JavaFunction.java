
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaFunction
  extends JavaMember {

  /**
   * Constructs a new method.
   * @param parent
   * @param name
   * @param description
   */
  protected JavaFunction(
      JavaComponent parent,
      String name,
      String description,
      EJavaAccessibility accessibility,
      Boolean isStatic,
      Boolean isFinal,
      JavaType returnType,
      String code ) {
    super( parent, name, description, accessibility, isStatic, isFinal, returnType );

    this.code = code;

    this.parameters = new ArrayList<JavaParameter>();

    parent.onAddChild( this );
  }

  /** Creates a parameter for this method. */
  public JavaParameter addParameter( String name, String description, JavaType type ) {
    return new JavaParameter( this, name, description, type );
  }

  /** @return the code of this method. */
  public String getCode() {
    return this.code;
  }

  @Override
  public Set<JavaType> getImports() {
    Set<JavaType> result = super.getImports();

    for ( JavaParameter parameter : this.parameters ) {
      result.add( parameter.getType() );
    }

    return result;
  }

  /** @return the parameters within this method. */
  public List<JavaParameter> getParameters() {
    return this.parameters;
  }

  /** @return the return type of this method. */
  public JavaType getReturnType() {
    return this.getType();
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaParameter child ) {
    super.onAddChild( child );
    this.parameters.add( child );
  }

  private String code;

  private List<JavaParameter> parameters;

}
