
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaParameter
  extends JavaTypedModelElement {

  /**
   * Constructs a new parameter
   * @param parent
   * @param name
   * @param description
   */
  JavaParameter( JavaFunction parent, String name, String description, JavaType type ) {
    super( parent, name, description, type );

    parent.onAddChild( this );
  }

  /** @return the parent of this parameter. */
  @Override
  public JavaFunction getParent() {
    return (JavaFunction) super.getParent();
  }

}
