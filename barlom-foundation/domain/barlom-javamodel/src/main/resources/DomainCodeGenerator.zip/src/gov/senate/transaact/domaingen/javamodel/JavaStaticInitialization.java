
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaStaticInitialization
  extends JavaModelElement {

  /**
   * Constructs a new static initialization block.
   * @param parent
   * @param name
   * @param description
   */
  JavaStaticInitialization( JavaConcreteComponent parent, String description, String code ) {
    super( parent, description );

    this.code = code;

    parent.onAddChild( this );
  }

  /** Returns the code. */
  public String getCode() {
    return this.code;
  }

  /** {@inheritDoc} */
  @Override
  public JavaConcreteComponent getParent() {
    return (JavaConcreteComponent) super.getParent();
  }

  private String code;

}
