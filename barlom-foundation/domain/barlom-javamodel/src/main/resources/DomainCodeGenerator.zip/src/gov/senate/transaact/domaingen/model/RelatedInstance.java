
package gov.senate.transaact.domaingen.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Represents an instance related to one or more others by a many-to-many entity */
public class RelatedInstance {

  /** Returns the parent of this instance. */
  public Instance getParent() {
    return this.parent;
  }

  /**
   * Sets the parent entity of this instance (also adds the instance to the entity's list of
   * instances).
   */
  public void setParent( Instance parent ) {
    assert this.parent == null : "Can not change the parent of an instance.";
    this.parent = parent;
    parent.getRelatedInstances().add( this );
  }

  public void setTo( String to ) {
    this.to = new String[] {
      to
    };
  }

  public void setToMany( String[] to ) {
    this.to = to;
  }

  public void validate() {
    assert this.to != null : "Related instance has no related 'to' field";
    assert this.through != null : "Related instance has no related 'through' field";
  }

  /** Processes elements after the domain has been loaded */
  void afterLoad() {
    Entity parentEntity = this.parent.getParent();
    Domain domain = parentEntity.getParent();

    Entity relationshipEntity = null;
    for ( Entity entity : domain.entities ) {
      if ( entity.getName().equals( this.through ) ) {
        relationshipEntity = entity;
        break;
      }
    }
    assert relationshipEntity != null : "Could not find many-to-many entity " + this.through;

    // If the field defining the back-relationship isn't set, determine a
    // back relationship.
    if ( this.by == null ) {
      List<Relationship> backs = new ArrayList<>();
      for ( Relationship relationship : relationshipEntity.getRelationships() ) {
        if ( relationship.getRelatedEntity() == parentEntity
            && this.attributes.get( relationship.getName() ) == null ) {
          backs.add( relationship );
        }
      }
      assert backs.size() == 1 : "Many-to-many back relationship is not well defined";
      this.by = backs.get( 0 ).getJavaName().getAsIdentifier();
    }

    List<Relationship> forwards = new ArrayList<>();
    for ( Relationship relationship : relationshipEntity.getRelationships() ) {
      if ( !relationship.getName().equals( this.by )
          && this.attributes.get( relationship.getName() ) == null ) {
        forwards.add( relationship );
      }
    }

    assert forwards.size() == 1 : "Many-to-many forward relationship is not well defined: "
        + this.by + " " + forwards.size();
    Relationship forward = forwards.get( 0 );

    for ( String toInstanceName : this.to ) {
      Map<String, Object> instanceAttrs = new HashMap<>();
      instanceAttrs.put( "UniqueId", relationshipEntity.getNewUniqueId() );
      instanceAttrs.put( "nameAttributeName", "UniqueId" );
      instanceAttrs.put( this.by, this.parent.get( this.parent.get( "nameAttributeName" ) ) );
      instanceAttrs.put( forward.getJavaName().getAsIdentifier(), toInstanceName );
      instanceAttrs.putAll( this.attributes );

      Instance instance = new Instance( instanceAttrs );
      instance.setParent( relationshipEntity );
    }
  }

  /** Extra attributes to be placed in the relationship instance */
  Map<String, Object> attributes = new HashMap<>();

  /** The field name the parent is known by in the relationship table */
  String by;

  /** The entity with this attribute. */
  Instance parent;

  /** The many-to-many entity the instances are related through */
  String through;

  /** The instance(s) the parent instance is related to */
  String[] to;
}
