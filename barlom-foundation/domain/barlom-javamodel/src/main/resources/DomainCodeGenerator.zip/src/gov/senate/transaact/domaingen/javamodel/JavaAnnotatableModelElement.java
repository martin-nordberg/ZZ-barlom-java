
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaAnnotatableModelElement
  extends JavaNamedModelElement {

  /**
   * Constructs a new named model element.
   * @param parent The parent of the element.
   * @param name The name of the element.
   * @param description A description of the element
   */
  protected JavaAnnotatableModelElement(
      JavaNamedModelElement parent,
      String name,
      String description ) {
    super( parent, name, description );

    this.annotations = new ArrayList<JavaAnnotation>();
    this.importedElements = new HashSet<IJavaTyped>();
  }

  /** Creates an annotation for this named model element. */
  public JavaAnnotation addAnnotation(
      String description,
      JavaAnnotationInterface annotationInterface,
      String parametersCode ) {
    return new JavaAnnotation( this, description, annotationInterface, parametersCode );
  }

  /** @return the annotations of this named model element. */
  public List<JavaAnnotation> getAnnotations() {
    return this.annotations;
  }

  /** @return the types needed to be imported by this component. */
  public Set<JavaType> getImports() {
    Set<JavaType> result = new ImportedJavaTypesSet();

    for ( IJavaTyped importedElement : this.importedElements ) {
      result.add( importedElement.makeJavaType() );
    }

    for ( JavaAnnotation method : this.getAnnotations() ) {
      result.add( method.getAnnotationInterface().makeJavaType() );
    }

    return result;
  }

  /** Adds a type that must be imported for textual code to work. */
  public void importForCode( IJavaTyped importedElement ) {
    assert importedElement != null;
    this.importedElements.add( importedElement );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaAnnotation child ) {
    super.onAddChild( child );
    this.annotations.add( child );
  }

  private List<JavaAnnotation> annotations;

  private Set<IJavaTyped> importedElements;

}
