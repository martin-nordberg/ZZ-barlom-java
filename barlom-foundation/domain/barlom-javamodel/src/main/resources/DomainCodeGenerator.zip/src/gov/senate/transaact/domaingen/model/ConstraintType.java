
package gov.senate.transaact.domaingen.model;

/** A primitive data type (String, integer, date, etc.). */
public class ConstraintType
  extends ModelElement {

  /**
   * Constructs a new constraint type
   * @param name The name of the constraint.
   * @param sqlName The SQL name of the constraint.
   */
  public ConstraintType( String name, String sqlName ) {
    this.setName( name );
    this.setSqlName( sqlName );
  }

  @Override
  public Constraint getParent() {
    return null;
  }

  /** Validates this constraint. */
  @Override
  public void validate() {
    assert !this.getName().isEmpty() : "Constraint type has no name.";
  }

  /** A uniqueness constraint over multiple fields. */
  static ConstraintType uniquenessConstraintType = new ConstraintType( "Uniqueness", "UNIQUE" );
}
