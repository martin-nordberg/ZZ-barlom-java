
package gov.senate.transaact.domaingen.javagen;

import gov.senate.transaact.domaingen.javamodel.EJavaAccessibility;
import gov.senate.transaact.domaingen.javamodel.JavaBuiltinType;
import gov.senate.transaact.domaingen.javamodel.JavaClass;
import gov.senate.transaact.domaingen.javamodel.JavaField;
import gov.senate.transaact.domaingen.javamodel.JavaMethod;
import gov.senate.transaact.domaingen.javamodel.JavaPackage;
import gov.senate.transaact.domaingen.javamodel.JavaRootPackage;
import gov.senate.transaact.domaingen.javamodel.JavaType;
import gov.senate.transaact.domaingen.model.Attribute;
import gov.senate.transaact.domaingen.model.DataType;
import gov.senate.transaact.domaingen.model.Entity;
import gov.senate.transaact.domaingen.model.Instance;

/**
 * @author GDIT, Inc.
 */
public class JavaImplementationGenerator {

  /**
   * @param domainModelPackage
   * @param entity
   */
  static void addEmptyImplementationClass( JavaPackage domainModelPackage, Entity entity ) {

    JavaClass implementationClass = domainModelPackage
        .addClass(
            entity.getJavaName().getImplementationClass(),
            entity.getDescription(),
            false,
            false,
            null /* TBD */,
            false );

  }

  /**
   * @param domainModelPackage
   * @param entity
   */
  static void defineImplementationClass( JavaPackage domainModelPackage, Entity entity ) {

    JavaRootPackage rootPackage = domainModelPackage.getRootPackage();

    JavaClass implementationClass = (JavaClass) domainModelPackage.findComponent( entity
        .getJavaName().getImplementationClass() );

    assert implementationClass != null;

    // class annotations
    defineClassAnnotations( rootPackage, entity, implementationClass );

    // base class
    defineBaseClass( rootPackage, entity, implementationClass );

    // getFieldsToString
    defineGetFieldsToString( rootPackage, entity, implementationClass );

    // getValidationMessages
    defineGetValidationMessages( rootPackage, entity, implementationClass );

    // serialization version field
    defineSerializationVersionField( implementationClass );

    // unique ID
    defineUniqueId( rootPackage, entity, implementationClass );

    // attribute fields, getters, and setters
    defineAttributes( rootPackage, entity, implementationClass );

    // reference values
    if ( entity.getHasReferenceValuesOnly() ) {
      defineReferenceValues( rootPackage, entity, implementationClass );
    }
  }

  private static void defineUniqueId(
      JavaRootPackage rootPackage,
      Entity entity,
      JavaClass implementationClass
  ) {
    String fieldName = entity.getJavaName().getUniqueId();
    JavaType fieldType = rootPackage.findComponent( "java.lang.Long" ).makeJavaType();

    // field
    JavaField field = implementationClass.addField(
        fieldName,
        "The unique ID of this " + entity.getJavaName().getAsDescription() + ".",
        EJavaAccessibility.PRIVATE,
        false,
        false,
        fieldType,
        "" );

    field.addAnnotation( "", rootPackage.findAnnotationInterface( "javax.persistence.Id" ), "" );
    field.addAnnotation( "", rootPackage.findAnnotationInterface( "javax.persistence.Column" ), "name = \"" + entity.getSqlName().getUniqueId() + "\"" );
    field.addAnnotation( "", rootPackage.findAnnotationInterface( "javax.persistence.SequenceGenerator" ), "name = \"" + entity.getSqlName().getSequence()+ "\", allocationSize = 1" );
    field.addAnnotation( "", rootPackage.findAnnotationInterface( "javax.persistence.GeneratedValue" ), "strategy = GenerationType.SEQUENCE, generator = \"" + entity.getSqlName().getSequence()+ "\"" );

    field.importForCode( rootPackage.findComponent( "javax.persistence.GenerationType" ) );

    // getter
    JavaMethod getter = implementationClass.addMethod(
        "getUniqueId",
        "{@inheritDoc}",
        EJavaAccessibility.PUBLIC,
        false,
        false,
        false,
        rootPackage.findComponent( "java.lang.Long" ).makeJavaType(),
        "    return this." + fieldName + ";"
    );
    getter.addAnnotation( "", rootPackage.findAnnotationInterface( "java.lang.Override" ), null );

    // setter
    JavaMethod setter = implementationClass.addMethod(
        "setUniqueId",
        "{@inheritDoc}",
        EJavaAccessibility.PUBLIC,
        false,
        false,
        false,
        JavaBuiltinType.VOID,
        "    this.trackChange( this." + fieldName + ", uniqueId );\r\n" +
        "    this." + fieldName + " = uniqueId;"
    );
    setter.addParameter( "uniqueId", "the new unique ID", fieldType );
    setter.addAnnotation( "", rootPackage.findAnnotationInterface( "java.lang.Override" ), null );
  }

  private static void defineGetFieldsToString(
      JavaRootPackage rootPackage,
      Entity entity,
      JavaClass implementationClass
  ) {
    String code = "    String result = super.getFieldsToString();\r\n";
    for ( Attribute attribute : entity.getAttributes() ) {
      String fieldName = attribute.getJavaName().getField();
      String getterName = attribute.getJavaName().getGetter();
      code += "    result += \"," + fieldName + "=\" + this." + getterName + "();\r\n";
    }
    code += "    return result;";

    JavaMethod method = implementationClass.addMethod(
        "getFieldsToString",
        "{@inheritDoc}",
        EJavaAccessibility.PROTECTED,
        false,
        false,
        false,
        rootPackage.findComponent( "java.lang.String" ).makeJavaType(),
        code
    );

    method.addAnnotation( "", rootPackage.findAnnotationInterface( "java.lang.Override" ), null );
  }

  private static void defineGetValidationMessages(
      JavaRootPackage rootPackage,
      Entity entity,
      JavaClass implementationClass
  ) {
    String code = "    List<String> messages = new ArrayList<String>();\r\n";
    for ( Attribute attribute : entity.getAttributes() ) {
      String getterName = attribute.getJavaName().getGetter();
      if ( attribute.getRequired() ) {
        code += "    if ( this." + getterName + "() == null";
        if ( attribute.getDataType() == DataType.stringDataType ) {
          code += " || this." + getterName + "().length() == 0";
        }
        code += " ) {\r\n";
        code += "      messages.add( \"Missing " + attribute.getName() + ".\" );\r\n";
        code += "    }\r\n";
      }
      if ( attribute.getMaxLength() != null ) {
        code += "    if ( this." + getterName + "() != null && this." + getterName + "().length() > " + attribute.getMaxLength() + " ) {\r\n";
        code += "      messages.add( \"" + attribute.getName() + " can be at most " + attribute.getMaxLength() + " characters.\" );\r\n";
        code += "    }\r\n";
      }
    }

    code += "\r\n";
    code += "// ### hand-written code begins: validation\r\n";
    code += "// ### validation\r\n";
    code += "// ### hand-written code ends\r\n";
    code += "\r\n";
    code += "    return messages;";

    JavaMethod method = implementationClass.addMethod(
        "getValidationMessages",
        "{@inheritDoc}",
        EJavaAccessibility.PUBLIC,
        false,
        false,
        false,
        rootPackage.findComponent( "java.util.List" ).makeGenericType( rootPackage.findComponent( "java.lang.String" ) ),
        code
    );

    method.addAnnotation( "", rootPackage.findAnnotationInterface( "java.lang.Override" ), null );

    method.importForCode( rootPackage.findComponent( "java.util.ArrayList" ) );
  }

  private static void defineReferenceValues(
      JavaRootPackage rootPackage, Entity entity, JavaClass implementationClass
  ) {
    for ( Instance instance : entity.getInstances() ) {
      if ( instance.getReferencePrefix() != null ) {
        String referencePrefix = instance.getReferencePrefix();

        // self-check method
        implementationClass.addMethod(
            instance.getJavaName().getInstanceTest(),
            "@return whether this instance matches " + instance.get( instance.get( "nameAttributeName" ) ) + ".",
            EJavaAccessibility.PUBLIC,
            false,
            false,
            false,
            JavaBuiltinType.BOOLEAN,
            "    return " + implementationClass.getJavaName() + "." + instance.getReferencePrefix() + "_ID.equals( this.getUniqueId() );"
        );

        // field ID
        implementationClass.addField(
            referencePrefix + "_ID",
            "The unique ID for " + instance.get( instance.get( "nameAttributeName" ) ) + ".",
            EJavaAccessibility.PUBLIC,
            true,
            true,
            rootPackage.findComponent( "java.lang.Long" ).makeJavaType(),
            instance.get( "UniqueId" ) + "L"
        );

        // unique field attributes
        for ( Attribute attribute : entity.getAttributes() ) {
          if ( attribute.getUnique() ) {
            String refName = attribute.getJavaName().getReferenceConstant( referencePrefix );

            implementationClass.addField(
                refName,
                "The reference constant for " + instance.get( instance.get( "nameAttributeName" ) ) + " instance " + attribute.getJavaName().getAsDescription() + ".",
                EJavaAccessibility.PUBLIC,
                true,
                true,
                JavaModelGeneratorUtilities.getType( rootPackage, attribute ),
                attribute.getDataType().valueForJava( instance.get( attribute.getJavaName().getAsIdentifier() ) )
            );
          }
        }
      }
    }
  }

  private static void defineAttributes(
      JavaRootPackage rootPackage, Entity entity, JavaClass implementationClass
  ) {
    for ( Attribute attribute : entity.getAttributes() ) {
      JavaType fieldType = JavaModelGeneratorUtilities.getType( rootPackage, attribute );
      String fieldName = attribute.getJavaName().getField();
      String paramName = attribute.getJavaName().getSetterParameter();

      // attribute field
      JavaField field = implementationClass.addField(
          fieldName,
          attribute.getDescription() + ".",
          EJavaAccessibility.PRIVATE,
          false,
          false,
          fieldType,
          attribute.getDataType().valueForJava( attribute.getDefaultValue() )
      );

      field.addAnnotation(
          "",
          rootPackage.findAnnotationInterface( "javax.persistence.Column" ),
          "name = \"" + attribute.getSqlName().getColumn() + "\"" );

      if ( attribute.getDataType().equals( DataType.timeStampDataType ) ) {
        field.addAnnotation(
            "",
            rootPackage.findAnnotationInterface( "javax.persistence.Temporal" ),
            "TemporalType.TIMESTAMP" );
        field.importForCode( rootPackage.findComponent( "javax.persistence.TemporalType" ) );
      }
      else if ( attribute.getDataType().equals( DataType.dateDataType ) ) {
        field.addAnnotation(
            "",
            rootPackage.findAnnotationInterface( "javax.persistence.Temporal" ),
            "TemporalType.DATE" );
        field.importForCode( rootPackage.findComponent( "javax.persistence.TemporalType" ) );
      }

      // attribute getter
      implementationClass.addMethod(
          attribute.getJavaName().getGetter(),
          "@return the value of " + attribute.getDescription() + ".",
          EJavaAccessibility.PUBLIC,
          false,
          false,
          false,
          fieldType,
          "    return this." + fieldName + ";"
      );

      // attribute setter
      JavaMethod setter = implementationClass.addMethod(
          attribute.getJavaName().getSetter(),
          "Changes the value of " + attribute.getDescription() + ".",
          EJavaAccessibility.PUBLIC,
          false,
          false,
          false,
          JavaBuiltinType.VOID,
          "    this.trackChange( this." + fieldName + ", " + paramName + " );\r\n" +
          "    this." + fieldName + " = " + paramName + ";"
      );
      setter.addParameter( paramName, "The new value for " + attribute.getJavaName().getAsDescription() + ".", fieldType );
    }
  }

  private static void defineSerializationVersionField( JavaClass implementationClass ) {
    implementationClass.addField(
        "serialVersionUID",
        "Serialization version number.",
        EJavaAccessibility.PRIVATE,
        true,
        true,
        JavaBuiltinType.LONG,
        "1L" );
  }

  private static void defineBaseClass(
      JavaRootPackage rootPackage, Entity entity, JavaClass implementationClass
  ) {
    if ( entity.getBaseClass() == null ) {
      implementationClass.setBaseClass( (JavaClass) rootPackage
          .findComponent( "gov.senate.transaact.jpa.datamodel.JpaDomainModelEntity" ) );
    }
    else {
      implementationClass.setBaseClass( (JavaClass) rootPackage.findComponent( entity
          .getBaseClass().getJavaName().getImplementationClassFullyQualified() ) );
    }
  }

  private static void defineClassAnnotations(
      JavaRootPackage rootPackage, Entity entity, JavaClass implementationClass
  ) {
    implementationClass.addAnnotation(
        "",
        rootPackage.findAnnotationInterface( "javax.persistence.Entity" ),
        null );
    implementationClass.addAnnotation(
        "",
        rootPackage.findAnnotationInterface( "javax.persistence.Table" ),
        "name = \"" + entity.getSqlName().getTable() + "\"" );
  }

}
