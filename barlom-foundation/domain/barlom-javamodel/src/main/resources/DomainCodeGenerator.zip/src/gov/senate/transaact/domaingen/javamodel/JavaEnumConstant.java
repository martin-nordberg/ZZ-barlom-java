
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaEnumConstant
  extends JavaMember {

  /**
   * Constructs a new field.
   * @param parent
   * @param name
   * @param description
   */
  JavaEnumConstant(
      JavaEnumeration parent,
      String name,
      String description,
      Integer uniqueId,
      String parametersCode,
      String referencePrefix ) {
    super(
        parent,
        name,
        description,
        EJavaAccessibility.PUBLIC,
        true,
        true,
        new JavaReferenceType( parent ) );

    this.parametersCode = parametersCode;
    this.uniqueId = uniqueId;
    this.referencePrefix = referencePrefix;

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public JavaEnumeration getParent() {
    return (JavaEnumeration) super.getParent();
  }

  public String getRawName() {
    String result = super.getName();
    return result;
  }

  public String getParametersCode() {
    return this.parametersCode;
  }

  public String getReferencePrefix() {
    return this.referencePrefix;
  }

  public Integer getUniqueId() {
    return this.uniqueId;
  }

  private String parametersCode;

  private String referencePrefix;

  private final Integer uniqueId;
}
