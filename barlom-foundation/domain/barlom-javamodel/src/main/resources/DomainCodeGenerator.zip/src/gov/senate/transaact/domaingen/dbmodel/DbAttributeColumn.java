
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbAttributeColumn
  extends DbTableColumn {

  /**
   * Constructs a new attribute column.
   */
  DbAttributeColumn(
      DbTable parent,
      String name,
      String attributeName,
      String description,
      EDbDataType type,
      Integer size,
      Integer precision,
      Boolean isNullable,
      Object defaultValue ) {
    super( parent, name, description, type, size, precision, isNullable, defaultValue );

    this.attributeName = attributeName;

    parent.onAddChild( this );
  }

  /** Returns the attributeName. */
  public String getAttributeName() {
    return this.attributeName;
  }

  private String attributeName;

}
