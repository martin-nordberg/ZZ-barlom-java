
package gov.senate.transaact.domaingen;

/** Base class writes its output with indenting support(). */
class IndentingWriter {

  /** The encapsulated output for this writer (any type that accepts "<<"). */
  private def xxoutput = new StringBuffer();
  
  /** The encapsulated output for the current line. */
  private def currentLine = new StringBuilder();
  
  /** The current indent level. */
  protected int indent = 0;
  
  /** The number of spaces for each indent level. */
  private static int INDENT_SIZE = 2;
  
  /** Indents the current line one extra level. */
  protected def indent() {
    currentLine << ' ' * INDENT_SIZE;
    return '';
  }

  /** Returns the output with a new indent already in place (call once per line). */
  protected def nextLine() {
    
    // trim trailing spaces from prior line
    while ( currentLine.length() > 0 && currentLine.charAt( currentLine.length() - 1 ) == ' ' ) {
      currentLine.setLength( currentLine.length() - 1 );
    }

    // output the line
    xxoutput << currentLine << '\r\n';
    currentLine = new StringBuffer();
    
    // start the next line
    currentLine << ' ' * ( indent * INDENT_SIZE );
    return currentLine;
  }

  /** Returns the output (continuing the current line). */
  protected def sameLine() {
    return currentLine;
  }

  protected def closeOutput() {

    // output the last line
    if ( currentLine.length() > 0 ) {
      nextLine();
    }

    xxoutput.close();
  }

  protected def setOutput( output ) {
    xxoutput = output;
  }
}
