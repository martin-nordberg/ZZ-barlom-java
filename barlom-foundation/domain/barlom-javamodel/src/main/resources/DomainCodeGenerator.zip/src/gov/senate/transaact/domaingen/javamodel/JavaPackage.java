
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GDIT, Inc.
 */
public class JavaPackage
  extends JavaAbstractPackage {

  /**
   * Constructs a new Java package.
   * @param parent
   * @param name
   * @param description
   */
  JavaPackage(
      JavaAbstractPackage parent,
      String name,
      String description,
      Boolean isImplicitlyImported ) {
    super( parent, name, description );

    this.isImplicitlyImported = isImplicitlyImported;

    this.classes = new ArrayList<JavaClass>();
    this.components = new ArrayList<JavaComponent>();
    this.enumerations = new ArrayList<JavaEnumeration>();
    this.interfaces = new ArrayList<JavaInterface>();
    this.annotationInterfaces = new ArrayList<JavaAnnotationInterface>();

    parent.onAddChild( this );
  }

  /** Creates an annotation interface within this package. */
  public JavaAnnotationInterface addAnnotationInterface( String name, String description ) {
    return new JavaAnnotationInterface( this, name, description );
  }

  /** Creates a class within this package. */
  public JavaClass addClass(
      String name,
      String description,
      Boolean isAbstract,
      Boolean isFinal,
      JavaClass baseClass,
      Boolean isTestCode ) {
    return new JavaClass(
        this,
        name,
        description,
        false,
        isAbstract,
        isFinal,
        baseClass,
        isTestCode );
  }

  /** Creates an enumeration within this package. */
  public JavaEnumeration addEnumeration( String name, String description, Boolean isExternal ) {
    return new JavaEnumeration( this, name, description, isExternal );
  }

  /** Creates a class within this package only for reference by other classes. */
  public JavaClass addExternalClass( String name ) {
    return new JavaClass( this, name, "", true, false, false, null, false );
  }

  /** Creates an interface within this package. */
  public JavaInterface addExternalInterface( String name ) {
    return new JavaInterface( this, name, "", true );
  }

  /** Creates an interface within this package. */
  public JavaInterface addInterface( String name, String description ) {
    return new JavaInterface( this, name, description, false );
  }

  /** Given a qualified name relative to this package, find the needed component. */
  @Override
  public JavaAnnotationInterface findAnnotationInterface( String relativeQualifiedName ) {

    // split the relative path into first and rest
    if ( relativeQualifiedName.indexOf( "." ) > 0 ) {
      return super.findAnnotationInterface( relativeQualifiedName );
    }

    // look for an existing component
    for ( JavaAnnotationInterface annotationInterface : this.annotationInterfaces ) {
      if ( annotationInterface.getJavaName().equals( relativeQualifiedName ) ) {
        return annotationInterface;
      }
    }

    return null;
  }

  /** Given a qualified name relative to this package, find the needed component. */
  @Override
  public JavaComponent findComponent( String relativeQualifiedName ) {

    // split the relative path into first and rest
    if ( relativeQualifiedName.indexOf( "." ) > 0 ) {
      return super.findComponent( relativeQualifiedName );
    }

    // look for an existing component
    for ( JavaComponent component : this.components ) {
      if ( component.getJavaName().equals( relativeQualifiedName ) ) {
        return component;
      }
    }

    return null;
  }

  /** Returns the annotation interfaces within this package. */
  public List<JavaAnnotationInterface> getAnnotationInterfaces() {
    return this.annotationInterfaces;
  }

  /** Returns the classes within this package. */
  public List<JavaClass> getClasses() {
    return this.classes;
  }

  /** Returns the components within this package. */
  public List<JavaComponent> getComponents() {
    return this.components;
  }

  /** Returns the enumerations within this package. */
  public List<JavaEnumeration> getEnumerations() {
    return this.enumerations;
  }

  /** Returns the interfaces within this package. */
  public List<JavaInterface> getInterfaces() {
    return this.interfaces;
  }

  /** Returns the isImplicitlyImported. */
  public Boolean getIsImplicitlyImported() {
    return this.isImplicitlyImported;
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaAnnotationInterface child ) {
    super.onAddChild( child );
    this.annotationInterfaces.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaClass child ) {
    this.onAddChild( (JavaComponent) child );
    this.classes.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaComponent child ) {
    super.onAddChild( child );
    this.components.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaEnumeration child ) {
    this.onAddChild( (JavaComponent) child );
    this.enumerations.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaInterface child ) {
    this.onAddChild( (JavaComponent) child );
    this.interfaces.add( child );
  }

  private List<JavaAnnotationInterface> annotationInterfaces;

  private List<JavaClass> classes;

  private List<JavaComponent> components;

  private List<JavaEnumeration> enumerations;

  private List<JavaInterface> interfaces;

  private Boolean isImplicitlyImported;

}
