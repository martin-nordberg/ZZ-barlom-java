
package gov.senate.transaact.domaingen.dbmodel;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Vangent, Inc.
 */
public abstract class DbConstraint
  extends DbNamedModelElement {

  /**
   * Constructs a new constraint.
   */
  DbConstraint(
      DbTable parent,
      String name,
      String description,
      List<DbTableColumn> constrainedColumns ) {
    super( parent, name, description );

    this.constrainedColumns = constrainedColumns;
  }

  /**
   * Makes a list from one column
   * @param column
   */
  static List<DbTableColumn> makeListOfOneColumn( DbTableColumn column ) {
    List<DbTableColumn> result = new ArrayList<>();
    result.add( column );
    return result;
  }

  /**
   * Makes a list from two columns
   * @param column
   */
  static List<DbTableColumn> makeListOfTwoColumns( DbTableColumn column1, DbTableColumn column2 ) {
    List<DbTableColumn> result = new ArrayList<DbTableColumn>();
    result.add( column1 );
    result.add( column2 );
    return result;
  }

  /** Returns the constrainedColumns. */
  public List<DbTableColumn> getConstrainedColumns() {
    return this.constrainedColumns;
  }

  /** {@inheritDoc} */
  @Override
  public DbTable getParent() {
    return (DbTable) super.getParent();
  }

  private List<DbTableColumn> constrainedColumns;
}
