
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbForeignKeyConstraint
  extends DbConstraint {

  /**
   * Constructs a new primary key constraint.
   */
  DbForeignKeyConstraint(
      DbTable parent,
      String name,
      String description,
      DbTableColumn foreignKeyColumn,
      DbTable relatedTable,
      Boolean isCascadeDelete ) {
    super( parent, name, description, DbConstraint.makeListOfOneColumn( foreignKeyColumn ) );

    assert relatedTable != null : "Missing related table for " + parent.getSqlName() + "."
        + name;

    this.relatedTable = relatedTable;
    this.isCascadeDelete = isCascadeDelete;

    if ( foreignKeyColumn instanceof DbForeignKeyColumn ) {
      ( (DbForeignKeyColumn) foreignKeyColumn ).setRelatedTable( relatedTable );
    }

    parent.onAddChild( this );
  }

  /** Returns the isCascadeDelete. */
  public Boolean getIsCascadeDelete() {
    return this.isCascadeDelete;
  }

  /** Returns the relatedTable. */
  public DbTable getRelatedTable() {
    return this.relatedTable;
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( "FK", this.getParent().getName(), this.getName() );
  }

  private Boolean isCascadeDelete;

  private DbTable relatedTable;
}
