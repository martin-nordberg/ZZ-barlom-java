package gov.senate.transaact.domaingen.javamodel;

/**
 * Interface for elements that have a Java type.
 */
public interface IJavaTyped {

  /** @return the type of this element. */
  JavaType makeJavaType();

}
