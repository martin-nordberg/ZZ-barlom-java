
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbPrimaryKeyColumn
  extends DbTableColumn {

  /**
   * Constructs a new primary key column
   * @param parent
   * @param name
   */
  DbPrimaryKeyColumn( DbTable parent, String name ) {
    super( parent, name, "primary key", EDbDataType.INTEGER, 0, 0, false, null );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public DbTable getParent() {
    return (DbTable) super.getParent();
  }

}
