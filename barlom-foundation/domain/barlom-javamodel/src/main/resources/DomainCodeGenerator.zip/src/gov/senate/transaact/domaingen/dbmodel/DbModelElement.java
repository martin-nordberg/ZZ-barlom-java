
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public abstract class DbModelElement {

  /**
   * Constructs a new database model element
   * @param parent The parent of this model element.
   */
  protected DbModelElement( DbNamedModelElement parent, String description ) {
    super();
    this.parent = parent;
    this.description = description;
  }

  /** Returns the description. */
  public String getDescription() {
    return this.description;
  }

  /** Returns the parent. */
  public DbNamedModelElement getParent() {
    return this.parent;
  }

  /** Returns the schema (top level parent). */
  public DbSchema getSchema() {
    return this.parent.getSchema();
  }

  private String description;

  private DbNamedModelElement parent;
}
