
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Abstract class to write Java code for a domain. */
abstract class JavaEntitiesWriter
extends JavaCodeWriter {

  /** Returns the name of the class for a given entity. */
  protected abstract String getClassName( Entity entity );

  /** Determines whether a given entity needs to be written. */
  protected boolean isWriteable( Entity entity ) {
    return true;
  }

  /** Writes the implementation of an attribute field. */
  protected void writeAttributeImplementation( String description, DataType dataType, JavaName attributeName, SqlName sqlName ) {
    nextLine() << '/** ' << description << '. */';
    nextLine() << '@Column( name = "' << sqlName.column << '" )';
    if ( dataType.isDateType ) {
      nextLine() << '@Temporal( TemporalType.' << dataType.sqlName.asIdentifier << ' )';
    }
    nextLine() << 'private ' << dataType.javaName.asIdentifier << ' ' << attributeName.field << ';';
    nextLine();
    nextLine() << '/** @return the value of ' << description << '. */';
    nextLine() << 'public ' << dataType.javaName.asIdentifier << ' ' << attributeName.getter << '() {';
    nextLine() << indent() << 'return this.' << attributeName.field << ';';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << description << '.';
    nextLine() << ' * @param ' << attributeName.setterParameter << ' The new value for ' << attributeName.asDescription << '.';
    nextLine() << ' */';
    nextLine() << 'public void ' << attributeName.setter << '( ' << dataType.javaName.asIdentifier << ' ' << attributeName.setterParameter << ' ) {';
    nextLine() << indent() << 'this.' << attributeName.field << ' = ' << ' ' << attributeName.setterParameter << ';';
    nextLine() << '}';
    nextLine();
  }

  /** Writes the Java code for entities in a given domain. */
  void writeDomain( Domain domain ) {

    domain.entities.each {
      if ( isWriteable( it ) ) {
        // open the source file
        File srcFile = new File( sourceFolder, getClassName( it ) + ".java" )
        setOutput( new FileRewriter( srcFile ) );

        // write the output
        writeEntity( it );

        // close the output
        closeOutput();
      }
    }
  }

  /** Writes the code for a given entity. */
  protected abstract void writeEntity( Entity entity );

  /** Writes a relationship field implementation. */
  protected void writeRelationshipImplementation( String description, boolean required, boolean aggregated, JavaName relationshipName, JavaName entityName, JavaName relatedEntityName, SqlName sqlName ) {
    nextLine() << '/** ' << description << '. */';
    nextLine() << '@ManyToOne( optional = ' << ( required ? 'false':'true' ) << ' )';
    nextLine() << '@JoinColumn( name = "' << sqlName.column << '" )';
    nextLine() << 'private ' << relatedEntityName.implementationClass << ' ' << relationshipName.field << ';';
    nextLine();
    nextLine() << '/** @return the value of ' << description << '. */';
    nextLine() << 'public ' << relatedEntityName.implementationClass << ' ' << relationshipName.getter << '() {';
    nextLine() << indent() << 'return this.' << relationshipName.field << ';';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << description << '.';
    nextLine() << ' * @param ' << relationshipName.setterParameter << ' The new value for ' << relationshipName.asDescription << '.';
    nextLine() << ' */';
    nextLine() << 'public void ' << relationshipName.setter << '( ' << relatedEntityName.implementationClass << ' ' << relationshipName.setterParameter << ' ) {';
    ++indent;
    nextLine() << 'this.' << relationshipName.field << ' = ' << relationshipName.setterParameter << ';';
    if ( aggregated ) {
      nextLine() << relationshipName.setterParameter << '.' << entityName.adder << '( this );';
    }
    --indent;
    nextLine() << '}';
    nextLine();
  }
}