
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaAnnotation
  extends JavaModelElement {

  /**
   * Constructs a new annotation (usage).
   * @param parent
   * @param description
   */
  JavaAnnotation(
      JavaAnnotatableModelElement parent,
      String description,
      JavaAnnotationInterface annotationInterface,
      String parametersCode ) {
    super( parent, description );

    this.annotationInterface = annotationInterface;
    this.parametersCode = parametersCode;

    parent.onAddChild( this );
  }

  /** @return the annotationInterface. */
  public JavaAnnotationInterface getAnnotationInterface() {
    return this.annotationInterface;
  }

  /** @return the parametersCode. */
  public String getParametersCode() {
    return this.parametersCode;
  }

  /** {@inheritDoc} */
  @Override
  public JavaAnnotatableModelElement getParent() {
    return (JavaAnnotatableModelElement) super.getParent();
  }

  private JavaAnnotationInterface annotationInterface;

  private String parametersCode;

}
