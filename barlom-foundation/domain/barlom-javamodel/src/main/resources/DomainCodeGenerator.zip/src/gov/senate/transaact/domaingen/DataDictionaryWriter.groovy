
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Writes a data dictionary in CSV format. **/
class DataDictionaryWriter
extends IndentingWriter {

  /** Writes the data dictionary for a domain. */
  void writeDomain( Domain domain ) {

    nextLine() << 'DOMAIN:,' << domain.name;
    nextLine() << 'SQL SCHEMA:,' << domain.sqlName.schema;
    nextLine() << 'JAVA PACKAGE:,' << domain.javaName.implementationPackage;
    nextLine() << 'DATA MODEL FACTORY:,' << domain.javaName.dataModelFactoryClassFullyQualified;
    nextLine();
    nextLine();
    nextLine() << 'ENTITY,TABLE,JAVA INTERFACE,BASE CLASS,TEMPORAL?,VALIDATOR?, , ,DESCRIPTION,NATURAL SORT';

    domain.entities.each { entity ->
      writeEntitySummary( entity );
    }

    nextLine();
    nextLine();
    nextLine() << 'ENTITY,COLUMN,FIELD,TYPE,TEMPORAL?,MAX LENGTH,DEFAULT,REQUIRED?,UNIQUE?,DESCRIPTION';

    domain.entities.each { entity ->
      writeEntityFields( entity );
    }
  }

  /** Writes an entity to the data dictionary. */
  private void writeEntitySummary( Entity entity ) {
    nextLine() << entity.name << ',';
    sameLine() << entity.sqlName.table << ',';
    sameLine() << entity.javaName.implementationClass << ',';
    sameLine() << ( entity.baseClass != null ? entity.baseClass.javaName.implementationClass : ' ' ) << ',';
    sameLine() << ( entity.temporal ? 'Y' : ' ' ) << ',';
    sameLine() << ( entity.hasValidator ? 'Y' : ' ' ) << ',';
    sameLine() << ' ' << ',';
    sameLine() << ' ' << ',';
    sameLine() << '"' << entity.description << '",';
    sameLine() << '"' << ( entity.naturalSort == 'uniqueId' ? ' ' : entity.naturalSort ) << '",';
  }

  /** Writes an entity's fields to the data dictionary. */
  private void writeEntityFields( Entity entity ) {

    entity.relationships.each { relationship ->
      nextLine() << entity.name << ',';
      sameLine() << relationship.sqlName.column << ',';
      sameLine() << relationship.name << ',';
      sameLine() << relationship.relatedEntity.name << ',';
      sameLine() << ( relationship.temporal ? 'Y' : ' ' ) << ',';
      sameLine() << ' ' << ',';
      sameLine() << ' ' << ',';
      sameLine() << ( relationship.required ? 'Y' : ' ' ) << ',';
      sameLine() << ' ' << ',';
      sameLine() << '"' << relationship.description << '",';
    }
    entity.attributes.each { attribute ->
      nextLine() << entity.name << ',';
      sameLine() << attribute.sqlName.column << ',';
      sameLine() << attribute.name << ',';
      sameLine() << attribute.dataType.name << ',';
      sameLine() << ( attribute.temporal ? 'Y' : ' ' ) << ',';
      sameLine() << ( attribute.maxLength ? attribute.maxLength : ' ' ) << ',';
      sameLine() << ( attribute.defaultValue != null ? attribute.dataType.valueForJava(attribute.defaultValue) : ' ' ) << ',';
      sameLine() << ( attribute.required ? 'Y' : ' ' ) << ',';
      sameLine() << ( attribute.unique ? 'Y' : ' ' ) << ',';
      sameLine() << '"' << attribute.description << '",';
    }

    if ( !entity.attributes && !entity.relationships ) {
      nextLine() << entity.name << ',';
      sameLine() << '(no attributes or relationships)' << ',';
    }

    nextLine();
  }
}
