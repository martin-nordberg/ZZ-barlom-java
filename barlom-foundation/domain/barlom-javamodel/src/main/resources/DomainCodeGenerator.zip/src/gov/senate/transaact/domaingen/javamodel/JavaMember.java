
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaMember
  extends JavaTypedModelElement {

  /**
   * Constructs a new member.
   * @param parent
   * @param name
   * @param description
   */
  protected JavaMember(
      JavaComponent parent,
      String name,
      String description,
      EJavaAccessibility accessibility,
      Boolean isStatic,
      Boolean isFinal,
      JavaType type ) {
    super( parent, name, description, type );

    this.accessibility = accessibility;
    this.isStatic = isStatic;
    this.isFinal = isFinal;
  }

  /** @return the accessibility of this method. */
  public EJavaAccessibility getAccessibility() {
    return this.accessibility;
  }

  /** Returns the isFinal. */
  public Boolean getIsFinal() {
    return this.isFinal;
  }

  /** @return whether this is a static method. */
  public Boolean getIsStatic() {
    return this.isStatic;
  }

  /** @return the parent of this field. */
  @Override
  public JavaComponent getParent() {
    return (JavaComponent) super.getParent();
  }

  private EJavaAccessibility accessibility;

  private Boolean isFinal;

  private Boolean isStatic;

}
