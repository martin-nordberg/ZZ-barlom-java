
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** This abstract base class writes a persistence.xml file. **/
abstract class PersistenceXmlWriter
extends IndentingWriter {

  /** Writes the opening portion of the XML with the persistence unit name. */
  protected abstract void writeFileHeader( String jpaPersistenceUnit );

  /** Writes the closing properties portion of the XML. */
  protected abstract void writeFileFooter( List<Domain> domains );

  /** Writes the persistence.xml code for a domain. */
  public void writeDomains( String jpaPersistenceUnit,
  List<Domain> domains       ) {

    // opening persistence unit declaration
    writeFileHeader( jpaPersistenceUnit );

    // list of entities
    domains.each { domain ->
      nextLine();
      nextLine() << '<!-- ' << domain.name << ' -->';
      def sortedEntities = domain.entities.sort { e1,e2 -> e1.name <=> e2.name }
      sortedEntities.each { entity ->
        if ( !entity.enumerated ) {
          nextLine() << '<class>' << entity.javaName.implementationClassFullyQualified << '</class>';
        }
        if ( entity.temporal ) {
          nextLine() << '<class>' << entity.javaName.changeImplementationClassFullyQualified << '</class>';
        }
      }
    }

    // closing properties
    writeFileFooter( domains );
  }
}
