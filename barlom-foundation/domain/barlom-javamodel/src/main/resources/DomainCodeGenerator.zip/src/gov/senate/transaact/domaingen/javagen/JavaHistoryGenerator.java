
package gov.senate.transaact.domaingen.javagen;

import gov.senate.transaact.domaingen.javamodel.JavaClass;
import gov.senate.transaact.domaingen.javamodel.JavaPackage;
import gov.senate.transaact.domaingen.model.Entity;

/**
 * @author GDIT, Inc.
 */
public class JavaHistoryGenerator {

  /**
   * @param javaRootPackage
   * @param historyPackage
   * @param entity
   */
  static void addEmptyHistoryClass( JavaPackage historyPackage, Entity entity ) {
    JavaClass historyClass = historyPackage.addClass(
        entity.getJavaName().getChangeImplementationClass(),
        entity.getDescription(),
        false,
        !entity.isAbztract(),
        null /* TBD */,
        false );

  }

  /**
   * @param javaRootPackage
   * @param historyPackage
   * @param entity
   */
  static void defineHistoryClass( JavaPackage historyPackage, Entity entity ) {

    JavaClass historyClass = (JavaClass) historyPackage.findComponent( entity.getJavaName()
        .getChangeImplementationClass() );

    assert historyClass != null;
  }

}
