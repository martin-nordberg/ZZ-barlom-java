
package gov.senate.transaact.domaingen.javagen;

import gov.senate.transaact.domaingen.javamodel.JavaPackage;
import gov.senate.transaact.domaingen.javamodel.JavaRootPackage;
import gov.senate.transaact.domaingen.model.Domain;
import gov.senate.transaact.domaingen.model.Entity;

/**
 * @author GDIT, Inc.
 */
public class JavaModelGenerator {

  /** Un-instanced static utility class. */
  private JavaModelGenerator() {
  }

  /** Generates the corresponding database domain for a model domain. */
  public static void generateDomain( Domain domain, JavaRootPackage javaRootPackage ) {

    JavaPackage transaactPackage = javaRootPackage.findOrCreatePackage( "gov.senate.transaact" );
    JavaPackage subsystemPackage = transaactPackage.findOrCreatePackage( domain.getJavaName()
        .getAsPackage() );

    JavaPackage domainModelPackage = subsystemPackage.findOrCreatePackage( "domainmodel" );
    JavaPackage historyPackage = domainModelPackage.findOrCreatePackage( "history" );
    JavaPackage validationPackage = domainModelPackage.findOrCreatePackage( "validators" );
    JavaPackage queriesPackage = subsystemPackage.findOrCreatePackage( "queries" );

    for ( Entity entity : domain.getEntities() ) {
      JavaModelGenerator.addEmptyClasses(
          domainModelPackage,
          historyPackage,
          validationPackage,
          queriesPackage,
          entity );
    }

    for ( Entity entity : domain.getEntities() ) {
      JavaModelGenerator.defineClasses(
          domainModelPackage,
          historyPackage,
          validationPackage,
          queriesPackage,
          entity );
    }
  }

  /**
   * Generates the root package and all its standard Java contents.
   * @return The newly created root package.
   */
  public static JavaRootPackage generateRootPackageAndJavaLibs() {
    JavaRootPackage result = new JavaRootPackage();

    // java.lang
    JavaPackage javaPackage = result.addPackage( "java", "", true );
    JavaModelGenerator.generateJavaLangPackage( javaPackage );
    JavaModelGenerator.generateJavaUtilPackage( javaPackage );

    // javax.persistence
    JavaPackage javaxPackage = result.addPackage( "javax", "", false );
    JavaModelGenerator.generateJavaxPersistencePackage( javaxPackage );

    // gov.senate.transaact.jpa.datamodel
    JavaPackage govPackage = result.addPackage( "gov", "", false );
    JavaPackage senatePackage = govPackage.addPackage( "senate", "", false );
    JavaPackage transaactPackage = senatePackage.addPackage( "transaact", "", false );
    JavaModelGenerator.generateTranSAActJpaDataModelPackage( transaactPackage );

    return result;
  }

  /**
   * First pass of model generation creates empty classes for all model entities.
   */
  private static void addEmptyClasses(
      JavaPackage domainModelPackage,
      JavaPackage historyPackage,
      JavaPackage validationPackage,
      JavaPackage queriesPackage,
      Entity entity ) {
    if ( entity.isEnumerated() ) {
      JavaEnumerationGenerator.addEmptyEnumeration( domainModelPackage, entity );
    }
    else {
      JavaImplementationGenerator.addEmptyImplementationClass( domainModelPackage, entity );

      if ( entity.isTemporal() ) {
        JavaHistoryGenerator.addEmptyHistoryClass( historyPackage, entity );
      }
    }
  }

  /**
   * Second pass of model generation fills in class members.
   */
  private static void defineClasses(
      JavaPackage domainModelPackage,
      JavaPackage historyPackage,
      JavaPackage validationPackage,
      JavaPackage queriesPackage,
      Entity entity ) {
    if ( entity.isEnumerated() ) {
      JavaEnumerationGenerator.defineEnumeration( domainModelPackage, entity );
    }
    else {
      JavaImplementationGenerator.defineImplementationClass( domainModelPackage, entity );

      if ( entity.isTemporal() ) {
        JavaHistoryGenerator.defineHistoryClass( historyPackage, entity );
      }
    }
  }

  /**
   * Generates the java.lang package as needed by the code generator.
   */
  private static void generateJavaLangPackage( JavaPackage javaPackage ) {
    JavaPackage langPackage = javaPackage.addPackage( "lang", "", true );
    langPackage.addExternalClass( "Boolean" );
    langPackage.addExternalClass( "Double" );
    langPackage.addExternalClass( "Integer" );
    langPackage.addExternalClass( "Long" );
    langPackage.addExternalClass( "String" );
    langPackage.addExternalClass( "byte[]" );

    langPackage.addAnnotationInterface( "Override", "Overrides a base class method." );
  }

  /**
   * Generates the java.util package as needed by the code generator.
   */
  private static void generateJavaUtilPackage( JavaPackage javaPackage ) {
    JavaPackage utilPackage = javaPackage.addPackage( "util", "", false );
    utilPackage.addExternalClass( "ArrayList" );
    utilPackage.addExternalClass( "Date" );
    utilPackage.addExternalInterface( "List" );
  }

  /**
   * Generates the java.lang package as needed by the code generator.
   */
  private static void generateJavaxPersistencePackage( JavaPackage javaxPackage ) {
    JavaPackage persistencePackage = javaxPackage.addPackage( "persistence", "", false );
    persistencePackage.addAnnotationInterface( "Column", "JPA annotation for database column" );
    persistencePackage.addAnnotationInterface( "Date", "JPA annotation for date values" );
    persistencePackage.addAnnotationInterface( "Entity", "JPA annotation for an entity class" );
    persistencePackage.addAnnotationInterface( "GeneratedValue", "JPA annotation for sequence generator mechanism" );
    persistencePackage.addAnnotationInterface( "Id", "JPA annotation for unique ID" );
    persistencePackage.addAnnotationInterface( "SequenceGenerator", "JPA annotation for a unique ID sequence generator" );
    persistencePackage.addAnnotationInterface( "Table", "JPA annotation for database table" );
    persistencePackage.addAnnotationInterface( "Temporal", "JPA annotation for time values" );

    persistencePackage.addExternalClass( "GenerationType" );
    persistencePackage.addExternalClass( "TemporalType" );
  }

  /**
   * Generates the java.lang package as needed by the code generator.
   */
  private static void generateTranSAActJpaDataModelPackage( JavaPackage transaactPackage ) {
    JavaPackage jpaPackage = transaactPackage.addPackage( "jpa", "", false );
    JavaPackage datamodelPackage = jpaPackage.addPackage( "datamodel", "", false );
    datamodelPackage.addClass(
        "JpaDomainModelEntity",
        "Common persistence base class",
        true,
        false,
        null,
        false );
  }

}
