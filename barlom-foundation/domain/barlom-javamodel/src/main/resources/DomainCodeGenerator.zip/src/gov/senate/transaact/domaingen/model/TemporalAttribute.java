
package gov.senate.transaact.domaingen.model;

/**
 * A Java field and corresponding SQL non-key column that is stored in the database such that its
 * values are tracked over time.
 */
public class TemporalAttribute
  extends Attribute {

  /** Whether changes to this attribute over time are stored for later recall. */
  @Override
  public boolean isTemporal() {
    return true;
  }

  /** Validates this attribute. */
  @Override
  public void validate() {
    super.validate();
    assert this.getParent().isTemporal() : "Temporal attribute " + this.getName()
        + " must be in a temporal entity.";
    assert !this.getObfuscated() : "Support for temporal obfuscated attributes not implemented.";
  }
}
