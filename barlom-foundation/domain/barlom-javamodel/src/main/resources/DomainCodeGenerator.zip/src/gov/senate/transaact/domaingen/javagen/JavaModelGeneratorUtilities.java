
package gov.senate.transaact.domaingen.javagen;

import gov.senate.transaact.domaingen.javamodel.JavaComponent;
import gov.senate.transaact.domaingen.javamodel.JavaRootPackage;
import gov.senate.transaact.domaingen.javamodel.JavaType;
import gov.senate.transaact.domaingen.model.Attribute;

/**
 * @author GDIT, Inc.
 */
public class JavaModelGeneratorUtilities {

  /**
   * Looks up the type of an attribute.
   * @param javaRootPackage The root package to search within.
   * @param attribute The attribute whose type is needed.
   * @return The Java type found.
   */
  static JavaType getType( JavaRootPackage rootPackage, Attribute attribute ) {
    String typeName;
    if ( attribute.getDataType().getIsDateType() ) {
      typeName = "java.util.Date";
    }
    else {
      typeName = "java.lang." + attribute.getDataType().getName();
    }

    JavaComponent component = rootPackage.findComponent( typeName );

    assert component != null : typeName;

    return component.makeJavaType();
  }

}
