
package gov.senate.transaact.domaingen;

/**
 * Class mimicking FileWriter, but does not change a file if the output content matches the 
 * file's current content.
 * @author Vangent, Inc. [MN]
 */
public class FileRewriter
extends Writer {
  
  /** Token that starts the lines delimiting a hand-written section of code */
  public static final String HAND_WRITTEN_CODE_TOKEN = "// ###";
  
  /** Constructs a new file rewriter to the given file. */
  public FileRewriter( File file ) {
    this.file = file;
    writer = new StringWriter();
  }
  
  /** 
   * Closes the file writer: compares the intended output against current file contents
   * and writes the output only if changed.
   */
  public void close() throws IOException {
    
    boolean rewrite = false;
    
    // get the new content for the file
    String newContent = writer.toString();
    
    try {
      // read the current content of the file
      FileReader reader = new FileReader( this.file );
      String oldContent = reader.getText();
      reader.close();
      
      newContent = processHandWrittenElements( newContent, oldContent );
      
      // rewrite if the content has changed
      if ( !newContent.equals( oldContent ) ) {
        rewrite  = true;
      }
    }
    catch ( IOException e ) {
      // rewrite if failed to read
      rewrite = true;
    }
    
    // write the real file if its contents have changed
    if ( rewrite ) {
      // note the changed file to the console
      System.out.println '    ' << this.file.path;
      
      // delete the old file if exists
      if ( this.file.exists() ) {
        this.file.delete();
      }
      
      // write the new contents
      FileWriter outWriter = new FileWriter( this.file );
      outWriter.write( newContent );
      outWriter.close();
    }
  }
  
  /** Flushes the output for this file writer. */
  public void flush() throws IOException {
    writer.flush();
  }
  
  /** Extracts hand-written segments out of the old code into the new. */
  protected String processHandWrittenElements( String newContent, String oldContent ) {
    
    Boolean addToHandWrittenCode = false;
    String lineToReplace = "";
    String handWrittenCode = "";
    
    oldContent.eachLine { line ->
      if ( line.trim().startsWith( HAND_WRITTEN_CODE_TOKEN ) && line.contains( "end" ) ) {
        newContent = newContent.replace( lineToReplace, handWrittenCode );
        addToHandWrittenCode = false;
        handWrittenCode = "";
      }
      else if ( addToHandWrittenCode ) {
        handWrittenCode = handWrittenCode + line + "\r\n"
      }
      else if ( line.trim().startsWith( HAND_WRITTEN_CODE_TOKEN ) && line.contains( "begin" ) ) {
        String name = line.split( ":" )[1].trim();
        lineToReplace = HAND_WRITTEN_CODE_TOKEN + " " + name + "\r\n";
        addToHandWrittenCode = true;
      }
    }
    
    return newContent;
  }
  
  /** Low level writer implementation - writes some bytes to the inner string writer. */
  public void write( char[] cbuf, int off, int len ) throws IOException {
    writer.write( cbuf, off, len );
  }
  
  /** The file to be written if content changes */
  private File file;
  
  /** The place to write out output until we have decided if the content has changed. */
  private StringWriter writer;
  
}
