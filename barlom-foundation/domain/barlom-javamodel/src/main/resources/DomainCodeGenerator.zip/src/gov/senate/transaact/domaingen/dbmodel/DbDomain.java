
package gov.senate.transaact.domaingen.dbmodel;

import java.util.ArrayList;
import java.util.List;

import gov.senate.transaact.domaingen.model.Domain;

/**
 * @author Vangent, Inc.
 */
public class DbDomain
  extends DbNamedModelElement {

  /**
   * Constructs a new schema.
   */
  DbDomain(
      DbSchema parent,
      String name,
      String description,
      boolean hasSqlCustomizations,
      Domain modelDomain ) {
    super( parent, name, description );

    this.tables = new ArrayList<>();
    this.views = new ArrayList<>();
    this.hasSqlCustomizations = hasSqlCustomizations;
    this.modelDomain = modelDomain;

    parent.onAddChild( this );
  }

  /**
   * Creates a new table within this schema.
   */
  public DbTable addTable( String name, String description ) {
    return new DbTable( this, name, description );
  }

  /**
   * Creates a new view within this schema.
   */
  public DbView addView( String name, String description ) {
    return new DbView( this, name, description );
  }

  /**
   * Returns the modelDomain.
   * @deprecated - Used by hybrid generator code still partially based directly on E/R model.
   */
  @Deprecated
  public Domain getModelDomain() {
    return this.modelDomain;
  }

  @Override
  public DbSchema getParent() {
    return (DbSchema) super.getParent();
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( this.getName() );
  }

  /** Returns the tables. */
  public List<DbTable> getTables() {
    return this.tables;
  }

  /** Returns the views. */
  public List<DbView> getViews() {
    return this.views;
  }

  /** Returns true if this domain has additional hand-written SQL DDL. */
  public boolean hasSqlCustomizations() {
    return this.hasSqlCustomizations;
  }

  /** Registers the addition of a table to this domain. */
  void onAddChild( DbTable table ) {
    String tableName = table.getSqlName();

    assert this.getParent().getRelationByName( tableName ) == null : "Duplicate table/view name: "
        + tableName;

    super.onAddChild( table );

    this.getParent().putRelationByName( tableName, table );
    this.tables.add( table );
  }

  /** Registers the addition of a view to this domain. */
  void onAddChild( DbView view ) {
    String viewName = view.getSqlName();

    assert this.getParent().getRelationByName( viewName ) == null : "Duplicate table/view name: "
        + viewName;

    super.onAddChild( view );

    this.getParent().putRelationByName( viewName, view );
    this.views.add( view );
  }

  private boolean hasSqlCustomizations = false;

  private Domain modelDomain;

  private List<DbTable> tables;

  private List<DbView> views;
}
