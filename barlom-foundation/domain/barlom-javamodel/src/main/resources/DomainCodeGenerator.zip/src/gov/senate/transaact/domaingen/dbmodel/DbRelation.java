
package gov.senate.transaact.domaingen.dbmodel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Vangent, Inc.
 */
public abstract class DbRelation
  extends DbNamedModelElement {

  /**
   * Constructs a new table or view.
   */
  DbRelation( DbDomain parent, String name, String description ) {
    super( parent, name, description );

    this.columns = new ArrayList<>();
    this.columnsByName = new HashMap<>();
  }

  /** Returns the columnsByName. */
  public DbColumn getColumnByName( String name ) {
    return this.columnsByName.get( DbNamedModelElement.makeSqlName( name ) );
  }

  /** Returns the columns. */
  public List<DbColumn> getColumns() {
    return this.columns;
  }

  /** @return the parent domain of this relation. */
  @Override
  public DbDomain getParent() {
    return (DbDomain) super.getParent();
  }

  /**
   * Creates a new column within this relation.
   */
  protected void addColumn( DbColumn column ) {
    assert this.columnsByName.get( column.getSqlName() ) == null : "Duplicate column name: "
        + column.getSqlName();

    this.columns.add( column );
    this.columnsByName.put( column.getSqlName(), column );
  }

  /**
   * Creates a new column within this relation.
   */
  void onAddChild( DbColumn column ) {
    String columnName = column.getSqlName();

    assert this.columnsByName.get( columnName ) == null : "Duplicate column name: "
        + columnName;

    super.onAddChild( column );

    this.columns.add( column );
    this.columnsByName.put( columnName, column );
  }

  private List<DbColumn> columns;

  private Map<String, DbColumn> columnsByName;
}
