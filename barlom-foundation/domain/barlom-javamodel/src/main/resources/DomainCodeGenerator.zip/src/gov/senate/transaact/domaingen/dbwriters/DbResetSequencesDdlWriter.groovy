
package gov.senate.transaact.domaingen.dbwriters;

import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbTable
import gov.senate.transaact.domaingen.model.*

/**
 * Writer generates code to define TranSAAct database tables.
 * @author Vangent, Inc.
 */
public class DbResetSequencesDdlWriter
extends DbWriter {

  /** Writes a schema definition to the writer's output. */
  void writeDomain( DbDomain domain ) {

    String title = 'SEQUENCE RESETS FOR ' + domain.sqlName;
    String purpose = 'Resets all sequences in the ' + domain.name + ' domain.'

    writeFileHeader( title, purpose, true );

    nextLine() << '---------------------';
    nextLine() << '-- Reset Sequences --';
    nextLine() << '---------------------';
    nextLine();
    nextLine() << 'DECLARE';
    nextLine() << indent() << 'NEW_SEQ_START INTEGER;';
    nextLine() << 'BEGIN';
    indent++;

    domain.tables.each { table ->
      resetSequence( table );
    }

    indent--;
    nextLine() << 'END;';
    nextLine() << '/';
    nextLine();

    writeFileFooter();
  }

  private void resetSequence( String tableName, String pkName, String sequenceName ) {
    nextLine() << '-- ' << sequenceName;
    nextLine() << 'SELECT GREATEST(10000,NVL(MAX(' << pkName << '),0)+1) INTO NEW_SEQ_START FROM ' << tableName << ';';
    nextLine() << "EXECUTE IMMEDIATE 'DROP SEQUENCE " << sequenceName << "';";
    nextLine() << "EXECUTE IMMEDIATE 'CREATE SEQUENCE " << sequenceName << " START WITH ' || NEW_SEQ_START;";
    nextLine() << "DBMS_OUTPUT.PUT_LINE( 'Sequence " << sequenceName << " reset to ' || NEW_SEQ_START || '.' );";
    nextLine();
  }

  private void resetSequence( DbTable table ) {
    if ( table.sequence ) {
      if ( table.historyTable ) {
        resetSequence( table.historyTable.sqlName, table.primaryKeyColumn.sqlName, table.sequence.sqlName );
      }
      else {
        resetSequence( table.sqlName, table.primaryKeyColumn.sqlName, table.sequence.sqlName );
      }
    }
  }
}
