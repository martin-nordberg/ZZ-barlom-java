
package gov.senate.transaact.domaingen.javamodel;

import java.util.Set;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaTypedModelElement
  extends JavaAnnotatableModelElement {

  /**
   * Constructs a new member.
   * @param parent
   * @param name
   * @param description
   */
  protected JavaTypedModelElement(
      JavaNamedModelElement parent,
      String name,
      String description,
      JavaType type ) {
    super( parent, name, description );

    this.type = type;
  }

  @Override
  public Set<JavaType> getImports() {
    Set<JavaType> result = super.getImports();

    result.add( this.type );

    return result;
  }

  /** Returns the type. */
  public JavaType getType() {
    return this.type;
  }

  private JavaType type;

}
