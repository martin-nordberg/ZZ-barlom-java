
package gov.senate.transaact.domaingen.dbgen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gov.senate.transaact.domaingen.dbmodel.DbColumn;
import gov.senate.transaact.domaingen.dbmodel.DbDomain;
import gov.senate.transaact.domaingen.dbmodel.DbForeignKeyColumn;
import gov.senate.transaact.domaingen.dbmodel.DbSchema;
import gov.senate.transaact.domaingen.dbmodel.DbTable;
import gov.senate.transaact.domaingen.dbmodel.DbTableColumn;
import gov.senate.transaact.domaingen.dbmodel.EDbDataType;
import gov.senate.transaact.domaingen.dbmodel.EDbTriggerType;
import gov.senate.transaact.domaingen.model.Attribute;
import gov.senate.transaact.domaingen.model.BlobDataType;
import gov.senate.transaact.domaingen.model.BooleanDataType;
import gov.senate.transaact.domaingen.model.Constraint;
import gov.senate.transaact.domaingen.model.DataType;
import gov.senate.transaact.domaingen.model.DateDataType;
import gov.senate.transaact.domaingen.model.Domain;
import gov.senate.transaact.domaingen.model.Entity;
import gov.senate.transaact.domaingen.model.Instance;
import gov.senate.transaact.domaingen.model.Relationship;
import gov.senate.transaact.domaingen.model.StringDataType;
import gov.senate.transaact.domaingen.model.TemporalEntity;
import gov.senate.transaact.domaingen.model.TimeStampDataType;
import gov.senate.transaact.domaingen.model.UnicodeStringDataType;

/**
 * @author GDIT, Inc.
 */
public class DbModelGenerator {

  /** Un-instanced static utility class. */
  private DbModelGenerator() {
  }

  /** Generates the corresponding database domain for a model domain. */
  public static DbDomain generateDomain( DbSchema dbSchema, Domain domain ) {

    DbDomain result = dbSchema.addDomain(
        domain.getName(),
        "",
        domain.getHasSqlCustomizations(),
        domain );

    for ( Entity entity : domain.getEntities() ) {
      DbModelGenerator.addTable( result, entity );
    }

    return result;
  }

  /** Adds the history table corresponding to the given entity. */
  private static void addHistoryTable( DbDomain dbDomain, TemporalEntity entity, DbTable table ) {
    // add the table
    DbTable histTable = dbDomain.addTable(
        entity.getSqlName().getHistoryTable(),
        entity.getDescription() );

    // add the primary key
    String keyName = DbModelGenerator.getUniqueId( entity );
    String histKeyName = keyName.substring( 0, keyName.length() - 2 ) + "ATTR_ID";
    histTable.addPrimaryKeyColumn( histKeyName );
    histTable.addPrimaryKeyConstraint( histKeyName );

    // add the sequence
    histTable.addSequence();

    // add the inheritance discriminator
    if ( entity.isInheritanceRoot() ) {
      DbColumn column = histTable.addDiscriminatorColumn( entity.getDiscriminator() );
      histTable.addIndex( column );
    }

    // add history-related columns
    DbForeignKeyColumn eColumn = histTable.addForeignKeyColumn(
        keyName,
        keyName,
        "The surrogate key for this " + entity.getJavaName().getAsDescription(),
        false );

    DbForeignKeyColumn column = histTable.addForeignKeyColumn(
        "Start Action Id",
        "Start Action",
        "The action that brought this record into being",
        false );
    histTable.addForeignKeyConstraint(
        "Start Action Id",
        "The action that brought this record into being",
        column,
        dbDomain.getParent().getTableByName( "USER_ACTION" ),
        false );
    histTable.addIndex( column );
    histTable.addUniquenessConstraint(
        table.getName() + "_" + column.getName(),
        "Unique historical actions",
        eColumn,
        column );

    column = histTable.addForeignKeyColumn(
        "End Action Id",
        "End Action",
        "The action that made this record obsolete (null means current)",
        true );
    histTable.addForeignKeyConstraint(
        "End Action Id",
        "The action that made this record obsolete (null means current)",
        column,
        dbDomain.getParent().getTableByName( "USER_ACTION" ),
        false );
    histTable.addIndex( column );
    histTable.addUniquenessConstraint(
        table.getName() + "_" + column.getName(),
        "Unique historical actions",
        eColumn,
        column );

    histTable.addAttributeColumn(
        "Update Date",
        "Update Date",
        "The date and time this record was last changed",
        EDbDataType.TIMESTAMP,
        null,
        null,
        false,
        null );

    // add attributes
    for ( Attribute attribute : entity.getAttributes() ) {
      Integer size = null;
      if ( attribute.getMaxLength() != null ) {
        size = attribute.getObfuscated() ? 3 * attribute.getMaxLength() : attribute
            .getMaxLength();
      }

      DbColumn acolumn = histTable.addAttributeColumn(
          attribute.getSqlName().getAsIdentifier(),
          attribute.getName(),
          attribute.getDescription(),
          DbModelGenerator.getDbType( attribute.getDataType() ),
          size,
          attribute.getPrecision(),
          true,
          attribute.getDefaultValue() );

      if ( attribute.getIndexed() ) {
        histTable.addIndex( acolumn );
      }
    }

    // add relationships
    for ( Relationship relationship : entity.getRelationships() ) {
      DbColumn rcolumn = histTable.addForeignKeyColumn( relationship.getSqlName()
          .getAsIdentifier(), relationship.getName(), relationship.getDescription(), true );
      histTable.addIndex( rcolumn );
    }

    // link the history table to its main table
    table.setHistoryTable( histTable );

    // add insert trigger
    String code = "";
    code += "-- Insert the audit record\n";
    code += "INSERT INTO " + entity.getSqlName().getHistoryTable() + "\n";
    code += "          ( " + entity.getSqlName().getHistoryUniqueId() + ", "
        + entity.getSqlName().getUniqueId() + ", START_ACTION_ID, END_ACTION_ID, UPDATE_DATE";

    for ( Attribute attribute : entity.getAttributes() ) {
      code += ", " + attribute.getSqlName().getColumn();
    }
    for ( Relationship relationship : entity.getRelationships() ) {
      code += ", " + relationship.getSqlName().getColumn();
    }
    code += " )\n";
    code += "   VALUES ( " + entity.getSqlName().getHistorySequence() + ".NEXTVAL, :NEW."
        + entity.getSqlName().getUniqueId();
    code += ", :NEW.LATEST_ACTION_ID, NULL, :NEW.UPDATE_DATE";
    for ( Attribute attribute : entity.getAttributes() ) {
      code += ", :NEW." + attribute.getSqlName().getColumn();
    }
    for ( Relationship relationship : entity.getRelationships() ) {
      code += ", :NEW." + relationship.getSqlName().getColumn();
    }
    code += " );\n \n";

    table.addTrigger(
        EDbTriggerType.AFTER_INSERT,
        "Create the trigger to automatically capture history",
        code.toString() );

    // add update trigger
    code = "";

    code += "-- Obsolete the prior attributes\n";
    code += "UPDATE " + entity.getSqlName().getHistoryTable() + "\n";
    code += "   SET END_ACTION_ID = :NEW.LATEST_ACTION_ID\n";
    code += " WHERE " + entity.getSqlName().getUniqueId() + " = :NEW."
        + entity.getSqlName().getUniqueId() + "\n";
    code += "   AND END_ACTION_ID IS NULL;\n";
    code += "\n";
    code += "-- If we're not using the special \"delete\" idiom (non-null IS_DELETED flag)\n";
    code += "IF :NEW.IS_DELETED IS NULL THEN\n";
    code += "  -- Insert the new attributes\n";
    code += "  INSERT INTO " + entity.getSqlName().getHistoryTable() + "\n";
    code += "            ( " + entity.getSqlName().getHistoryUniqueId() + ", "
        + entity.getSqlName().getUniqueId() + ", START_ACTION_ID, END_ACTION_ID, UPDATE_DATE";
    for ( Attribute attribute : entity.getAttributes() ) {
      code += ", " + attribute.getSqlName().getColumn();
    }
    for ( Relationship relationship : entity.getRelationships() ) {
      code += ", " + relationship.getSqlName().getColumn();
    }
    code += " )\n";
    code += "     VALUES ( " + entity.getSqlName().getHistorySequence() + ".NEXTVAL, :NEW."
        + entity.getSqlName().getUniqueId();
    code += ", :NEW.LATEST_ACTION_ID, NULL, :NEW.UPDATE_DATE";
    for ( Attribute attribute : entity.getAttributes() ) {
      code += ", :NEW." + attribute.getSqlName().getColumn();
    }
    for ( Relationship relationship : entity.getRelationships() ) {
      code += ", :NEW." + relationship.getSqlName().getColumn();
    }
    code += " );\n";
    code += "END IF;\n";
    code += " \n";

    table.addTrigger(
        EDbTriggerType.AFTER_UPDATE,
        "Create the trigger to capture updates history",
        code.toString() );

  }

  /** Adds the table corresponding to the given entity. */
  private static void addTable( DbDomain dbDomain, Entity entity ) {
    // add the table
    DbTable table = dbDomain.addTable( entity.getSqlName().getRaw(), entity.getDescription() );

    // add the primary key
    String keyName = DbModelGenerator.getUniqueId( entity );
    table.addPrimaryKeyColumn( keyName );
    table.addPrimaryKeyConstraint( keyName );

    // add the sequence
    table.addSequence();

    // add foreign key to base class
    if ( entity.getBaseClass() != null ) {
      DbTable baseTable = (DbTable) dbDomain.getParent().getRelationByName(
          entity.getBaseClass().getSqlName().getTable() );
      table.addForeignKeyConstraint(
          keyName,
          "Foreign key to base class",
          baseTable.getPrimaryKeyColumn(),
          baseTable,
          true );
    }

    // add the inheritance discriminator
    if ( entity.isInheritanceRoot() ) {
      DbColumn column = table.addDiscriminatorColumn( entity.getDiscriminator() );
      table.addIndex( column );
    }

    // add history-related columns
    if ( entity.isTemporal() ) {
      DbForeignKeyColumn fkColumn = table.addForeignKeyColumn(
          "Latest Action Id",
          "Latest Action",
          "The action that brought this record into being",
          false );
      table.addForeignKeyConstraint(
          "Latest Action Id",
          "The action that brought this record into being",
          fkColumn,
          (DbTable) dbDomain.getParent().getRelationByName( "USER_ACTION" ),
          false );
      table.addIndex( fkColumn );

      table.addAttributeColumn(
          "Is Deleted",
          "Is Deleted",
          "Flag used only by update trigger to create the audit trail for a deletion",
          EDbDataType.BOOLEAN,
          null,
          null,
          true,
          null );

      DbColumn aColumn = table.addAttributeColumn(
          "Update Date",
          "Update Date",
          "The date and time this record was last changed",
          EDbDataType.TIMESTAMP,
          null,
          null,
          false,
          null );
      table.addIndex( aColumn );
    }

    // add attributes
    for ( Attribute attribute : entity.getAttributes() ) {
      Integer size = null;
      if ( attribute.getMaxLength() != null ) {
        size = attribute.getObfuscated() ? 3 * attribute.getMaxLength() : attribute
            .getMaxLength();
      }

      DbTableColumn column = table.addAttributeColumn(
          attribute.getSqlName().getAsIdentifier(),
          attribute.getName(),
          attribute.getDescription(),
          DbModelGenerator.getDbType( attribute.getDataType() ),
          size,
          attribute.getPrecision(),
          !attribute.getRequired(),
          attribute.getDefaultValue() );

      if ( attribute.getIndexed() ) {
        table.addIndex( column );
      }

      if ( attribute.getUnique() ) {
        table.addUniquenessConstraint( column );
      }
    }

    // add relationships
    for ( Relationship relationship : entity.getRelationships() ) {
      DbTable relatedTable = dbDomain.getParent().getTableByName(
          relationship.getRelatedEntity().getSqlName().getTable() );
      if ( relationship.getNeedsForeignKeyToBaseClassWorkaround() ) {
        relatedTable = dbDomain.getParent().getTableByName(
            relationship.getRelatedEntity().getBaseClass().getSqlName().getTable() );
      }
      assert relatedTable != null : relationship.getRelatedEntity().getSqlName().getTable();

      DbTableColumn column = table.addForeignKeyColumn(
          relationship.getSqlName().getAsIdentifier(),
          relationship.getName(),
          relationship.getDescription(),
          !relationship.getRequired() );
      table.addForeignKeyConstraint(
          relationship.getSqlName().getAsIdentifier(),
          relationship.getDescription(),
          column,
          relatedTable,
          relationship.isComposed() );
      if ( relationship.isOneToOne() ) {
        table.addUniquenessConstraint( column );
      }
      table.addIndex( column );
    }

    // add the corresponding history table
    if ( entity instanceof TemporalEntity ) {
      DbModelGenerator.addHistoryTable( dbDomain, (TemporalEntity) entity, table );
    }

    // add extra constraints
    for ( Constraint constraint : entity.getConstraints() ) {
      String[] uniqueColumnNames = constraint.getExpression().split( "," );
      List<DbTableColumn> uniqueColumns = new ArrayList<DbTableColumn>();

      for ( int i = 0; i < uniqueColumnNames.length; ++i ) {
        DbTableColumn column = table.getColumnByName( uniqueColumnNames[i].trim() );
        assert column != null : constraint.getExpression() + " -- "
            + uniqueColumnNames[i].trim();
        uniqueColumns.add( column );
      }

      table.addUniquenessConstraint(
          constraint.getName(),
          constraint.getDescription(),
          uniqueColumns );
    }

    // add records
    for ( Instance instance : entity.getInstances() ) {
      Map<String, Object> values = new HashMap<String, Object>();

      for ( String key : instance.keySet() ) {
        Object value = instance.get( key );
        values.put( key.toString().toUpperCase(), value );
      }

      table.addRecord( values, (Boolean) instance.get( "isUnitTestInstance" ) );
    }

  }

  /** Returns the SQL data type for the given model data type. */
  private static EDbDataType getDbType( DataType dataType ) {
    if ( dataType instanceof StringDataType ) {
      return EDbDataType.VARCHAR2;
    }
    if ( dataType instanceof BooleanDataType ) {
      return EDbDataType.BOOLEAN;
    }
    if ( dataType instanceof DateDataType ) {
      return EDbDataType.DATE;
    }
    if ( dataType instanceof TimeStampDataType ) {
      return EDbDataType.TIMESTAMP;
    }
    if ( dataType instanceof BlobDataType ) {
      return EDbDataType.BLOB;
    }
    if ( dataType instanceof UnicodeStringDataType ) {
      return EDbDataType.NVARCHAR2;
    }

    return EDbDataType.INTEGER;
  }

  /** Returns the unique ID for an entity; uses the base class if present. */
  private static String getUniqueId( Entity entity ) {
    if ( entity.getBaseClass() != null ) {
      return DbModelGenerator.getUniqueId( entity.getBaseClass() );
    }

    return entity.getSqlName().getUniqueId();
  }
}
