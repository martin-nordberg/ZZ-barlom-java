
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbTrigger
  extends DbNamedModelElement {

  /**
   * Constructs a new trigger
   * @param parent
   * @param name
   * @param description
   */
  public DbTrigger( DbTable parent, EDbTriggerType triggerType, String description, String code ) {
    super( parent, parent.getName(), description );

    this.triggerType = triggerType;
    this.code = code;

    parent.onAddChild( this );
  }

  /** Returns the code. */
  public String getCode() {
    return this.code;
  }

  /** {@inheritDoc} */
  @Override
  public DbTable getParent() {
    return (DbTable) super.getParent();
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    switch ( this.triggerType ) {
      case AFTER_INSERT:
        return DbNamedModelElement.makeSqlName( "INSERT", this.getParent().getSqlName() );
      case AFTER_UPDATE:
        return DbNamedModelElement.makeSqlName( "UPDATE", this.getParent().getSqlName() );
    }

    assert false;
    return DbNamedModelElement.makeSqlName( "UNKNOWN", this.getParent().getSqlName() );
  }

  /** Returns the triggerType. */
  public EDbTriggerType getTriggerType() {
    return this.triggerType;
  }

  private String code;

  private EDbTriggerType triggerType;

}
