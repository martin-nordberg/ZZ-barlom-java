
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaAbstractPackage
  extends JavaNamedModelElement {

  /**
   * Constructs a new abstract Java package (package or root package).
   * @param parent
   * @param name
   * @param description
   */
  protected JavaAbstractPackage( JavaAbstractPackage parent, String name, String description ) {
    super( parent, name, description );

    this.packages = new ArrayList<JavaPackage>();
  }

  /** Creates a package within this one. */
  public JavaPackage addPackage( String name, String description, Boolean isImplicitlyImported ) {
    return new JavaPackage( this, name, description, isImplicitlyImported );
  }

  /** Given a qualified name relative to this package, find the needed component. */
  public JavaAnnotationInterface findAnnotationInterface( String relativeQualifiedName ) {

    // split the relative path into first and rest
    String[] packageNames = relativeQualifiedName.split( "\\.", 2 );

    // look for an existing sub-package
    for ( JavaPackage jpackage : this.packages ) {
      if ( jpackage.getJavaName().equals( packageNames[0] ) ) {
        return jpackage.findAnnotationInterface( packageNames[1] );
      }
    }

    return null;
  }

  /** Given a qualified name relative to this package, find the needed component. */
  public JavaComponent findComponent( String relativeQualifiedName ) {

    // split the relative path into first and rest
    String[] packageNames = relativeQualifiedName.split( "\\.", 2 );

    // look for an existing sub-package
    for ( JavaPackage jpackage : this.packages ) {
      if ( jpackage.getJavaName().equals( packageNames[0] ) ) {
        return jpackage.findComponent( packageNames[1] );
      }
    }

    return null;
  }

  /** Given a qualified name relative to this package, find or create the needed subpackages. */
  public JavaPackage findOrCreatePackage( String relativeQualifiedName ) {

    // return this package itself if we're at the bottom of the path
    if ( relativeQualifiedName.isEmpty() ) {
      return (JavaPackage) this;
    }

    // split the relative path into first and rest
    String[] packageNames = relativeQualifiedName.split( "\\.", 2 );

    // look for an existing sub-package
    for ( JavaPackage jpackage : this.packages ) {
      if ( jpackage.getJavaName().equals( packageNames[0] ) ) {
        if ( packageNames.length == 1 ) {
          return jpackage;
        }
        return jpackage.findOrCreatePackage( packageNames[1] );
      }
    }

    // not found - create a new sub-package
    JavaPackage newPackage = this.addPackage( packageNames[0], "", false );

    if ( packageNames.length == 1 ) {
      return newPackage;
    }
    return newPackage.findOrCreatePackage( packageNames[1] );
  }

  /** Returns the fully qualified name of this package. */
  public String getFullyQualifiedJavaName() {
    String result = this.getParent().getFullyQualifiedJavaName();
    if ( result.length() > 0 ) {
      result += ".";
    }
    result += this.getJavaName();
    return result;
  }

  /** Returns the packages within this package. */
  public List<JavaPackage> getPackages() {
    return this.packages;
  }

  /** @return the parent of this package. */
  @Override
  public JavaAbstractPackage getParent() {
    return (JavaAbstractPackage) super.getParent();
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    return this.getFullyQualifiedJavaName();
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaPackage child ) {
    super.onAddChild( child );
    this.packages.add( child );
  }

  private List<JavaPackage> packages;

}
