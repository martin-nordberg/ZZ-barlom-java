
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaMethod
  extends JavaFunction {

  /**
   * Constructs a new method.
   * @param parent
   * @param name
   * @param description
   */
  JavaMethod(
      JavaComponent parent,
      String name,
      String description,
      EJavaAccessibility accessibility,
      Boolean isAbstract,
      Boolean isStatic,
      Boolean isFinal,
      JavaType returnType,
      String code ) {
    super( parent, name, description, accessibility, isStatic, isFinal, returnType, code );

    this.isAbstract = isAbstract;

    parent.onAddChild( this );
  }

  /** @return whether this is an abstract method. */
  public Boolean getIsAbstract() {
    return this.isAbstract;
  }

  private Boolean isAbstract;

}
