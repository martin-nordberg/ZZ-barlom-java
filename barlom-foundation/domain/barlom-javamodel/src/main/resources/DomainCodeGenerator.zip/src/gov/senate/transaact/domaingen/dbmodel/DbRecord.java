
package gov.senate.transaact.domaingen.dbmodel;

import java.util.Map;

/**
 * Representation of a single table record in the database.
 * @author GDIT, Inc.
 */
public class DbRecord
  extends DbModelElement {

  /**
   * Constructs a new record.
   * @param parent The table the record is part of.
   * @param description A description of the record.
   */
  DbRecord( DbTable parent, Map<String, Object> columnValues, Boolean isUnitTestValue ) {
    super( parent, null );

    this.columnValues = columnValues;
    this.isUnitTestValue = isUnitTestValue;

    parent.onAddChild( this );
  }

  /** Returns the columnValues. */
  public Object getColumnValue( String key ) {

    String simplifiedKey = key.toUpperCase();
    simplifiedKey = simplifiedKey.replaceAll( " ", "" );
    simplifiedKey = simplifiedKey.replaceAll( "_", "" );

    return this.columnValues.get( simplifiedKey );
  }

  /** Returns the columnValues. */
  public Map<String, Object> getColumnValues() {
    return this.columnValues;
  }

  /** Returns whether this record is for unit testing (as opposed to reference data). */
  public Boolean getIsUnitTestValue() {
    return this.isUnitTestValue;
  }

  /** {@inheritDoc} */
  @Override
  public String toString() {
    return "[columnValues=" + this.columnValues + ", isUnitTestValue=" + this.isUnitTestValue
        + "]";
  }

  /** Mapping from column name to SQL-formatted value. */
  private Map<String, Object> columnValues;

  private Boolean isUnitTestValue;

}
