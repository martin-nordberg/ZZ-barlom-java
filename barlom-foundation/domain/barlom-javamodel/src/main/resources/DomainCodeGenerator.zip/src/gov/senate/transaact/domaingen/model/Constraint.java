
package gov.senate.transaact.domaingen.model;

/**
 * A constraint is an extra criteria enforced on multiple elements of an entity.
 */
public class Constraint
  extends ModelElement {

  /** Returns the description. */
  public String getDescription() {
    return this.description;
  }

  /** Returns the expression. */
  public String getExpression() {
    return this.expression;
  }

  @Override
  public Entity getParent() {
    return this.parent;
  }

  /**
   * Sets the parent entity for this attribute. (Also adds this attribute to the parent's list of
   * attributes.) (This method is needed by the model builder code.)
   */
  public void setParent( Entity parent ) {
    assert this.parent == null : "Cannot change the parent of a constraint.";
    this.parent = parent;
    parent.getConstraints().add( this );
  }

  /** Validates this constraint. */
  @Override
  public void validate() {
    assert !this.getName().isEmpty() : "Constraint has no name.";
    assert !this.expression.isEmpty() : "Constraint has no expression.";
    assert !this.description.isEmpty() : "Constraint " + this.getName()
        + " has no description.";
    assert this.constraintType != null : "Attribute " + this.getName() + " has no data type.";
  }

  /** The type of this constraint (uniqueness by default). */
  private ConstraintType constraintType = ConstraintType.uniquenessConstraintType;

  /** A short description of this attribute. */
  private String description;

  /** An expression defining the constraint. */
  private String expression;

  /** The entity with this attribute. */
  private Entity parent;
}
