
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

class JavaCrudTestWriter
extends JavaEntitiesWriter {

  private List<Instance> findTestInstances( Entity entity ) {

    // try using only test instances
    List<Instance> result = new ArrayList<Instance>();
    for ( Instance instance : entity.instances ) {
      if ( instance.isUnitTestInstance ) {
        result.add( instance );
      }
    }

    // try again with all instances if not enough test instances
    if ( result.size() < 2 ) {
      result = new ArrayList<Instance>();
      for ( Instance instance : entity.instances ) {
        result.add( instance );
      }
    }

    // shrink the set to reduce likelihood of conflicts in uniqueness constraints with existing test data
    if ( result.size > 2 ) {
      result.remove( 0 );
    }
    if ( result.size > 2 ) {
      result.remove( result.size()-1 );
    }

    return result;
  }

  protected String getClassName( Entity entity ) {
    return entity.javaName.crudTestClass;
  }

  /** Determines whether a given entity needs to be written. */
  protected boolean isWriteable( Entity entity ) {
    return !entity.needsHandWrittenCrudTest && !entity.abztract && !entity.enumerated;
  }

  /** Writes the CRUD unit test for a given entity. */
  protected void writeEntity( Entity entity ) {

    String testPackage = entity.parent.javaName.testPackage;

    // package definition
    nextLine() << 'package ' << testPackage << ';';
    nextLine();

    // imports
    getImportedPackages( entity ).each { importedClass ->
      if ( !isInSamePackage( importedClass, testPackage ) ) {
        nextLine() << 'import ' << importedClass << ';';
      }
    }
    nextLine();

    // class declaration
    nextLine() << '/**';
    nextLine() << ' * Unit test (create/review/update/delete) for class ' << entity.javaName.asIdentifier << '.';
    nextLine() << ' * @author Vangent, Inc. (NOTE: SCRIPT-GENERATED CODE; DO NOT HAND EDIT)';
    nextLine() << ' */';
    nextLine() << 'public final class ' << getClassName( entity )
    ++indent;
    nextLine() << 'extends BaseTestCase {';
    nextLine();

    // set up and tear down
    nextLine() << '/** Allocates the entity manager. */';
    nextLine() << '@Before';
    nextLine() << 'public void setUp() {';
    nextLine() << indent() << 'em = JpaDataModelFactory.makeEntityManager();';
    nextLine() << indent() << 'assert em.isOpen();';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** Closes the entity manager. */';
    nextLine() << '@After';
    nextLine() << 'public void tearDown() {';
    nextLine() << indent() << 'em.close();';
    nextLine() << '}';
    nextLine();

    // string attribute test values
    if ( hasStringAttribute( entity ) ) {
      nextLine() << '/** @return a test value for a string attribute. */';
      nextLine() << 'private String sampleValue( String name, int maxLength ) {';
      ++indent;
      nextLine() << 'String result = name + Math.random();';
      nextLine() << 'if ( result.length() > maxLength ) {';
      nextLine() << indent() << 'result = result.substring( 0, maxLength );';
      nextLine() << '}';
      nextLine() << 'return result;';
      --indent;
      nextLine() << '}';
      nextLine();
    }

    // test method declaration
    nextLine() << '/**';
    nextLine() << ' * Tests create/review/update/delete for a ' << entity.javaName.asDescription << '.';
    nextLine() << ' * @throws Exception if the test fails unexpectedly.';
    nextLine() << ' */';
    nextLine() << '@Test';
    nextLine() << 'public void testCRUD() throws Exception {';
    ++indent;
    nextLine();

    // unit test user
    if ( entity.isTemporal() ) {
      nextLine() << 'User user = em.findOne( User.class, "SELECT obj FROM User obj WHERE obj.loginName = \'UNITTEST\'" );';
      nextLine();
    }

    // REVIEW
    nextLine() << '// review initial list';
    String beforeObjs = 'before' + entity.javaName.asIdentifier + 's';
    nextLine() << 'List<' << entity.javaName.implementationClass << '> ' << beforeObjs << ' = em.findAll( ' << entity.javaName.implementationClass << '.class );';
    nextLine();

    // CREATE
    String obj1 = entity.javaName.field + '1';
    nextLine() << '// create';
    nextLine();
    nextLine() << 'em.beginTransaction();';
    ++indent;
    if ( entity.isTemporal() ) {
      nextLine() << 'UserAction userAction1 = new UserAction();';
      nextLine() << 'userAction1.setEffectiveDateAndTime( new Date() );';
      nextLine() << 'userAction1.setDescription( "' << entity.javaName.asDescription << ' Test Action #1" );';
      nextLine() << 'userAction1.setUser( user );';
      nextLine() << 'em.persist( userAction1 );';
      nextLine();
    }

    writeCreateEntity( entity, obj1 );

    if ( entity.isTemporal() ) {
      nextLine() << obj1 << '.setLatestUserAction( userAction1 );';
      nextLine();
    }
    nextLine() << 'em.persist( ' << obj1 << ' );';
    --indent;
    nextLine() << 'em.commitTransaction();';
    nextLine();
    String objId = entity.javaName.uniqueId;
    nextLine() << 'Long ' << objId << ' = ' << obj1 << '.getUniqueId();';
    nextLine();

    // REVIEW
    String obj2 = entity.javaName.field + '2';
    nextLine() << '// review';
    nextLine() << entity.javaName.implementationClass << ' ' << obj2 << ' = em.find( ' << entity.javaName.implementationClass << '.class, ' << objId << ' );';
    nextLine();
    nextLine() << 'assert ' << obj2 << '.equals( ' << obj1 << ' );';
    nextLine();

    // UPDATE
    nextLine() << '// update';
    nextLine();
    nextLine() << 'em.beginTransaction();';
    ++indent;
    if ( entity.isTemporal() ) {
      nextLine() << 'UserAction userAction2 = new UserAction();';
      nextLine() << 'userAction2.setEffectiveDateAndTime( new Date() );';
      nextLine() << 'userAction2.setDescription( "' << entity.javaName.asDescription << ' Test Action #2" );';
      nextLine() << 'userAction2.setUser( user );';
      nextLine() << 'em.persist( userAction2 );';
      nextLine();
    }

    writeUpdateEntity( entity, obj2 );

    if ( entity.isTemporal() ) {
      nextLine() << obj2 << '.setLatestUserAction( userAction2 );';
      nextLine();
    }
    nextLine() << 'em.persist( ' << obj2 << ' );';
    --indent;
    nextLine() << 'em.commitTransaction();';
    nextLine();

    // REVIEW
    String obj3 = entity.javaName.field + '3';
    nextLine() << '// review changes';
    nextLine() << entity.javaName.implementationClass << ' ' << obj3 << ' = em.find( ' << entity.javaName.implementationClass << '.class, ' << objId << ' );';
    nextLine();
    nextLine() << 'assert ' << obj3 << '.equals( ' << obj2 << ' );';
    nextLine();
    nextLine() << '// review all';
    String allObjs = 'all' + entity.javaName.asIdentifier + 's';
    nextLine() << 'List<' << entity.javaName.implementationClass << '> ' << allObjs << ' = em.findAll( ' << entity.javaName.implementationClass << '.class );';
    nextLine();
    nextLine() << 'assert ' << allObjs << '.size() == ' << beforeObjs << '.size() + 1;';
    nextLine() << 'assert ' << allObjs << '.contains( ' << obj3 << ' );';
    nextLine();

    // DELETE
    nextLine() << '// delete';
    nextLine() << 'em.beginTransaction();';
    ++indent;
    if ( entity.isTemporal() ) {
      nextLine() << 'UserAction userAction3 = new UserAction();';
      nextLine() << 'userAction3.setEffectiveDateAndTime( new Date() );';
      nextLine() << 'userAction3.setDescription( "' << entity.javaName.asDescription << ' Test Action #3" );';
      nextLine() << 'userAction3.setUser( user );';
      nextLine() << 'em.persist( userAction3 );';
      nextLine();
      nextLine() << obj3 << '.setLatestUserAction( userAction3 );';
      nextLine() << 'em.remove( ' << obj3 << ' );';
      nextLine() << 'assert ' << obj3 << '.isDeleted();';
    }
    else {
      nextLine() << 'em.remove( ' << obj3 << ' );';
    }
    --indent;
    nextLine() << 'em.commitTransaction();';
    nextLine();

    // REVIEW
    String obj4 = entity.javaName.field + '4';
    nextLine() << '// review gone';
    nextLine() << entity.javaName.implementationClass << ' ' << obj4 << ' = em.find( ' << entity.javaName.implementationClass << '.class, ' << objId << ' );';
    nextLine();
    nextLine() << 'assert ' << obj4 << ' == null;';
    nextLine();
    nextLine() << '// review all again';
    String afterObjs = 'after' + entity.javaName.asIdentifier + 's';
    nextLine() << 'List<' << entity.javaName.implementationClass << '> ' << afterObjs << ' = em.findAll( ' << entity.javaName.implementationClass << '.class );';
    nextLine();
    nextLine() << 'assert ' << afterObjs << '.size() == ' << beforeObjs << '.size();';
    nextLine();

    // REVIEW CHANGES
    if ( entity.isTemporal() ) {
      String objIdAttr = objId;
      if ( entity.baseClass != null ) {
        objIdAttr = entity.baseClass.javaName.uniqueId;
      }
      nextLine() << '// review changes';
      nextLine() << 'List<' << entity.javaName.changeImplementationClass << '> changes = em.findMultiple( ' << entity.javaName.changeImplementationClass << '.class, "SELECT change FROM ' << entity.javaName.changeImplementationClass << ' change WHERE change.' << objIdAttr << ' = " + ' << objId << ' );';
      nextLine();
      nextLine() << 'assert changes.size() == 3;';
      nextLine();
    }

    --indent;
    nextLine() << '}';
    nextLine();

    // entity manager
    nextLine() << '/** The JPA entity manager. */';
    nextLine() << 'private IEntityManager em;';
    nextLine();

    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Determines whether an entoty has a string attribute. */
  private boolean hasStringAttribute( Entity entity ) {

    if ( entity.attributes.find { it.dataType == DataType.stringDataType } ) {
      return true;
    }
    else if ( entity.attributes.find { it.dataType == DataType.unicodeStringDataType } ) {
      return true;
    }

    if ( entity.baseClass != null ) {
      return hasStringAttribute( entity.baseClass );
    }

    return false;
  }

  /** Constructs a test value for the given attribute. */
  private String makeTestValue( Attribute attribute ) {
    if ( attribute.dataType == DataType.stringDataType ) {
      return 'sampleValue( "' + attribute.name + '", ' + (attribute.autoTruncated ? attribute.maxLength+10 : attribute.maxLength) + " )";
    }
    else if ( attribute.dataType == DataType.unicodeStringDataType ) {
      return 'sampleValue( "' + attribute.name + '", ' + (attribute.autoTruncated ? attribute.maxLength+10 : attribute.maxLength) + " )";
    }
    else if ( attribute.dataType == DataType.timeStampDataType ) {
      return 'new Date()';
    }
    else if ( attribute.dataType == DataType.dateDataType ) {
      return 'new Date()';
    }
    else if ( attribute.dataType == DataType.integerDataType ) {
      return 'new Integer( (int) ( Math.random() * 100 ) )';
    }
    else if ( attribute.dataType == DataType.longDataType ) {
      return 'new Long( (long) ( Math.random() * 100 ) )';
    }
    else if ( attribute.dataType == DataType.booleanDataType ) {
      return 'Boolean.TRUE';
    }
    else {
      assert false;
    }
  }

  private List<String> getImportedPackages( Entity entity ) {

    Set result = new HashSet();

    result.add( 'java.util.*' );
    result.add( 'org.junit.*' );
    result.add( 'gov.senate.transaact.common.datamodel.IEntityManager' );
    result.add( 'gov.senate.transaact.common.util.BaseTestCase' );
    if ( entity.isTemporal() ) {
      result.add( 'gov.senate.transaact.common.organization.domainmodel.UserAction' );
      result.add( 'gov.senate.transaact.common.organization.domainmodel.User' );
      result.add( entity.javaName.changeImplementationClassFullyQualified );
    }
    result.add( 'gov.senate.transaact.jpa.datamodel.JpaDataModelFactory' );

    entity.allRelationships.each {
      if ( it.relatedEntity.instances ) {
        result.add( it.relatedEntity.javaName.implementationClassFullyQualified );
      }
      if ( it.oneToOne && it.persistedWithParent ) {
        it.relatedEntity.allRelationships.each {
          result.add( it.relatedEntity.javaName.implementationClassFullyQualified );
        }
      }
    }

    return result.sort();
  }

  /** Writes the code to instantiate a test object. */
  private void writeCreateEntity( Entity entity, String varName ) {
    nextLine() << entity.javaName.implementationClass << ' ' << varName << ' = new ' << entity.javaName.implementationClass << '();';
    entity.allAttributes.each {
      nextLine() << varName << '.' << it.javaName.setter << '( ' << makeTestValue(it) << ' );';
    }
    entity.allRelationships.each {
      if ( it.oneToOne && it.persistedWithParent ) {
        String rel = it.javaName.field + '1';
        nextLine() << "{";
        indent++;
        writeCreateEntity( it.relatedEntity, rel );
        nextLine() << varName << '.' << it.javaName.setter << '( ' << rel << ' );';
        indent--;
        nextLine() << "}";
      }
      else if ( it.relatedEntity.instances ) {
        Entity relatedEntity = it.relatedEntity;
        List<Instance> testInstances = findTestInstances( relatedEntity );
        Instance instance = testInstances[0];
        String rel = it.javaName.field + '1';
        nextLine() << relatedEntity.javaName.implementationClass << ' ' << rel << ' = '
        if ( relatedEntity.enumerated ) {
          sameLine() << relatedEntity.javaName.implementationClass << '.' << instance.getReferencePrefix() << ';';
        }
        else if ( instance.get( 'UniqueId' ) ) {
          sameLine() << 'em.find( ';
          sameLine() << relatedEntity.javaName.implementationClass << '.class, '
          sameLine() << instance.get( 'UniqueId' ) << 'L );';
        }
        else {
          sameLine() << 'em.findOne( ';
          sameLine() << relatedEntity.javaName.implementationClass << '.class, "SELECT obj FROM ' << relatedEntity.javaName.implementationClass;
          sameLine() << ' obj WHERE obj.' << new JavaName( instance.nameAttributeName ).field << ' = \''
          sameLine() << instance.get( instance.nameAttributeName ) << '\'" );';
        }
        nextLine() << varName << '.' << it.javaName.setter << '( ' << rel << ' );';
      }
    }
  }


  /** Writes the code to instantiate a test object. */
  private void writeUpdateEntity( Entity entity, String varName ) {
    entity.allAttributes.each {
      if ( entity.isTemporal() == it.isTemporal() ) {
        nextLine() << varName << '.' << it.javaName.setter << '( ' << makeTestValue(it) << ' );';
      }
    }
    entity.allRelationships.each {
      if ( it.oneToOne && it.persistedWithParent ) {
        String rel = varName + "." + it.javaName.getter + "()";
        nextLine() << "{";
        indent++;
        writeUpdateEntity( it.relatedEntity, rel );
        indent--;
        nextLine() << "}";
      }
      else if ( it.relatedEntity.instances ) {
        Entity relatedEntity = it.relatedEntity;
        List<Instance> testInstances = findTestInstances( relatedEntity );
        Instance instance = testInstances[testInstances.size()-1];
        String rel = it.javaName.field + '2';
        nextLine() << relatedEntity.javaName.implementationClass << ' ' << rel << ' = '
        if ( relatedEntity.enumerated ) {
          sameLine() << relatedEntity.javaName.implementationClass << '.' << instance.getReferencePrefix() << ';';
        }
        else if ( instance.get( 'UniqueId' ) ) {
          sameLine() << 'em.find( ';
          sameLine() << relatedEntity.javaName.implementationClass << '.class, '
          sameLine() << instance.get( 'UniqueId' ) << 'L );';
        }
        else {
          sameLine() << 'em.findOne( ';
          sameLine() << relatedEntity.javaName.implementationClass << '.class, "SELECT obj FROM ' << relatedEntity.javaName.implementationClass;
          sameLine() << ' obj WHERE obj.' << new JavaName( instance.nameAttributeName ).field << ' = \''
          sameLine() << instance.get( instance.nameAttributeName ) << '\'" );';
        }
        nextLine() << varName << '.' << it.javaName.setter << '( ' << rel << ' );';
      }
    }
  }
}
