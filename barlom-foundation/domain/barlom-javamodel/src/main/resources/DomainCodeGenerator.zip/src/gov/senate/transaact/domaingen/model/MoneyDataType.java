
package gov.senate.transaact.domaingen.model;

/** Concrete date type for money values. */
public class MoneyDataType
  extends DataType {

  public MoneyDataType() {
    super( "Money", "NUMBER", false, false );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    return value.toString();
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    return value.toString();
  }
}
