
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
@SuppressWarnings( "javadoc" )
public enum EDbTriggerType {

  AFTER_INSERT,

  AFTER_UPDATE;

}
