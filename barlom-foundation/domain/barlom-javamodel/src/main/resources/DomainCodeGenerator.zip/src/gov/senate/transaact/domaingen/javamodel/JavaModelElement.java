
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaModelElement {

  /**
   * Constructs a new Java model element
   * @param parent The parent of this model element.
   */
  protected JavaModelElement( JavaNamedModelElement parent, String description ) {
    super();
    this.parent = parent;
    this.description = description;
  }

  /** Returns the description. */
  public String getDescription() {
    return this.description;
  }

  /** Returns the parent. */
  public JavaNamedModelElement getParent() {
    return this.parent;
  }

  /**
   * @return The highest root package containing this model element.
   */
  public JavaRootPackage getRootPackage() {
    return this.getParent().getRootPackage();
  }

  private String description;

  private JavaNamedModelElement parent;
}
