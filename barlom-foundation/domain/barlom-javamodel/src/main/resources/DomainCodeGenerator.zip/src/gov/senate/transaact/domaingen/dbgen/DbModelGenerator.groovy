package gov.senate.transaact.domaingen.dbgen;

import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbSchema
import gov.senate.transaact.domaingen.dbmodel.DbTable
import gov.senate.transaact.domaingen.dbmodel.DbTableColumn
import gov.senate.transaact.domaingen.dbmodel.EDbDataType
import gov.senate.transaact.domaingen.dbmodel.EDbTriggerType
import gov.senate.transaact.domaingen.model.BlobDataType
import gov.senate.transaact.domaingen.model.BooleanDataType
import gov.senate.transaact.domaingen.model.DataType
import gov.senate.transaact.domaingen.model.DateDataType
import gov.senate.transaact.domaingen.model.Domain
import gov.senate.transaact.domaingen.model.Entity
import gov.senate.transaact.domaingen.model.StringDataType
import gov.senate.transaact.domaingen.model.TemporalEntity
import gov.senate.transaact.domaingen.model.TimeStampDataType
import gov.senate.transaact.domaingen.model.UnicodeStringDataType


/**
 * @author Vangent, Inc.
 */
class DbModelGenerator {

  /** Generates the corresponding database domain for a model domain. */
  public DbDomain generateDomain( DbSchema dbSchema, Domain domain ) {

    DbDomain result = dbSchema.addDomain( domain.name, "", domain.hasSqlCustomizations, domain );

    domain.entities.each { entity ->
      this.addTable( result, entity );
    }

    return result;
  }

  /** Adds the table corresponding to the given entity. */
  private void addTable( DbDomain dbDomain, Entity entity ) {
    // add the table
    def table = dbDomain.addTable( entity.sqlName.raw, entity.description );

    // add the primary key
    String keyName = getUniqueId( entity );
    table.addPrimaryKeyColumn( keyName );
    table.addPrimaryKeyConstraint( keyName );

    // add the sequence
    table.addSequence();

    // add foreign key to base class
    if ( entity.baseClass ) {
      DbTable baseTable = dbDomain.parent.getRelationByName( entity.baseClass.sqlName.table );
      table.addForeignKeyConstraint(keyName, "Foreign key to base class", baseTable.primaryKeyColumn, baseTable, true )
    }

    // add the inheritance discriminator
    if ( entity.isInheritanceRoot() ) {
      def column = table.addDiscriminatorColumn( entity.discriminator );
      table.addIndex( column );
    }

    // add history-related columns
    if ( entity.isTemporal() ) {
      def column = table.addForeignKeyColumn( "Latest Action Id","Latest Action",
          "The action that brought this record into being",
          false );
      table.addForeignKeyConstraint( "Latest Action Id",
          "The action that brought this record into being",
          column,
          dbDomain.parent.getRelationByName( "USER_ACTION" ),
          false );
      table.addIndex( column );

      table.addAttributeColumn( "Is Deleted", "Is Deleted",
          "Flag used only by update trigger to create the audit trail for a deletion",
          EDbDataType.BOOLEAN,
          null,
          null,
          true  ,
          null );

      column = table.addAttributeColumn( "Update Date", "Update Date",
          "The date and time this record was last changed",
          EDbDataType.TIMESTAMP,
          null,
          null,
          false,
          null );
      table.addIndex( column );
    }

    // add attributes
    entity.attributes.each{ attribute ->
      def column = table.addAttributeColumn( attribute.sqlName.asIdentifier,
          attribute.name,
          attribute.description,
          this.getDbType( attribute.dataType ),
          attribute.obfuscated ? 3*attribute.maxLength : attribute.maxLength,
          attribute.precision,
          !attribute.required,
          attribute.defaultValue );

      if ( attribute.indexed ) {
        table.addIndex( column );
      }

      if ( attribute.unique ) {
        table.addUniquenessConstraint( column );
      }
    }

    // add relationships
    entity.relationships.each{ relationship ->
      def relatedTable = dbDomain.parent.getRelationByName( relationship.relatedEntity.sqlName.table );
      if ( relationship.needsForeignKeyToBaseClassWorkaround ) {
        relatedTable = dbDomain.parent.getRelationByName( relationship.relatedEntity.baseClass.sqlName.table );
      }
      assert relatedTable != null : relationship.relatedEntity.sqlName.table;

      def column = table.addForeignKeyColumn( relationship.sqlName.asIdentifier,
          relationship.name,
          relationship.description,
          !relationship.required );
      table.addForeignKeyConstraint( relationship.sqlName.asIdentifier,
          relationship.description,
          column,
          relatedTable,
          relationship.composed );
      if ( relationship.oneToOne ) {
        table.addUniquenessConstraint( column );
      }
      table.addIndex( column );
    }

    // add the corresponding history table
    this.addHistoryTable( dbDomain, entity, table );

    // add extra constraints
    entity.constraints.each{ constraint ->
      def uniqueColumnNames = constraint.expression.split(",");
      def uniqueColumns = new ArrayList<DbTableColumn>();

      for ( int i=0; i<uniqueColumnNames.length; ++i ) {
        def column = table.getColumnByName(uniqueColumnNames[i].trim());
        assert column != null : constraint.expression + " -- " + uniqueColumnNames[i].trim();
        uniqueColumns.add( column );
      }

      table.addUniquenessConstraint( constraint.name, constraint.description, uniqueColumns );
    }

    // add records
    entity.instances.each { instance ->
      def values = [:];

      instance.each { key,value ->
        values.put(  key.toString().toUpperCase(), value );
      }

      table.addRecord( values, instance.isUnitTestInstance );
    }
  }

  /** Skips the history table for a non-temporal entity. */
  private void addHistoryTable( DbDomain dbDomain, Entity entity, DbTable table ) {
  }

  /** Adds the history table corresponding to the given entity. */
  private void addHistoryTable( DbDomain dbDomain, TemporalEntity entity, DbTable table ) {
    // add the table
    def histTable = dbDomain.addTable( entity.sqlName.historyTable, entity.description );

    // add the primary key
    String keyName = getUniqueId( entity );
    String histKeyName = keyName.substring(0, keyName.length() - 2 ) + "ATTR_ID";
    def pkColumn = histTable.addPrimaryKeyColumn( histKeyName );
    histTable.addPrimaryKeyConstraint( histKeyName );

    // add the sequence
    histTable.addSequence();

    // add the inheritance discriminator
    if ( entity.isInheritanceRoot() ) {
      def column = histTable.addDiscriminatorColumn( entity.discriminator );
      histTable.addIndex( column );
    }

    // add history-related columns
    def eColumn = histTable.addForeignKeyColumn( keyName, keyName, "The surrogate key for this " + entity.javaName.asDescription, false );

    def column = histTable.addForeignKeyColumn( "Start Action Id", "Start Action",
        "The action that brought this record into being",
        false );
    histTable.addForeignKeyConstraint( "Start Action Id",
        "The action that brought this record into being",
        column,
        dbDomain.parent.getRelationByName( "USER_ACTION" ),
        false );
    histTable.addIndex( column );
    histTable.addUniquenessConstraint( table.name+"_"+column.name, "Unique historical actions", [eColumn, column]);

    column = histTable.addForeignKeyColumn( "End Action Id", "End Action",
        "The action that made this record obsolete (null means current)",
        true );
    histTable.addForeignKeyConstraint( "End Action Id",
        "The action that made this record obsolete (null means current)",
        column,
        dbDomain.parent.getRelationByName( "USER_ACTION" ),
        false );
    histTable.addIndex( column );
    histTable.addUniquenessConstraint( table.name+"_"+column.name, "Unique historical actions", [eColumn, column]);

    histTable.addAttributeColumn( "Update Date", "Update Date",
        "The date and time this record was last changed",
        EDbDataType.TIMESTAMP,
        null,
        null,
        false,
        null );

    // add attributes
    entity.attributes.each{ attribute ->
      def acolumn = histTable.addAttributeColumn( attribute.sqlName.asIdentifier,
          attribute.name,
          attribute.description,
          this.getDbType( attribute.dataType ),
          attribute.obfuscated ? 3*attribute.maxLength : attribute.maxLength,
          attribute.precision,
          true,
          attribute.defaultValue );

      if ( attribute.indexed ) {
        histTable.addIndex( acolumn );
      }
    }

    // add relationships
    entity.relationships.each{ relationship ->
      def rcolumn = histTable.addForeignKeyColumn( relationship.sqlName.asIdentifier,
          relationship.name,
          relationship.description,
          true );
      histTable.addIndex( rcolumn );
    }

    // link the history table to its main table
    table.setHistoryTable( histTable );

    // add insert trigger
    def code = "";
    code <<= '-- Insert the audit record\n';
    code << 'INSERT INTO ' << entity.sqlName.historyTable << '\n'
    code << '          ( ' << entity.sqlName.historyUniqueId << ', ' << entity.sqlName.uniqueId << ', START_ACTION_ID, END_ACTION_ID, UPDATE_DATE';
    entity.attributes.each {
      code << ', ' << it.sqlName.column;
    }
    entity.relationships.each {
      code << ', ' << it.sqlName.column;
    }
    code << ' )\n';
    code << '   VALUES ( ' << entity.sqlName.historySequence << '.NEXTVAL, :NEW.' << entity.sqlName.uniqueId;
    code << ', :NEW.LATEST_ACTION_ID, NULL, :NEW.UPDATE_DATE';
    entity.attributes.each {
      code << ', :NEW.' << it.sqlName.column;
    }
    entity.relationships.each {
      code << ', :NEW.' << it.sqlName.column;
    }
    code << ' );\n \n';

    table.addTrigger( EDbTriggerType.AFTER_INSERT, "Create the trigger to automatically capture history", code.toString() );

    // add update trigger
    code = "";

    code <<= '-- Obsolete the prior attributes\n';
    code << 'UPDATE ' << entity.sqlName.historyTable << '\n';
    code << '   SET END_ACTION_ID = :NEW.LATEST_ACTION_ID\n';
    code << ' WHERE ' << entity.sqlName.uniqueId << ' = :NEW.' << entity.sqlName.uniqueId << '\n';
    code << '   AND END_ACTION_ID IS NULL;\n';
    code << '\n';
    code << '-- If we\'re not using the special "delete" idiom (non-null IS_DELETED flag)\n';
    code << 'IF :NEW.IS_DELETED IS NULL THEN\n';
    code << '  -- Insert the new attributes\n';
    code << '  INSERT INTO ' << entity.sqlName.historyTable << '\n';
    code << '            ( ' << entity.sqlName.historyUniqueId << ', ' << entity.sqlName.uniqueId << ', START_ACTION_ID, END_ACTION_ID, UPDATE_DATE';
    entity.attributes.each {
      code << ', ' << it.sqlName.column;
    }
    entity.relationships.each {
      code << ', ' << it.sqlName.column;
    }
    code << ' )\n';
    code << '     VALUES ( ' << entity.sqlName.historySequence << '.NEXTVAL, :NEW.' << entity.sqlName.uniqueId;
    code << ', :NEW.LATEST_ACTION_ID, NULL, :NEW.UPDATE_DATE';
    entity.attributes.each {
      code << ', :NEW.' << it.sqlName.column;
    }
    entity.relationships.each {
      code << ', :NEW.' << it.sqlName.column;
    }
    code << ' );\n';
    code << 'END IF;\n';
    code << ' \n';

    table.addTrigger(EDbTriggerType.AFTER_UPDATE, "Create the trigger to capture updates history", code.toString() );

  }

  /** Returns the SQL data type for the given model data type. */
  EDbDataType getDbType( DataType dataType ) {
    if ( dataType instanceof StringDataType ) {
      return EDbDataType.VARCHAR2;
    }
    if ( dataType instanceof BooleanDataType ) {
      return EDbDataType.BOOLEAN;
    }
    if ( dataType instanceof DateDataType ) {
      return EDbDataType.DATE;
    }
    if ( dataType instanceof TimeStampDataType ) {
      return EDbDataType.TIMESTAMP;
    }
    if ( dataType instanceof BlobDataType ) {
      return EDbDataType.BLOB;
    }
    if ( dataType instanceof UnicodeStringDataType ) {
      return EDbDataType.NVARCHAR2;
    }

    return EDbDataType.INTEGER;
  }

  /** Returns the unique ID for an entity; uses the base class if present. */
  private String getUniqueId( Entity entity ) {
    if ( entity.baseClass != null ) {
      return getUniqueId( entity.baseClass );
    }

    return entity.sqlName.uniqueId;
  }
}
