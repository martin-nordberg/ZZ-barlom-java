
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbIndex
  extends DbNamedModelElement {

  /**
   * Constructs a new index.
   */
  DbIndex( DbTable parent, DbColumn column ) {
    super( parent, column.getName(), "Index for " + column.getDescription() );

    this.column = column;

    parent.onAddChild( this );
  }

  /** Returns the column. */
  public DbColumn getColumn() {
    return this.column;
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( "IDX", this.getParent().getName(), this.getName() );
  }

  /**
   * Sets the column.
   * @param column The new value for column.
   */
  public void setColumn( DbColumn column ) {
    this.column = column;
  }

  private DbColumn column;

}
