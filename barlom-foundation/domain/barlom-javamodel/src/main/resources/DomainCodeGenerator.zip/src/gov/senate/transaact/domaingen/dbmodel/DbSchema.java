
package gov.senate.transaact.domaingen.dbmodel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gov.senate.transaact.domaingen.model.Domain;

/**
 * @author Vangent, Inc.
 */
public class DbSchema
  extends DbNamedModelElement {

  /**
   * Constructs a new schema.
   */
  public DbSchema( String name, String description ) {
    super( null, name, description );

    this.domainsByName = new HashMap<>();
    this.domains = new ArrayList<>();
    this.relationsByName = new HashMap<>();
  }

  /**
   * Creates a new domain within this schema.
   */
  public DbDomain addDomain(
      String name,
      String description,
      boolean hasSqlCustomizations,
      Domain modelDomain ) {
    return new DbDomain( this, name, description, hasSqlCustomizations, modelDomain );
  }

  /** Returns the domain within this schema with given name. */
  public DbDomain getDomainByName( String name ) {
    return this.domainsByName.get( name );
  }

  /** Returns the domains within this schema. */
  public List<DbDomain> getDomains() {
    return this.domains;
  }

  /** Returns the table or view within this schema with given name. */
  public DbRelation getRelationByName( String name ) {
    return this.relationsByName.get( DbNamedModelElement.makeSqlName( name ) );
  }

  /** {@inheritDoc} */
  @Override
  public DbSchema getSchema() {
    return this;
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( this.getName() );
  }

  /** Returns the table or view within this schema with given name. */
  public DbTable getTableByName( String name ) {
    DbRelation result = this.getRelationByName( name );

    if ( result instanceof DbTable ) {
      return (DbTable) result;
    }

    return null;
  }

  /** Register the addition of a domain to this schema. */
  void onAddChild( DbDomain domain ) {
    String domainName = domain.getName();

    assert this.domainsByName.get( domainName ) == null : "Duplicate domain name: "
        + domainName;

    super.onAddChild( domain );

    this.domainsByName.put( domainName, domain );
    this.domains.add( domain );
  }

  /** Sets the table or view within this schema with given name. */
  void putRelationByName( String name, DbRelation relation ) {
    this.relationsByName.put( DbNamedModelElement.makeSqlName( name ), relation );
  }

  private List<DbDomain> domains;

  private Map<String, DbDomain> domainsByName;

  private Map<String, DbRelation> relationsByName;

}
