
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Writer for the implementation of an entity. */
class JavaImplementationWriter
extends JavaEntitiesWriter {

  /** Returns the name of the implementation for a given entity. */
  protected String getClassName( Entity entity ) {
    return entity.javaName.implementationClass;
  }

  /** Returns the list of imports needed by an entity's implementation. */
  private List<String> getImportedPackages( Entity entity ) {

    Set result = new HashSet();

    // validation
    result.add( 'java.util.List' );
    if ( entity.baseClass == null ) {
      result.add( 'java.util.ArrayList' );
    }

    // JPA imports always needed
    result.add( 'javax.persistence.*' );

    // the base class for this entity
    if ( entity.baseClass ) {
      if ( entity.parent != entity.baseClass.parent ) {
        result.add( entity.baseClass.javaName.implementationClassFullyQualified );
      }
    }
    else {
      result.add( 'gov.senate.transaact.jpa.datamodel.JpaDomainModelEntity' );
      if ( entity.isTemporal() ) {
        result.add( 'gov.senate.transaact.common.domainmodel.ITemporalDomainModelEntity' );
      }
    }

    // base class constants for attribute change management
    if ( entity.attributes ) {
      result.add( 'gov.senate.transaact.jpa.datamodel.JpaDomainModelEntity' );
    }

    // EclipseLink extensions
    if ( entity.relationships.find { relationship -> relationship.required } ) {
      result.add( 'org.eclipse.persistence.annotations.JoinFetch' );
      result.add( 'org.eclipse.persistence.annotations.JoinFetchType' );
    }

    // each related entity's interface
    entity.relationships.each { relationship ->
      result.add( relationship.relatedEntity.javaName.implementationClassFullyQualified );

      if ( relationship.relatedEntity.parent != entity.parent ) {
        result.add( relationship.relatedEntity.javaName.implementationClassFullyQualified );
      }
    }

    // user actions for temporal classes
    if ( entity.isTemporal() ) {
      result.add( 'gov.senate.transaact.common.organization.domainmodel.UserAction' );
      result.add( 'java.util.Date' );
    }

    // java.util.Date, if needed
    entity.attributes.each { attribute ->
      if ( attribute.dataType.isDateType ) {
        result.add( 'java.util.Date' );
        result.add( 'gov.senate.transaact.common.util.DateUtil' );
      }
      if ( attribute.dataType.isBlobType ) {
        result.add( 'java.io.ByteArrayInputStream' );
        result.add( 'java.io.ByteArrayOutputStream' );
        result.add( 'java.io.InputStream' );
        result.add( 'java.io.IOException' );
      }
      if ( attribute.obfuscated ) {
        result.add( 'gov.senate.transaact.common.util.obfuscation.config.ObfuscationConfiguration' );
      }
      if ( attribute.autoTruncated ) {
        result.add( 'gov.senate.transaact.common.util.StringUtil' );
      }
      if ( attribute.optional ) {
        result.add( 'com.google.common.base.Optional' );
      }
    }

    // List class, if needed
    if ( entity.aggregations ) {
      result.add( 'java.util.List' );
      result.add( 'java.util.ArrayList' );

      entity.aggregations.each {
        result.add( it.parent.javaName.implementationClassFullyQualified );
      }
    }

    return result.sort();
  }

  /** Returns the list of imports needed by an enum entity's implementation. */
  private List<String> getImportedPackages( EnumeratedEntity entity ) {

    Set result = new HashSet();

    result.add( 'java.util.ArrayList' );
    result.add( 'java.util.HashMap' );
    result.add( 'java.util.List' );
    result.add( 'java.util.Map' );

    return result.sort();
  }

  /** Writes an aggregation implementation. */
  private void writeAggregation( Relationship relationship ) {
    nextLine() << '/** The collection of ' << relationship.parent.description << '. */';
    nextLine() << '@OneToMany( mappedBy = "' << relationship.javaName.field << '", fetch = FetchType.LAZY';
    if ( relationship.persistedWithParent ) {
      sameLine() << ", cascade = CascadeType.ALL";
    }
    sameLine() << ' )';
    nextLine() << 'private List<' << relationship.parent.javaName.implementationClass << '> ' << new JavaName( relationship.aggregationName ).field << ' = new ArrayList<>();';
    nextLine();
    nextLine() << '/** @return the collection of ' << relationship.parent.description << '. */';
    nextLine() << 'public List<' << relationship.parent.javaName.implementationClass << '> ' << new JavaName( relationship.aggregationName ).getter << '() {';
    ++indent;
    nextLine() << 'ArrayList<' << relationship.parent.javaName.implementationClass << '> result = new ArrayList<>();';
    nextLine() << 'result.addAll( ' << new JavaName( relationship.aggregationName ).field << ' );';
    nextLine() << 'return result;';
    --indent;
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Adds the given ' << relationship.parent.javaName.asDescription << ' to this ' << relationship.relatedEntity.javaName.asDescription << '.';
    nextLine() << ' * @param ' << relationship.parent.javaName.setterParameter << ' The ' << relationship.parent.javaName.asDescription << ' to add.';
    nextLine() << ' */';
    nextLine() << 'void ' << relationship.parent.javaName.adder << '( ' << relationship.parent.javaName.implementationClass << ' ' << relationship.parent.javaName.setterParameter << ' ) {';
    nextLine() << indent() << 'this.' << new JavaName( relationship.aggregationName ).field << '.add( ' << relationship.parent.javaName.setterParameter << ' );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Removes the given ' << relationship.parent.javaName.asDescription << ' from this ' << relationship.relatedEntity.javaName.asDescription << '.';
    nextLine() << ' * @param ' << relationship.parent.javaName.setterParameter << ' The ' << relationship.parent.javaName.asDescription << ' to add.';
    nextLine() << ' */';
    nextLine() << 'void ' << relationship.parent.javaName.remover << '( ' << relationship.parent.javaName.implementationClass << ' ' << relationship.parent.javaName.setterParameter << ' ) {';
    nextLine() << indent() << 'this.' << new JavaName( relationship.aggregationName ).field << '.remove( ' << relationship.parent.javaName.setterParameter << ' );';
    nextLine() << '}';
    nextLine();
  }

  /** Writes the implementation of an attribute field. */
  private void writeAttribute( Attribute attribute ) {
    nextLine() << '/** ' << attribute.description << '. */';
    nextLine() << '@Column( name = "' << attribute.sqlName.column << '" )';
    if ( attribute.dataType.isBlobType ) {
      nextLine() << '@Lob';
    }
    if ( attribute.dataType.isDateType ) {
      nextLine() << '@Temporal( TemporalType.' << attribute.dataType.sqlName.asIdentifier << ' )';
    }
    nextLine() << 'private ' << attribute.dataType.javaName.asIdentifier << ' ' << attribute.javaName.field;
    if ( attribute.defaultValue ) {
      sameLine() << ' = ' << attribute.dataType.valueForJava( attribute.defaultValue );
    }
    sameLine() << ';';
    nextLine();
    nextLine() << '/** @return the value of ' << attribute.description << '. */';
    nextLine() << 'public '
    if ( attribute.optional ) {
      sameLine() << 'Optional<' << attribute.dataType.javaName.asIdentifier << '>';
    }
    else {
      sameLine() << attribute.dataType.javaName.asIdentifier;
    }
    sameLine() << ' ' << attribute.javaName.getter << '() {';
    ++indent;
    if ( attribute.obfuscated && attribute.optional ) {
      nextLine() << 'return Optional.of( ObfuscationConfiguration.deobfuscate( this.' << attribute.javaName.field << ' ) );';
    }
    else if ( attribute.obfuscated ) {
      nextLine() << 'return ObfuscationConfiguration.deobfuscate( this.' << attribute.javaName.field << ' );';
    }
    else if ( attribute.optional ) {
      nextLine() << 'return Optional.fromNullable( this.' << attribute.javaName.field << ' );';
    }
    else {
      nextLine() << 'return this.' << attribute.javaName.field << ';';
    }
    --indent;
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << attribute.description << '.';
    nextLine() << ' * @param ' << attribute.javaName.setterParameter << ' The new value for ' << attribute.javaName.asDescription << '.';
    nextLine() << ' */';
    nextLine() << 'public void ' << attribute.javaName.setter << '( ' << attribute.dataType.javaName.asIdentifier << ' ' << attribute.javaName.setterParameter << ' ) {';
    if ( attribute.defaultValue ) {
      ++indent;
      nextLine() << 'if ( ' << attribute.javaName.setterParameter << ' == null ) {'
      nextLine() << indent() << 'this.' << attribute.javaName.field << ' = ' << attribute.dataType.valueForJava( attribute.defaultValue ) << ';';
      nextLine() << '}';
      nextLine() << 'else {';
      nextLine() << indent() << 'this.' << attribute.javaName.field << ' = ';
      if ( attribute.autoTruncated ) {
        sameLine() << "StringUtil.truncateByUtf8ByteCount( " << attribute.javaName.setterParameter << ", " << attribute.maxLength << " );"
      }
      else {
        sameLine() << attribute.javaName.setterParameter << ';';
      }
      nextLine() << '}';
      if ( attribute.dataType.isDateType ) {
        nextLine() << 'this.' << attribute.javaName.field << ' = DateUtil.restrictToReasonableYears( ' << 'this.' << attribute.javaName.field << ' );';
      }
      --indent;
    }
    else if ( attribute.autoTruncated || attribute.obfuscated ) {
      String locVariable = attribute.javaName.setterParameter + "Loc";
      ++indent;
      nextLine() << attribute.dataType.javaName.asIdentifier << " " << locVariable << " = " << attribute.javaName.setterParameter << ';';
      nextLine() << 'if ( ' << locVariable << ' != null ) {'
      ++indent;
      if ( attribute.autoTruncated ) {
        nextLine() << locVariable << " = ";
        sameLine() << "StringUtil.truncateByUtf8ByteCount( " << locVariable << ", " << attribute.maxLength << " );";
      }
      if ( attribute.obfuscated ) {
        nextLine() << locVariable << " = ObfuscationConfiguration.obfuscate( " << locVariable << " );";
      }
      if ( attribute.dataType.isDateType ) {
        nextLine() << locVariable << ' = DateUtil.restrictToReasonableYears( ' << locVariable << ' );';
      }
      --indent;
      nextLine() << '}';

      nextLine() << 'this.trackChange( this.' << attribute.javaName.field << ', ' << locVariable << ' );';
      nextLine() << 'this.' << attribute.javaName.field << ' = ' << locVariable << ';';
      --indent;
    }
    else {
      ++indent;
      nextLine() << 'this.trackChange( this.' << attribute.javaName.field << ', ' << attribute.javaName.setterParameter << ' );';
      if ( attribute.dataType.isDateType ) {
        nextLine() << 'this.' << attribute.javaName.field << ' = DateUtil.restrictToReasonableYears( ' << attribute.javaName.setterParameter << ' );';
      }
      else {
        nextLine() << 'this.' << attribute.javaName.field << ' = ' << attribute.javaName.setterParameter << ';';
      }
      --indent;
    }

    nextLine() << '}';
    nextLine();
  }

  private void writeChangeMethods( Entity entity ) {
  }

  private void writeChangeMethods( TemporalEntity entity ) {
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << '@Override';
    nextLine() << 'protected <T> boolean trackChange( T oldValue, T newValue ) {';
    nextLine() << '  if ( super.trackChange( oldValue, newValue ) ) {';
    nextLine() << '    this.updateDate = new Date();';
    nextLine() << '    return true;';
    nextLine() << '  }';
    nextLine() << '  return false;';
    nextLine() << '}';
    nextLine();
  }

  protected void writeEntity( Entity entity ) {

    // package declaration
    nextLine() << 'package ' << entity.parent.javaName.implementationPackage << ';';
    nextLine();

    // import declarations
    getImportedPackages( entity ).each {
      nextLine() << 'import ' << it << ';';
    }
    nextLine();

    // custom extended imports
    writeCustomCodeSegment( "imports" )
    nextLine();

    // class declaration
    nextLine() << '/**';
    nextLine() << ' * ' << entity.description;
    nextLine() << ' * @author Vangent, Inc. (NOTE: SCRIPT-GENERATED CODE; DO NOT HAND EDIT EXCEPT IN MARKED AREAS)';
    nextLine() << ' */';
    nextLine() << '@Entity';
    nextLine() << '@Table( name = "' << entity.sqlName.table << '" )';
    if ( entity.isInheritanceRoot() ) {
      nextLine() << '@Inheritance( strategy = InheritanceType.JOINED )';
      nextLine() << '@DiscriminatorColumn( name = "DISCRIMINATOR", discriminatorType = DiscriminatorType.STRING, length = 1 )';
    }
    if ( entity.discriminator ) {
      nextLine() << '@DiscriminatorValue( "' << entity.discriminator << '" )';
    }
    nextLine() << 'public ';
    sameLine() << 'class ' << entity.javaName.implementationClass;
    ++indent;
    if ( entity.baseClass != null ) {
      nextLine() << 'extends ' << entity.baseClass.javaName.implementationClass;
    }
    else {
      nextLine() << 'extends JpaDomainModelEntity<' << entity.javaName.implementationClass << '>';
      if ( entity.isTemporal() ) {
        nextLine() << 'implements ITemporalDomainModelEntity<' << entity.javaName.implementationClass << '>';
      }
    }
    sameLine() << ' {';
    nextLine();

    // custom behavior
    writeCustomCodeSegment( "methods" )
    nextLine();

    nextLine() << '/** Serialization version number. */';
    nextLine() << 'private static final long serialVersionUID = 1L;';
    nextLine();

    // getFieldsToString
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << '@Override';
    nextLine() << 'protected String getFieldsToString() {';
    ++indent;
    nextLine() << 'String result = super.getFieldsToString();';
    entity.attributes.each { attribute ->
      if ( !attribute.dataType.isBlobType ) {
        nextLine() << 'result += ",' << attribute.javaName.field << '=" + this.' << attribute.javaName.getter << '();';
      }
    }
    entity.relationships.each {
      nextLine() << 'if ( this.' << it.javaName.getter << '() != null ) {';
      nextLine() << indent() << 'result += ",' << it.javaName.field << '=" + this.' << it.javaName.getter << '().getUniqueId();';
      nextLine() << '}';
    }
    nextLine() << 'return result;';
    --indent;
    nextLine() << '}';
    nextLine();

    // validate
    writeValidation( entity );

    // the unique ID for the entity
    if ( entity.baseClass == null ) {
      nextLine() << '/** The unique ID of this ' << entity.javaName.asDescription << '. */';
      nextLine() << '@Id';
      nextLine() << '@Column( name = "' << entity.sqlName.uniqueId << '" )';
      nextLine() << '@SequenceGenerator( name = "' << entity.sqlName.sequence << '", allocationSize = 1 )';
      nextLine() << '@GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "' << entity.sqlName.sequence << '" )';
      nextLine() << 'private Long ' << entity.javaName.uniqueId << ';';
      nextLine();
      nextLine() << '/** {@inheritDoc} */';
      nextLine() << 'public Long getUniqueId() {';
      nextLine() << indent() << 'return this.' << entity.javaName.uniqueId << ';';
      nextLine() << '}';
      nextLine();
      nextLine() << '/** {@inheritDoc} */';
      nextLine() << 'public void setUniqueId( Long uniqueId ) {';
      ++indent;
      nextLine() << 'this.trackChange( this.' << entity.javaName.uniqueId << ', uniqueId );';
      nextLine() << 'this.' << entity.javaName.uniqueId << ' = uniqueId;';
      --indent;
      nextLine() << '}';
      nextLine();
    }

    writeTemporalAttributes( entity );

    // relationships
    entity.relationships.each { writeRelationship( it ); }

    // onRemoval
    writeRemoveFromAggregations( entity );

    // aggregations
    entity.aggregations.each { writeAggregation( it ); }

    // attributes
    entity.attributes.each { writeAttribute( it ); }

    writeChangeMethods( entity );

    // instance IDs
    entity.instances.each { instance ->
      writeInstanceConstants( entity, instance );
    }

    // instance Tests
    entity.instances.each { instance ->
      writeInstanceTest( instance, true );
    }

    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes an enumeration. */
  protected void writeEntity( EnumeratedEntity entity ) {

    // package declaration
    nextLine() << 'package ' << entity.parent.javaName.implementationPackage << ';';
    nextLine();

    // import declarations
    getImportedPackages( entity ).each {
      nextLine() << 'import ' << it << ';';
    }
    nextLine();

    // custom extended imports
    writeCustomCodeSegment( "imports" )
    nextLine();

    // class declaration
    nextLine() << '/**';
    nextLine() << ' * ' << entity.description;
    nextLine() << ' * @author Vangent, Inc. (NOTE: SCRIPT-GENERATED CODE; DO NOT HAND EDIT EXCEPT IN MARKED AREAS)';
    nextLine() << ' */';
    nextLine() << 'public enum ' << entity.javaName.implementationClass << ' {';
    ++indent;

    // enumeration constants
    writeInstances( entity );

    // constructor
    writeEnumConstructor( entity );

    // unique ID
    nextLine() << '/** The unique ID of this ' << entity.javaName.asDescription << '. */';
    nextLine() << 'private Long ' << entity.javaName.uniqueId << ';';
    nextLine();
    nextLine() << '/** @return the unique ID of this instance */';
    nextLine() << 'public Long getUniqueId() {';
    nextLine() << indent() << 'return this.' << entity.javaName.uniqueId << ';';
    nextLine() << '}';
    nextLine();

    // attributes
    entity.attributes.each { attribute ->
      writeEnumAttribute( attribute );
    }

    // relationships
    entity.relationships.each { relationship ->
      writeEnumRelationship( relationship );
    }

    // instance IDs
    entity.instances.each { instance ->
      writeInstanceConstants( entity, instance );
    }

    // instance Tests
    entity.instances.each { instance ->
      writeInstanceTest( instance, false );
    }

    // instance maps
    writeInstanceMaps( entity );

    // full list
    writeInstanceList( entity );

    // custom behavior
    writeCustomCodeSegment( "methods" )
    nextLine();

    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes the implementation of an attribute field in an enum. */
  private void writeEnumAttribute( Attribute attribute ) {
    nextLine() << '/** ' << attribute.description << '. */';
    nextLine() << 'private ' << attribute.dataType.javaName.asIdentifier << ' ' << attribute.javaName.field << ';';
    nextLine();
    nextLine() << '/** @return the value of ' << attribute.description << '. */';
    nextLine() << 'public ' << attribute.dataType.javaName.asIdentifier << ' ' << attribute.javaName.getter << '() {';
    nextLine() << indent() << 'return this.' << attribute.javaName.field << ';';
    nextLine() << '}';
    nextLine();
  }

  /** Writes the constructor for an enumeration. */
  private void writeEnumConstructor( Entity entity ) {
    nextLine() << '/** Constructs a ' << entity.description << ' */';
    nextLine() << 'private ' << entity.javaName.implementationClass << '( '
    sameLine() << 'Long ' << entity.javaName.uniqueId;
    entity.attributes.each { attribute ->
      sameLine() << ', ' << attribute.dataType.javaName.asIdentifier << ' ' << attribute.javaName.field;
    }
    entity.relationships.each { relationship ->
      sameLine() << ', ' << relationship.relatedEntity.javaName.asIdentifier << ' ' << relationship.javaName.field;
    }
    sameLine() << ' ) {';
    indent++;
    nextLine() << 'this.' << entity.javaName.uniqueId << ' = ' << entity.javaName.uniqueId << ';';
    entity.attributes.each { attribute ->
      nextLine() << 'this.' << attribute.javaName.field << ' = ' << attribute.javaName.field << ';';
    }
    entity.relationships.each { relationship ->
      nextLine() << 'this.' << relationship.javaName.field << ' = ' << relationship.javaName.field << ';';
    }
    indent--;
    nextLine() << '}';
    nextLine();
  }

  private void writeEnumRelationship( Relationship relationship ) {
    nextLine() << '/** ' << relationship.description << '. */';
    nextLine() << 'private ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.field << ';';
    nextLine();
    nextLine() << '/** @return the value of ' << relationship.description << '. */';
    nextLine() << 'public ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.getter << '() {';
    nextLine() << indent() << 'return this.' << relationship.javaName.field << ';';
    nextLine() << '}';
    nextLine();
  }

  /** Writes the enumeration constant for a reference instance. */
  private void writeInstances( Entity entity ) {
    String delimiter = "";
    entity.instances.each { instance ->
      sameLine() << delimiter;
      nextLine();
      nextLine() << '/** ' << instance.Description << '*/'
      nextLine() << instance.getReferencePrefix() << '( ';
      sameLine() << instance.UniqueId << 'L';
      entity.attributes.each { attribute ->
        sameLine() << ', ' << attribute.dataType.valueForJava( instance.get( attribute.javaName.asIdentifier ) );
      }
      entity.relationships.each { relationship ->
        sameLine() << ', ';
        sameLine() << relationship.relatedEntity.javaName.asIdentifier;
        sameLine() << '.';
        def relInstanceName = instance.get( relationship.javaName.asIdentifier );
        def relatedInstance = relationship.relatedEntity.instances.find { relInstance ->
          relInstance.get('Name') == relInstanceName
        }
        sameLine() << relatedInstance.getReferencePrefix();
      }
      sameLine() << ' )';
      delimiter = ",";
    }
    sameLine() << ";";
    nextLine();
    nextLine();
  }

  /** Writes the constants for the unique ID of a reference instance. */
  private void writeInstanceConstants( Entity entity, Instance instance ) {
    String referencePrefix = instance.getReferencePrefix();
    if ( referencePrefix != null ) {
      nextLine() << '/** The unique ID for ' << instance.get( instance.nameAttributeName ) << '. */';
      nextLine() << 'public static final Long ' << referencePrefix << '_ID = ' << instance.get( 'UniqueId' ) << 'L;';
      nextLine();

      entity.attributes.each { attribute ->
        if ( attribute.unique ) {
          String refName = attribute.javaName.getReferenceConstant( referencePrefix );

          nextLine() << '/** The reference constant for ' << instance.get( instance.nameAttributeName ) << ' instance ' << attribute.javaName.asDescription << '. */'
          nextLine() << 'public static final ' << attribute.dataType.javaName.asIdentifier << ' ' << refName;
          sameLine() << ' = ' << attribute.dataType.valueForJava( instance.get( attribute.javaName.asIdentifier ) ) << ";";
          nextLine();
        }
      }
    }
  }

  /** Writes a method to retrieve all instances of the enumeration. */
  private void writeInstanceList( Entity entity ) {
    nextLine() << '/** List of all reference values. */';
    nextLine() << 'private static List<' << entity.javaName.implementationClass << '> instances = new ArrayList<>();';
    nextLine();
    nextLine() << '/** Get the list of all instances. */'
    nextLine() << 'public static List<' << entity.javaName.implementationClass << '> getAll() {';
    nextLine() << indent() << 'return instances;';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** Initialize the list. */';
    nextLine() << 'static {';
    ++indent;
    entity.instances.each { instance ->
      nextLine() << 'instances.add( ' << instance.getReferencePrefix() << ' );';
    }
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes maps to get enum values by their unique attributes. */
  private void writeInstanceMap( Entity entity, String keyType, String keyName, String keyValueSuffix ) {
    nextLine() << '/** Map of reference values from their unique IDs */';
    nextLine() << 'private static Map<' << keyType << ',' << entity.javaName.implementationClass << '> instancesBy' << keyName << ' = new HashMap<>();';
    nextLine();
    nextLine() << '/** Get a reference value from its unique ID. */'
    nextLine() << 'public static ' << entity.javaName.implementationClass << ' getBy' << keyName << '( ' << keyType << ' key ) {';
    nextLine() << indent() << 'return instancesBy' << keyName << '.get( key );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** Initialize the map. */';
    nextLine() << 'static {';
    ++indent;
    entity.instances.each { instance ->
      nextLine() << 'instancesBy' << keyName << '.put( ' << instance.getReferencePrefix() << keyValueSuffix << ', ' << instance.getReferencePrefix() << ' );';
    }
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes maps to get enum values by their unique attributes. */
  private void writeInstanceMaps( Entity entity ) {

    // Unique ID
    writeInstanceMap( entity, 'Long', 'UniqueId', '_ID' );

    // each unique attribute
    entity.attributes.each{ attribute ->
      if ( attribute.unique ) {
        String keyType = attribute.dataType.javaName.asIdentifier;
        String keyName = attribute.javaName.asIdentifier;
        String keyValueSuffix = attribute.javaName.getReferenceConstant( '' );

        writeInstanceMap( entity, keyType, keyName, keyValueSuffix );
      }
    }
  }

  /** Writes a boolean test for a reference instance. */
  private void writeInstanceTest( Instance instance, boolean longIds ) {
    if ( instance.getReferencePrefix() != null ) {
      nextLine() << '/** @return whether this instance matches ' << instance.get( instance.nameAttributeName ) << '. */';
      nextLine() << 'public boolean ' << instance.getJavaName().instanceTest << '() {'
      String javaInterface = instance.getParent().javaName.implementationClass;
      if ( longIds ) {
        nextLine() << indent() << 'return ' << javaInterface << '.' << instance.getReferencePrefix() << '_ID.equals( this.getUniqueId() );';
      }
      else {
        nextLine() << indent() << 'return ' << javaInterface << '.' << instance.getReferencePrefix() << '_ID == this.getUniqueId();';
      }
      nextLine() << '}';
      nextLine();
    }
  }

  /** Writes the removeFromAggregations method for an entity. */
  private void writeRemoveFromAggregations( Entity entity ) {

    if ( entity.relationships.find { relationship -> relationship.aggregated } ) {

      nextLine() << '/** {@inheritDoc} */';
      nextLine() << '@Override';
      nextLine() << 'public void removeFromAggregations() {';
      indent++;
      nextLine() << 'super.removeFromAggregations();';

      entity.relationships.each { relationship ->
        if ( relationship.aggregated ) {
          nextLine();
          nextLine() << 'if ( this.' << relationship.javaName.getter << '() != null ) {';
          nextLine() << indent() << relationship.javaName.getter << '().' << entity.javaName.remover << '( this );';
          nextLine() << '}';
        }
      }

      indent--;
      nextLine() << '}';
      nextLine();
    }
  }

  private void writeRelationship( Relationship relationship ) {
    if ( relationship.relatedEntity.enumerated ) {
      writeRelationshipToEnum( relationship );
      return;
    }

    nextLine() << '/** ' << relationship.description << '. */';
    if ( relationship.oneToOne ) {
      nextLine() << '@OneToOne( optional = ' << ( relationship.required ? 'false':'true' );
      if ( relationship.persistedWithParent ) {
        sameLine() << ", cascade = CascadeType.ALL";
      }
      if ( !relationship.loadedWithParent ) {
        sameLine() << ", fetch = FetchType.LAZY";
      }
      sameLine() << ' )';
    }
    else {
      nextLine() << '@ManyToOne( optional = ' << ( relationship.required ? 'false':'true' ) << ' )';
    }
    nextLine() << '@JoinColumn( name = "' << relationship.sqlName.column << '" )';
    if ( relationship.required ) {
      nextLine() << '@JoinFetch( JoinFetchType.INNER )';
    }
    nextLine() << 'private ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.field << ';';
    nextLine();
    nextLine() << '/** @return the value of ' << relationship.description << '. */';
    nextLine() << 'public ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.getter << '() {';
    nextLine() << indent() << 'return this.' << relationship.javaName.field << ';';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << relationship.description << '.';
    nextLine() << ' * @param ' << relationship.javaName.setterParameter << ' The new value for ' << relationship.javaName.asDescription << '.';
    nextLine() << ' */';
    nextLine() << 'public void ' << relationship.javaName.setter << '( ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.setterParameter << ' ) {';
    ++indent;
    if ( relationship.aggregated ) {
      nextLine() << 'if ( ' << relationship.javaName.getter << '() != null ) {';
      nextLine() << indent() << relationship.javaName.getter << '().' << relationship.parent.javaName.remover << '( this );';
      nextLine() << '}';
    }

    nextLine() << 'this.trackChange( this.' << relationship.javaName.field << ', ' << relationship.javaName.setterParameter << ' );';
    nextLine() << 'this.' << relationship.javaName.field << ' = ' << relationship.javaName.setterParameter << ';';
    if ( relationship.aggregated ) {
      nextLine() << relationship.javaName.setterParameter << '.' << relationship.parent.javaName.adder << '( this );';
    }
    --indent;
    nextLine() << '}';
    nextLine();
  }

  private void writeRelationshipToEnum( Relationship relationship ) {
    nextLine() << '/** ' << relationship.description << '. */';
    nextLine() << '@Column( name = "' << relationship.sqlName.column << '" )';
    nextLine() << 'private Long ' << relationship.javaName.field << 'Id;';
    nextLine();
    nextLine() << '/** @return the value of ' << relationship.description << '. */';
    nextLine() << 'public ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.getter << '() {';
    nextLine() << indent() << 'return ' << relationship.relatedEntity.javaName.implementationClass << '.getByUniqueId( this.' << relationship.javaName.field << 'Id );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << relationship.description << '.';
    nextLine() << ' * @param ' << relationship.javaName.setterParameter << ' The new value for ' << relationship.javaName.asDescription << '.';
    nextLine() << ' */';
    nextLine() << 'public void ' << relationship.javaName.setter << '( ' << relationship.relatedEntity.javaName.implementationClass << ' ' << relationship.javaName.setterParameter << ' ) {';
    ++indent;
    nextLine() << 'Long ' << relationship.javaName.setterParameter << 'Id = null;';
    nextLine() << 'if ( ' << relationship.javaName.setterParameter << ' != null ) {';
    nextLine() << indent() << relationship.javaName.setterParameter << 'Id = ' << relationship.javaName.setterParameter <<'.getUniqueId();';
    nextLine() << '}';
    nextLine() << 'this.trackChange( this.' << relationship.javaName.field << 'Id, ' << relationship.javaName.setterParameter << 'Id );';
    nextLine() << 'this.' << relationship.javaName.field << 'Id = ' << relationship.javaName.setterParameter << 'Id;';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  private void writeTemporalAttributes( Entity entity ) {
  }

  private void writeTemporalAttributes( TemporalEntity entity ) {

    // latestAction
    String description = 'the latest user action to affect this ' + entity.javaName.asDescription;

    nextLine() << '/** The unique ID of the latest user action that affected this ' << entity.javaName.asDescription << '. */';
    nextLine() << '@Column( name = "LATEST_ACTION_ID" )';
    nextLine() << 'private Long latestUserActionId;';
    nextLine();
    nextLine() << '/** The new latest user action that affected this ' << entity.javaName.asDescription << '. */';
    nextLine() << '@Transient';
    nextLine() << 'private UserAction unpersistedLatestUserAction;';
    nextLine();
    nextLine() << '/** @return the unique ID of ' << description << '. */';
    nextLine() << 'public Long getLatestUserActionId() {';
    ++indent;
    nextLine() << 'if ( this.unpersistedLatestUserAction != null ) {';
    nextLine() << indent() << 'return this.unpersistedLatestUserAction.getUniqueId();';
    nextLine() << '}';
    nextLine() << 'return this.latestUserActionId;';
    --indent;
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Changes the value of ' << description << '.';
    nextLine() << ' * @param action The new value for latest user action.';
    nextLine() << ' */';
    nextLine() << 'public void setLatestUserAction( UserAction action ) {';
    ++indent;
    nextLine() << 'assert !action.needsPersisting() : "User action must be fully persisted before being set";';
    nextLine() << 'this.latestUserActionId = action.getUniqueId();';
    --indent;
    nextLine() << '}';
    nextLine();

    // isDeleted
    nextLine() << '@Column( name = "IS_DELETED" )';
    nextLine() << 'private Long isDeleted;';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public boolean isDeleted() {';
    nextLine() << indent() << 'return this.isDeleted != null;';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public void setDeleted( boolean deleted ) {';
    ++indent;
    nextLine() << 'assert deleted;';
    nextLine() << 'trackChange( this.isDeleted, 1L );';
    nextLine() << 'this.isDeleted = 1L;';
    --indent;
    nextLine() << '}';
    nextLine();

    // updateDate
    nextLine() << '/** The date of the latest user action that affected this ' << entity.javaName.asDescription << '. */';
    nextLine() << '@Column( name = "UPDATE_DATE" )';
    nextLine() << '@Temporal( TemporalType.TIMESTAMP )';
    nextLine() << 'private Date updateDate = new Date();';
    nextLine();
    nextLine() << '@Transient';
    nextLine() << 'private boolean explicitlyMarkedAsUpdated = false;';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public Date getUpdateDate() {';
    nextLine() << indent() << 'return this.updateDate;';
    nextLine() << '}';
    nextLine();
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public void markAsUpdated() {';
    ++indent;
    nextLine() << 'this.trackChange( this.explicitlyMarkedAsUpdated, true );';
    nextLine() << 'this.explicitlyMarkedAsUpdated = true;';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes entity validation code. */
  private void writeValidation( Entity entity ) {

    // getValidationMessages()
    nextLine() << '/** {@inheritDoc} */';
    nextLine() << 'public List<String> getValidationMessages() {';
    ++indent;
    if ( entity.baseClass == null ) {
      nextLine() << 'List<String> messages = new ArrayList<>();';
    }
    else {
      nextLine() << 'List<String> messages = super.getValidationMessages();';
    }
    entity.attributes.each { attribute ->
      if ( attribute.optional && attribute.maxLength ) {
        nextLine() << 'if ( this.' << attribute.javaName.getter << '().isPresent() && this.' << attribute.javaName.getter << '().get().length() > ' << attribute.maxLength << ' ) {';
        nextLine() << indent() << 'messages.add( "' << attribute.name << ' can be at most ' << attribute.maxLength << ' characters." );';
        nextLine() << '}';
      }
      else {
        if ( attribute.required ) {
          nextLine() << 'if ( this.' << attribute.javaName.getter << '() == null ';
          if ( attribute.dataType == DataType.stringDataType ) {
            sameLine() << '|| this.' << attribute.javaName.getter << '().length() == 0 ';
          }
          sameLine() << ') {';
          nextLine() << indent() << 'messages.add( "Missing ' << attribute.name << '." );';
          nextLine() << '}';
        }

        if ( attribute.maxLength ) {
          nextLine() << 'if ( this.' << attribute.javaName.getter << '() != null && this.' << attribute.javaName.getter << '().length() > ' << attribute.maxLength << ' ) {';
          nextLine() << indent() << 'messages.add( "' << attribute.name << ' can be at most ' << attribute.maxLength << ' characters." );';
          nextLine() << '}';
        }
      }
    }
    entity.relationships.each {
      if ( it.required ) {
        nextLine() << 'if ( this.' << it.javaName.getter << '() == null ) {';
        nextLine() << indent() << 'messages.add( "Missing ' << it.name << '." );';
        nextLine() << '}';
        if ( !it.relatedEntity.enumerated ) {
          nextLine() << 'else {';
          nextLine() << indent() << 'messages.addAll( this.' << it.javaName.getter << '().getValidationMessages() );';
          nextLine() << '}';
        }
      }
    }

    // custom extended imports
    nextLine();
    writeCustomCodeSegment( "validation" )
    nextLine();

    nextLine() << 'return messages;';
    --indent;
    nextLine() << '}';
    nextLine();
  }
}