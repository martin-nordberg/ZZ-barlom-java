
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbSequence
  extends DbNamedModelElement {

  /**
   * Constructs a new sequence for a given table.
   */
  DbSequence( DbTable parent ) {
    super( parent, parent.getName(), parent.getDescription() );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( "SEQ", this.getName() );
  }

}
