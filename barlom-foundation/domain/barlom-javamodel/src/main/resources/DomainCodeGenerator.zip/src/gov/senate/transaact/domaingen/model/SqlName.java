
package gov.senate.transaact.domaingen.model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Encapsulation of the rules for computing names of SQL code elements.
 */
public class SqlName {

  /** Constructs a SQL name for a given name. */
  public SqlName( String name ) {
    this.name = name;
  }

  /** Returns the identifier for a foreign key. */
  public String foreignKey( String columnName ) {
    return this.makeSqlIdentifier( "FK", this.name, columnName );
  }

  /** Returns the identifier without prefix or suffix. */
  public String getAsIdentifier() {
    return this.makeSqlIdentifier( this.name );
  }

  /** Returns the unique ID of the history view. */
  public String getChangesUniqueId() {
    return this.makeSqlIdentifier( this.name, "CHGS_ID" );
  }

  /** Returns the name of the history view. */
  public String getChangesView() {
    return this.makeSqlIdentifier( this.name, "CHGS" );
  }

  /** Returns the identifier for a column. */
  public String getColumn() {
    return this.makeSqlIdentifier( this.name );
  }

  /** Returns the identifier for a new column. */
  public String getColumnNew() {
    return this.makeSqlIdentifier( "NEW", this.name );
  }

  /** Returns the identifier for an old column. */
  public String getColumnOld() {
    return this.makeSqlIdentifier( "OLD", this.name );
  }

  /** Returns the identifier for a uniqueness constraint. */
  public String getConstraint() {
    return this.makeSqlIdentifier( "UQ", this.name );
  }

  /** Returns the identifier for a delete trigger. */
  public String getDeleteTrigger() {
    return this.makeSqlIdentifier( "DELETE", this.name );
  }

  /** Returns the identifier for a the ending foreign key from attributes table to user action. */
  public String getEndActionForeignKey() {
    return this.makeSqlIdentifier( "FK", this.name, "END" );
  }

  /**
   * Returns the uniqueness identifier for a the ending foreign key from attributes table to user
   * action.
   */
  public String getEndActionUniqueConstraint() {
    return this.makeSqlIdentifier( "UQ", this.name, "END" );
  }

  /** Returns the name of the histroy view. */
  public String getHistoryId() {
    return this.makeSqlIdentifier( this.name, "ATTR_ID" );
  }

  /** Returns the identifier for the primary key of a history table. */
  public String getHistoryPrimaryKey() {
    return this.makeSqlIdentifier( "PK", this.name, "ATTR" );
  }

  /** Returns the identifier for the history table sequence. */
  public String getHistorySequence() {
    return this.makeSqlIdentifier( "SEQ", this.name, "HIST" );
  }

  /** Returns the name of the history table. */
  public String getHistoryTable() {
    return this.makeSqlIdentifier( this.name, "HIST" );
  }

  /** Returns the identifier for a temporal attributes table. */
  public String getHistoryUniqueId() {
    return this.makeSqlIdentifier( this.name, "ATTR_ID" );
  }

  /** Returns the name of the histroy view. */
  public String getHistoryView() {
    return this.makeSqlIdentifier( this.name, "HIST" );
  }

  /** Returns the identifier for an insert trigger. */
  public String getInsertTrigger() {
    return this.makeSqlIdentifier( "INSERT", this.name );
  }

  /** Returns the identifier for a the starting foreign key from attributes table to user action. */
  public String getLatestActionForeignKey() {
    return this.makeSqlIdentifier( "FK", this.name, "LATEST" );
  }

  /** Returns the identifier for a primary key. */
  public String getPrimaryKey() {
    return this.makeSqlIdentifier( "PK", this.name );
  }

  /** Returns the un-modified name. */
  public String getRaw() {
    return this.name;
  }

  /** Returns the identifier for a schema. */
  public String getSchema() {
    return this.makeSqlIdentifier( this.name );
  }

  /** Returns the identifier for a sequence. */
  public String getSequence() {
    return this.makeSqlIdentifier( "SEQ", this.name );
  }

  /** Returns the identifier for a the starting foreign key from attributes table to user action. */
  public String getStartActionForeignKey() {
    return this.makeSqlIdentifier( "FK", this.name, "START" );
  }

  /**
   * Returns the uniqueness identifier for a the starting foreign key from attributes table to user
   * action.
   */
  public String getStartActionUniqueConstraint() {
    return this.makeSqlIdentifier( "UQ", this.name, "START" );
  }

  /** Returns the identifier for a basic table. */
  public String getTable() {
    return this.makeSqlIdentifier( this.name );
  }

  /** Returns the identifier for a basic table. */
  public String getUniqueId() {
    return this.makeSqlIdentifier( this.name, "ID" );
  }

  /** Returns the identifier for an update trigger. */
  public String getUpdateTrigger() {
    return this.makeSqlIdentifier( "UPDATE", this.name );
  }

  /**
   * Returns the identifier for an index on a table.
   * @param columnName The name of a column to be indexed.
   */
  public String index( String columnName ) {
    return this.makeSqlIdentifier( "IDX", this.name, columnName );
  }

  /** Returns the identifier for a uniqueness constraint. */
  public String uniqueConstraint( String columnName ) {
    return this.makeSqlIdentifier( "UQ", this.name, columnName );
  }

  /** Ensures that a given identifier is short enough to be a valid SQL identifier (<= 30 chars). */
  private String makeSqlIdentifier( String identifier ) {

    // convert to upper case with underscores
    String result = identifier.toUpperCase();
    result = result.replaceAll( " ", "_" );
    result = result.replaceAll( "-", "_" );

    // done if identifier is short enough
    if ( result.length() <= 30 ) {
      return result;
    }

    // remove vowels from the end so long as they are not word-leading and not "ID"
    Pattern vowelPattern = Pattern.compile( "(.*[^_])[AEIOU]([^D].*)" );
    while ( result.length() > 30 ) {

      Matcher matcher = vowelPattern.matcher( result );

      if ( !matcher.matches() ) {
        break;
      }

      result = matcher.replaceFirst( "$1$2" );
    }

    // remove underscores, starting from the end
    Pattern underscorePattern = Pattern.compile( "(.*)_(.*)" );
    while ( result.length() > 30 ) {

      Matcher matcher = underscorePattern.matcher( result );

      if ( !matcher.matches() ) {
        break;
      }

      result = matcher.replaceFirst( "$1$2" );
    }

    // remove near ending chars and add hash code digits to get short enough & artificially unique
    // (hopefully)
    if ( result.length() > 30 ) {
      Integer hashCode = identifier.hashCode();
      String hashCodeStr = Integer.toHexString( hashCode ).toUpperCase();
      result = result.substring( 0, 30 - hashCodeStr.length() ) + hashCodeStr;
    }

    return result;
  }

  /** Returns the SQL name of this element with a suffix appended. */
  private String makeSqlIdentifier( String fragment1, String fragment2 ) {
    assert fragment1 != null && fragment1.length() > 0 : "SQL fragment should not be empty.";
    assert fragment2 != null && fragment2.length() > 0 : "SQL fragment should not be empty.";
    return this.makeSqlIdentifier( fragment1 + "_" + fragment2 );
  }

  /** Returns the SQL name of this element with both a prefix and suffix appended. */
  private String makeSqlIdentifier( String fragment1, String fragment2, String fragment3 ) {
    assert fragment1 != null && fragment1.length() > 0 : "SQL fragment should not be empty.";
    assert fragment2 != null && fragment2.length() > 0 : "SQL fragment should not be empty.";
    assert fragment3 != null && fragment3.length() > 0 : "SQL fragment should not be empty.";

    return this.makeSqlIdentifier( fragment1 + "_" + fragment2 + "_" + fragment3 );
  }

  /** The raw name of a model element to be modified for use in SQL code. */
  private String name;
}
