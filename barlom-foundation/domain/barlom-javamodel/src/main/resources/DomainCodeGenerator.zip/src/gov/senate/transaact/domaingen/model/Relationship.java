
package gov.senate.transaact.domaingen.model;

/**
 * A relationship is a link between two entities (a SQL foreign key). A relationship is owned by the
 * many side of a many-to-one relationship and references the one related entity.
 */
public class Relationship
  extends ModelElement {

  /**
   * Returns the name of the aggregation for this relationship (defaults to the parent entity name).
   */
  public String getAggregationName() {
    return this.aggregationName != null ? this.aggregationName : this.parent.getJavaName()
        .getAsIdentifier() + "s";
  }

  /** Returns the description. */
  public String getDescription() {
    return this.description;
  }

  /**
   * Whether this relationship needs a workaround where its foreign key references the base class
   * table of the related entity instead of the derived class table. (This avoids an EclipseLink 2.X
   * issue where the child is mistakenly saved before the parent).
   */
  public boolean getNeedsForeignKeyToBaseClassWorkaround() {
    // workaround is needed if the child's parent and some grandparent are both derived classes
    boolean result = true;
    result = result && this.composed;
    result = result && this.relatedEntity.getBaseClass() != null;
    if ( result ) {
      result = false;
      for ( Relationship rel : this.relatedEntity.getBaseClass().getRelationships() ) {
        if ( rel.composed && rel.relatedEntity.getBaseClass() != null ) {
          result = true;
        }
      }
    }
    return result;
  }

  /** Returns the parent. */
  @Override
  public Entity getParent() {
    return this.parent;
  }

  /** Returns the relatedEntity. */
  public Entity getRelatedEntity() {
    return this.relatedEntity;
  }

  /** Returns the required. */
  public Boolean getRequired() {
    return this.required;
  }

  /** Returns the unique. */
  public Boolean getUnique() {
    return this.unique;
  }

  /** Returns the aggregated. */
  public boolean isAggregated() {
    return this.aggregated;
  }

  /** Returns the composed. */
  public boolean isComposed() {
    return this.composed;
  }

  /** Returns the loadedWithParent. */
  public boolean isLoadedWithParent() {
    return this.loadedWithParent;
  }

  /** Returns the oneToOne. */
  public boolean isOneToOne() {
    return this.oneToOne;
  }

  /** Returns the persistedWithParent. */
  public boolean isPersistedWithParent() {
    return this.persistedWithParent;
  }

  /** Whether this relationship has its values tracked over time. */
  public boolean isTemporal() {
    return false;
  }

  /**
   * Sets the aggregationName.
   * @param aggregationName The new value for aggregationName.
   */
  public void setAggregationName( String aggregationName ) {
    this.aggregationName = aggregationName;
  }

  /**
   * Sets the composed.
   * @param composed The new value for composed.
   */
  public void setComposed( boolean composed ) {
    this.composed = composed;
  }

  /**
   * Sets the description.
   * @param description The new value for description.
   */
  public void setDescription( String description ) {
    this.description = description;
  }

  /**
   * Sets the loadedWithParent.
   * @param loadedWithParent The new value for loadedWithParent.
   */
  public void setLoadedWithParent( boolean loadedWithParent ) {
    this.loadedWithParent = loadedWithParent;
  }

  /**
   * Sets the oneToOne.
   * @param oneToOne The new value for oneToOne.
   */
  public void setOneToOne( boolean oneToOne ) {
    this.oneToOne = oneToOne;
  }

  /**
   * Sets the persistedWithParent.
   * @param persistedWithParent The new value for persistedWithParent.
   */
  public void setPersistedWithParent( boolean persistedWithParent ) {
    this.persistedWithParent = persistedWithParent;
  }

  /**
   * Sets the required.
   * @param required The new value for required.
   */
  public void setRequired( Boolean required ) {
    this.required = required;
  }

  /**
   * Sets the unique.
   * @param unique The new value for unique.
   */
  public void setUnique( Boolean unique ) {
    this.unique = unique;
  }

  /** Validates this relationship. */
  @Override
  public void validate() {
    assert !this.description.isEmpty() : "Relationship " + this.parent.getName() + "#"
        + this.getName() + " has no description.";
    assert this.relatedEntity != null : "Relationship " + this.parent.getName() + "#"
        + this.getName() + " has no related entity.";
  }

  /**
   * Sets whether this relationship is aggregated (accessible from the related entity). Adds this
   * relationship to the related entity's aggregations if the related entity is known.
   */
  void setAggregated( boolean aggregated ) {
    assert !this.aggregated : "Can not change a relationship's aggregation.";
    this.aggregated = aggregated;
    if ( this.aggregated && this.relatedEntity != null ) {
      this.relatedEntity.getAggregations().add( this );
    }
  }

  /**
   * Sets the parent entity (the "many" entity) of this relationship. Also adds this relationship to
   * the entity's list of relationships.
   */
  void setParent( Entity parent ) {
    assert this.parent == null : "Can not changed the parent of a relationship.";
    this.parent = parent;
    parent.getRelationships().add( this );
  }

  /**
   * Sets the related entity (the "one" entity) for this relationship. Also adds it to that entity's
   * aggregations if the relationship is aggregated.
   */
  void setRelatedEntity( Entity relatedEntity ) {
    assert this.relatedEntity == null : "Can not changed the related entity of a relationship.";
    this.relatedEntity = relatedEntity;
    if ( this.aggregated && this.relatedEntity != null ) {
      relatedEntity.getAggregations().add( this );
    }
  }

  /**
   * Whether the related entity aggregates the entity owning this relationship (i.e. the one keeps
   * track of the many; i.e. the relationship is bidirectional [a better word for it]).
   */
  private boolean aggregated = false;

  /** The name of the aggregation for this relationship (if it is aggregated). */
  private String aggregationName;

  /** Whether this relationship is one of composition (i.e. the many can not outlive the one). */
  private boolean composed = false;

  /** A short description of this relationship. */
  private String description;

  /** Whether to fetch this entity along with its parent. */
  private boolean loadedWithParent = true;

  /** Whether this relationship is one to one instead of many to one. */
  private boolean oneToOne = false;

  /** The parent entity for this relationship (the "many" entity of the relationship). */
  private Entity parent;

  /** Whether to cascade persist this entity along with its parent. */
  private boolean persistedWithParent = false;

  /**
   * The other entity that is the target of this relationship (the "one" entity of the
   * relationship).
   */
  private Entity relatedEntity;

  /** Whether this relationship is required (non-null). */
  private Boolean required = false;

  /**
   * Whether this relationship must have a unique value among all entity instances with this
   * relationship.
   */
  private Boolean unique = false;
}
