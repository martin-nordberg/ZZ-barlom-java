
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * An interface, enum, or class.
 * @author GDIT, Inc.
 */
public abstract class JavaComponent
  extends JavaAnnotatableModelElement
  implements IJavaTyped {

  /**
   * Constructs a new component.
   * @param parent
   * @param name
   * @param description
   */
  protected JavaComponent(
      JavaPackage parent,
      String name,
      String description,
      Boolean isExternal ) {
    super( parent, name, description );

    this.isExternal = isExternal;

    this.implementedInterfaces = new ArrayList<JavaImplementedInterface>();
    this.members = new ArrayList<JavaMember>();
    this.methods = new ArrayList<JavaMethod>();
  }

  /** Creates a method within this component. */
  public JavaMethod addMethod(
      String name,
      String description,
      EJavaAccessibility accessibility,
      Boolean isAbstract,
      Boolean isStatic,
      Boolean isFinal,
      JavaType returnType,
      String code ) {
    return new JavaMethod(
        this,
        name,
        description,
        accessibility,
        isAbstract,
        isStatic,
        isFinal,
        returnType,
        code );
  }

  /** @return the fully qualified name of this component. */
  public String getFullyQualifiedJavaName() {
    return this.getParent().getFullyQualifiedJavaName() + "." + this.getJavaName();
  }

  /** @return the interfaces implemented by this component. */
  public List<JavaImplementedInterface> getImplementedInterfaces() {
    return this.implementedInterfaces;
  }

  /** @return the types needed to be imported by this component. */
  @Override
  public Set<JavaType> getImports() {
    Set<JavaType> result = super.getImports();

    for ( JavaMethod method : this.getMethods() ) {
      result.addAll( method.getImports() );
    }

    for ( JavaImplementedInterface implInterface : this.getImplementedInterfaces() ) {
      result.add( implInterface.getImplementedInterface().makeJavaType() );
    }

    return result;
  }

  /** Returns the isExternal. */
  public Boolean getIsExternal() {
    return this.isExternal;
  }

  /** @return the methods within this component. */
  public List<JavaMethod> getMethods() {
    List<JavaMethod> result = new ArrayList<>( this.methods );
    Collections.sort( result, new Comparator<JavaMethod>() {
      @Override
      public int compare(
          JavaMethod m1, JavaMethod m2
      ) {
        int result = m2.getIsStatic().compareTo( m1.getIsStatic() );
        if ( result == 0 ) {
          result = m1.getAccessibility().compareTo( m2.getAccessibility() );
        }
        if ( result == 0 ) {
          result = m1.compareTo( m2 );
        }
        if ( result == 0 ) {
          result = m1.getParameters().size() - m2.getParameters().size();
        }
        return result;
      }
    } );
    return result;
  }

  /** @return the parent of this package. */
  @Override
  public JavaPackage getParent() {
    return (JavaPackage) super.getParent();
  }

  /** Constructs a generic Java type with one type argument. */
  public JavaType makeGenericType( JavaComponent typeArg1 ) {
    JavaReferenceType result = new JavaReferenceType( this );
    result.addTypeArgument( typeArg1 );
    return result;
  }

  /** @return a type referencing this component. */
  public JavaType makeJavaType() {
    return new JavaReferenceType( this );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaImplementedInterface child ) {
    super.onAddChild( child );
    this.implementedInterfaces.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaMember child ) {
    super.onAddChild( child );
    this.members.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaMethod child ) {
    this.onAddChild( (JavaMember) child );
    this.methods.add( child );
  }

  private List<JavaImplementedInterface> implementedInterfaces;

  private Boolean isExternal;

  private List<JavaMember> members;

  private List<JavaMethod> methods;

}
