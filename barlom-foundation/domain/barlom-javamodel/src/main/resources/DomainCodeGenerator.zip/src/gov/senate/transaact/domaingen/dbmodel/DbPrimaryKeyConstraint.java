
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbPrimaryKeyConstraint
  extends DbConstraint {

  /**
   * Constructs a new primary key constraint.
   */
  DbPrimaryKeyConstraint(
      DbTable parent,
      String name,
      String description,
      DbTableColumn primaryKeyColumn ) {
    super( parent, name, description, DbConstraint.makeListOfOneColumn( primaryKeyColumn ) );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( "PK", this.getParent().getName() );
  }
}
