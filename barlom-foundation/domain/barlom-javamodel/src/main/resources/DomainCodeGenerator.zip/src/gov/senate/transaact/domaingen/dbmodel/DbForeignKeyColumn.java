
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbForeignKeyColumn
  extends DbTableColumn {

  /**
   * Constructs a new attribute column.
   */
  DbForeignKeyColumn(
      DbTable parent,
      String name,
      String relationshipName,
      String description,
      Boolean isNullable ) {
    super( parent, name, description, EDbDataType.INTEGER, null, null, isNullable, null );

    this.relationshipName = relationshipName;

    parent.onAddChild( this );
  }

  /** @return The name of the constraint for this primary key */
  public String getConstraintName() {
    return DbNamedModelElement.makeSqlName(
        "FK",
        this.getParent().getSqlName(),
        this.getSqlName() );
  }

  /** @return the related table. */
  public DbTable getRelatedTable() {
    return this.relatedTable;
  }

  /** Returns the relationshipName. */
  public String getRelationshipName() {
    return this.relationshipName;
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( this.getName() );
  }

  /**
   * Sets the relatedTable.
   * @param relatedTable The new value for relatedTable.
   */
  public void setRelatedTable( DbTable relatedTable ) {
    this.relatedTable = relatedTable;
  }

  private DbTable relatedTable;

  private String relationshipName;

}
