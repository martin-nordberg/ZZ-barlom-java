
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaInterface
  extends JavaComponent {

  /**
   * Constructs a new class.
   * @param parent
   * @param name
   * @param description
   */
  JavaInterface( JavaPackage parent, String name, String description, Boolean isExternal ) {
    super( parent, name, description, isExternal );

    parent.onAddChild( this );
  }

}
