
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GDIT, Inc.
 */
public class JavaReferenceType
  extends JavaType {

  /**
   * Constructs a new type reference.
   * @param component The referenced component defining this type
   */
  JavaReferenceType( JavaComponent component ) {
    super();

    this.component = component;
    this.typeArgs = new ArrayList<>();
  }

  /** Adds a type argument to this type. */
  public void addTypeArgument( JavaComponent typeArg ) {
    this.typeArgs.add( typeArg );
  }

  /** {@inheritDoc} */
  @Override
  public String getFullyQualifiedJavaName() {
    return this.component.getFullyQualifiedJavaName();
  }

  @Override
  public boolean getIsImplicitlyImported() {
    return this.component.getParent().getIsImplicitlyImported();
  }

  /** {@inheritDoc} */
  @Override
  public String getJavaName() {
    return this.component.getJavaName() + this.getTypeArgsForName();
  }

  private String getTypeArgsForName() {
    String result = "";

    if ( typeArgs.size() > 0 ) {
      result += "<";
      String delimiter = "";
      for ( JavaComponent typeArg : typeArgs ) {
        result += delimiter;
        result += typeArg.getJavaName();
        delimiter = ",";
      }
      result += ">";
    }

    return result;
  }

  private JavaComponent component;

  private List<JavaComponent> typeArgs;

}
