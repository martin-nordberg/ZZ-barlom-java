
package gov.senate.transaact.domaingen.model;

import java.util.ArrayList;
import java.util.List;

/** A Java class and the corresponding SQL tables to store changes over time. */
public class TemporalEntity
  extends Entity {

  /** Returns the subset of this entity's attributes that are not temporal. */
  public List<Attribute> getNonTemporalAttributes() {
    List<Attribute> result = new ArrayList<>();
    for ( Attribute attribute : this.getAttributes() ) {
      if ( !attribute.isTemporal() ) {
        result.add( attribute );
      }
    }
    return result;
  }

  /** Returns the subset of this entity's relationships that are not temporal. */
  public List<Relationship> getNonTemporalRelationships() {
    List<Relationship> result = new ArrayList<>();
    for ( Relationship relationship : this.getRelationships() ) {
      if ( !relationship.isTemporal() ) {
        result.add( relationship );
      }
    }
    return result;
  }

  /** Returns the subset of this entity's attributes that are temporal. */
  public List<TemporalAttribute> getTemporalAttributes() {
    List<TemporalAttribute> result = new ArrayList<>();
    for ( Attribute attribute : this.getAttributes() ) {
      if ( attribute.isTemporal() ) {
        result.add( (TemporalAttribute) attribute );
      }
    }
    return result;
  }

  /** Returns the subset of this entity's relationships that are temporal. */
  public List<TemporalRelationship> getTemporalRelationships() {
    List<TemporalRelationship> result = new ArrayList<>();
    for ( Relationship relationship : this.getRelationships() ) {
      if ( relationship.isTemporal() ) {
        result.add( (TemporalRelationship) relationship );
      }
    }
    return result;
  }

  /** Whether this entity maintains a history of its changes over time. */
  @Override
  public boolean isTemporal() {
    return true;
  }
}
