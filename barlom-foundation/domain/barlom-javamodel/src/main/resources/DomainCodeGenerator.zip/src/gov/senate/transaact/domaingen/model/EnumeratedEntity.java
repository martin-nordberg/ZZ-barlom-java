
package gov.senate.transaact.domaingen.model;

/** An entity with a compile-time fixed set of instances. */
public class EnumeratedEntity
  extends Entity {

  @Override
  public Boolean getHasReferenceValuesOnly() {
    return true;
  }

  /** Whether this entity is an enumeration. */
  @Override
  public boolean isEnumerated() {
    return true;
  }
}
