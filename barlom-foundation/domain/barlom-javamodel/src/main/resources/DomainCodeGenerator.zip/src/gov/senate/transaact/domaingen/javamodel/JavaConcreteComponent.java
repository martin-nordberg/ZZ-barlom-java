
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * @author GDIT, Inc.
 */
public class JavaConcreteComponent
  extends JavaComponent {

  /**
   * Constructs a new concrete component.
   * @param parent
   * @param name
   * @param description
   */
  JavaConcreteComponent( JavaPackage parent, String name, String description, Boolean isExternal ) {
    super( parent, name, description, isExternal );

    this.constructors = new ArrayList<JavaConstructor>();
    this.fields = new ArrayList<JavaField>();
    this.staticInitializations = new ArrayList<JavaStaticInitialization>();

    parent.onAddChild( this );
  }

  /** Creates a constructor within this class. */
  public JavaConstructor addConstructor(
      String description,
      EJavaAccessibility accessibility,
      String code ) {
    return new JavaConstructor( this, description, accessibility, code );
  }

  /** Creates a field within this class. */
  public JavaField addField(
      String name,
      String description,
      EJavaAccessibility accessibility,
      Boolean isStatic,
      Boolean isFinalField,
      JavaType type,
      String code ) {
    return new JavaField(
        this,
        name,
        description,
        accessibility,
        isStatic,
        isFinalField,
        type,
        code );
  }

  /** Creates a static initialization within this class. */
  public JavaStaticInitialization addStaticInitialization( String description, String code ) {
    return new JavaStaticInitialization( this, description, code );
  }

  /** @return the constructors within this class. */
  public List<JavaConstructor> getConstructors() {
    return this.constructors;
  }

  /** @return the fields within this class. */
  public List<JavaField> getFields() {
    List<JavaField> result = new ArrayList<>( this.fields );
    Collections.sort( result, new Comparator<JavaField>() {
      @Override
      public int compare(
          JavaField f1, JavaField f2
      ) {
        int result = f2.getIsStatic().compareTo( f1.getIsStatic() );
        if ( result == 0 ) {
          result = f1.getAccessibility().compareTo( f2.getAccessibility() );
        }
        if ( result == 0 ) {
          result = f1.compareTo( f2 );
        }
        return result;
      }
    } );
    return result;
  }

  @Override
  public Set<JavaType> getImports() {
    Set<JavaType> result = super.getImports();

    for ( JavaField field : this.fields ) {
      result.addAll( field.getImports() );
    }

    return result;
  }

  /** @return the static initializations within this class. */
  public List<JavaStaticInitialization> getStaticInitializations() {
    return this.staticInitializations;
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaConstructor child ) {
    super.onAddChild( child );
    this.constructors.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaField child ) {
    super.onAddChild( child );
    this.fields.add( child );
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaStaticInitialization child ) {
    super.onAddChild( child );
    this.staticInitializations.add( child );
  }

  private List<JavaConstructor> constructors;

  private List<JavaField> fields;

  private List<JavaStaticInitialization> staticInitializations;

}
