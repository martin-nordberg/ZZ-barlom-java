
package gov.senate.transaact.domaingen.model;

/** Concrete date type for booleans. */
public class BooleanDataType
  extends DataType {

  public BooleanDataType() {
    super( "Boolean", "NUMBER(1,0)", false, false );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    return ( (Boolean) value ) ? "true" : "false";
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    return ( (Boolean) value ) ? "1" : "0";
  }
}
