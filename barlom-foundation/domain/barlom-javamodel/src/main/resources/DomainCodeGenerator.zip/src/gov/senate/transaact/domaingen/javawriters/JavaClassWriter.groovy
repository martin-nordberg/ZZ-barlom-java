
package gov.senate.transaact.domaingen.javawriters

import freemarker.template.Configuration
import freemarker.template.DefaultObjectWrapper
import freemarker.template.Template
import freemarker.template.TemplateExceptionHandler
import gov.senate.transaact.domaingen.FileRewriter
import gov.senate.transaact.domaingen.IndentingWriter
import gov.senate.transaact.domaingen.javamodel.JavaClass

/**
 * @author GDIT, Inc.
 */
public class JavaClassWriter
extends IndentingWriter {

  JavaClassWriter( String sourcePath ) {
    this.sourcePath = sourcePath;
  }

  void writeClass( JavaClass clazz ) {
    this.setOutput( this.getSourceFilePath( clazz ) );

    Configuration cfg = new Configuration();

    cfg.setClassForTemplateLoading(
        this.getClass(),
        "/gov/senate/transaact/domaingen/javawriters/templates/"
    );
    cfg.setObjectWrapper( new DefaultObjectWrapper() );
    cfg.setDefaultEncoding( "UTF-8" );
    cfg.setTemplateExceptionHandler( TemplateExceptionHandler.DEBUG_HANDLER );

    Template temp = cfg.getTemplate( "Class.java.ftl" );

    Writer out = new StringWriter();
    temp.process( clazz, out );

    this.nextLine() << out.toString();

    this.closeOutput();
  }

  /**
   * @param clazz
   * @return
   */
  private FileRewriter getSourceFilePath( JavaClass clazz ) {

    String path = clazz.getFullyQualifiedJavaName();
    path = path.replaceAll( "\\.", "\\\\" );
    path = this.sourcePath + "\\" + path + ".java";

    return new FileRewriter( new File( path ) );
  }

  private String sourcePath;
}
