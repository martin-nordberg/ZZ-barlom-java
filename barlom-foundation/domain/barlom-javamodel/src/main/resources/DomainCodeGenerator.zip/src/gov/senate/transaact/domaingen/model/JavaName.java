
package gov.senate.transaact.domaingen.model;

/** Encapsulation of the rules for computing names of Java code elements. */
public class JavaName {

  /** Constructs a name from a given model element. */
  public JavaName( ModelElement element ) {
    this.name = element.getName();

    if ( element.getParent() != null ) {
      this.parentName = element.getParent().getJavaName();
    }
  }

  /** Constructs a given name. */
  public JavaName( String name ) {
    assert name != null && !name.isEmpty();
    this.name = name;
  }

  /** Returns the name for an addXxx method. */
  public String getAdder() {
    return "add" + this.getAsIdentifier();
  }

  /** Returns the name of an element suitable for use in comments. */
  public String getAsDescription() {
    return this.name.toLowerCase();
  }

  /** Returns the unadorned name ready for use as an identifier. */
  public String getAsIdentifier() {
    String result = this.name.replaceAll( " ", "" );
    result = result.replaceAll( "\\-", "" );
    result = result.replaceAll( "\\.", "" );
    result = result.replaceAll( "\\,", "" );
    result = result.replaceAll( "\\(", "" );
    result = result.replaceAll( "\\)", "" );
    result = result.replaceAll( "/", "" );
    return result;
  }

  /** Returns the name converted for use as a fractional package name. */
  public String getAsPackage() {
    return this.name.replaceAll( " ", "." ).toLowerCase();
  }

  /** Returns the name for the package for the basic services for an entity. */
  public String getBasicServicePackage() {
    return "gov.senate.transaact." + this.getAsPackage() + ".queries";
  }

  /** Returns the name for an entity change record interface. */
  public String getChangeImplementationClass() {
    return this.getAsIdentifier() + "Change";
  }

  /** Returns the fully qualified name for an entity change record interface. */
  public String getChangeImplementationClassFullyQualified() {
    return this.parentName.getChangeImplementationPackage() + "."
        + this.getChangeImplementationClass();
  }

  /** Returns the name for the package of an entity implementation. */
  public String getChangeImplementationPackage() {
    return "gov.senate.transaact." + this.getAsPackage() + ".domainmodel.history";
  }

  /** Returns the name for the CRUD test of an entity. */
  public String getCrudTestClass() {
    return this.getAsIdentifier() + "CrudTest";
  }

  /** Returns the name for the CRUD test suite of a domain. */
  public String getCrudTestSuiteClass() {
    return this.getAsIdentifier() + "CrudTests";
  }

  /** Returns the name for a data model factory. */
  public String getDataModelFactoryClass() {
    return this.getAsIdentifier() + "DataModelFactory";
  }

  /** Returns the fully qualified name for an entity change record interface. */
  public String getDataModelFactoryClassFullyQualified() {
    return this.getImplementationPackage() + "." + this.getDataModelFactoryClass();
  }

  /** Returns the name for a field. */
  public String getField() {
    String result = this.getAsIdentifier();
    return Character.toLowerCase( result.charAt( 0 ) ) + result.substring( 1 );
  }

  /** Returns the name for a getXxx method. */
  public String getGetter() {
    return "get" + this.getAsIdentifier();
  }

  /** Returns the name for an entity implementation. */
  public String getImplementationClass() {
    return this.getAsIdentifier();
  }

  /** Returns the fully qualified name for an entity implementation. */
  public String getImplementationClassFullyQualified() {
    return this.parentName.getImplementationPackage() + "." + this.getImplementationClass();
  }

  /** Returns the name for the package of an entity implementation. */
  public String getImplementationPackage() {
    return "gov.senate.transaact." + this.getAsPackage() + ".domainmodel";
  }

  /** Returns the name for an instance test method. */
  public String getInstanceTest() {
    return "is" + this.getAsIdentifier();
  }

  /** Returns the name for an instance reference constant. */
  public String getReferenceConstant( String prefix ) {
    String result = prefix + "_" + this.name;
    result = result.replaceAll( " ", "_" );
    result = result.replaceAll( "\\-", "_" );
    result = result.replaceAll( "\\.", "_" );
    result = result.replaceAll( "\\,", "_" );
    result = result.replaceAll( "\\(", "_" );
    result = result.replaceAll( "\\)", "_" );
    result = result.replaceAll( "/", "_" );
    return result.toUpperCase();
  }

  /** Returns the name for an instance reference constant prefix. */
  public String getReferencePrefix() {
    String result = this.name;
    result = result.replaceAll( " ", "_" );
    result = result.replaceAll( "\\-", "_" );
    result = result.replaceAll( "\\.", "_" );
    result = result.replaceAll( "\\,", "_" );
    result = result.replaceAll( "\\(", "_" );
    result = result.replaceAll( "\\)", "_" );
    result = result.replaceAll( "/", "_" );
    return result.toUpperCase();
  }

  /** Returns the name for a removeXxx method. */
  public String getRemover() {
    return "remove" + this.getAsIdentifier();
  }

  /** Returns the name for a setXxx method. */
  public String getSetter() {
    return "set" + this.getAsIdentifier();
  }

  /** Returns the name for the parameter of a setXxx method. */
  public String getSetterParameter() {
    return "new" + this.getAsIdentifier();
  }

  /** Returns the name for the testing package of a domain. */
  public String getTestPackage() {
    return "gov.senate.transaact." + this.getAsPackage() + ".domainmodel";
  }

  /** Returns the name for the unique ID of an entity. */
  public String getUniqueId() {
    return this.getField() + "Id";
  }

  /** Returns the name for an entity validator. */
  public String getValidatorClass() {
    return this.getAsIdentifier() + "Validator";
  }

  /** Returns the fully qualified name for an entity validator. */
  public String getValidatorClassFullyQualified() {
    return this.parentName.getImplementationPackage() + ".validators."
        + this.getValidatorClass();
  }

  /** Returns the name for an element implementation. */
  @Override
  public String toString() {
    assert false;
    return this.name.replaceAll( " ", "" );
  }

  public static String ABANDON_UNPERSISTED_CHANGES = "abandonUnpersistedChanges";

  public static String NEEDS_PERSISTING = "needsPersisting";

  public static String STAGE_UNPERSISTED_CHANGES = "stageUnpersistedChanges";

  /** The raw name of the model element to be converted as needed for different purposes. */
  private String name;

  /** The name of the parent to this named model element. */
  private JavaName parentName;
}
