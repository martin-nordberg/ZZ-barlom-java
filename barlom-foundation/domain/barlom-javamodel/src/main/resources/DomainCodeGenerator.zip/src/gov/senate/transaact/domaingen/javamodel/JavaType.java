
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaType
  extends JavaModelElement
  implements Comparable<JavaType> {

  /**
   * Constructs a new type.
   */
  protected JavaType() {
    super( null, "" );
  }

  @Override
  public int compareTo( JavaType that ) {
    return this.getFullyQualifiedJavaName().compareTo( that.getFullyQualifiedJavaName() );
  }

  /** Returns the fully qualified name of this type. */
  public abstract String getFullyQualifiedJavaName();

  /** Whether this type is implicitly imported. */
  public abstract boolean getIsImplicitlyImported();

  /** Returns the name of this element for Java code purposes. */
  public abstract String getJavaName();
}
