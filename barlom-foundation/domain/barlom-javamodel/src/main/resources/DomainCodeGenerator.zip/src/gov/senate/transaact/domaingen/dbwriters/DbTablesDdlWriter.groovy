
package gov.senate.transaact.domaingen.dbwriters;

import gov.senate.transaact.domaingen.dbmodel.DbColumn
import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbPrimaryKeyColumn
import gov.senate.transaact.domaingen.dbmodel.DbTable
import gov.senate.transaact.domaingen.dbmodel.DbTableColumn
import gov.senate.transaact.domaingen.model.*

/**
 * Writer generates code to define TranSAAct database tables.
 * @author Vangent, Inc.
 */
public class DbTablesDdlWriter
extends DbWriter {

  /** Writes a schema definition to the writer's output. */
  void writeDomain( DbDomain domain ) {

    String title = 'SCHEMA TABLES DEFINITION FOR ' + domain.sqlName;
    String purpose = 'Defines the ' + domain.sqlName + ' schema tables.'

    writeFileHeader( title, purpose, true );

    nextLine() << '-------------------';
    nextLine() << '-- Create Tables --';
    nextLine() << '-------------------';
    nextLine();
    domain.tables.each { table ->
      createTable( table );
    }
    nextLine();

    writeFileFooter();
  }

  private void createTable( DbTable table ) {

    String keyName = table.primaryKeyColumn.sqlName;

    nextLine() << '-- Create the table for ' << table.sqlName;
    nextLine() << 'BEGIN';
    ++indent;
    nextLine() << "DATAMODEL.CREATE_TABLE( '" << table.sqlName << "', '" << keyName << "' );";
    nextLine();

    table.columns.each{ column ->
      createColumn( table.sqlName, column );
    }

    --indent;
    nextLine() << 'END;';
    nextLine() << '/';
    nextLine();
  }

  /** Creates an attribute column. */
  private void createColumn( String tableName, DbTableColumn column ) {
    nextLine() << '-- ' << column.description;
    nextLine() << "DATAMODEL.ADD_COLUMN( '" << tableName <<
        "', '" << column.sqlName << "', '" << column.type.getSqlType( column.size, column.precision );
    if ( column.defaultValue != null ) {
      sameLine() << "', '" << escaped(column.type.getValueForSql( column.defaultValue )) << "' );";
    }
    else {
      sameLine() << "', NULL );";
    }
  }

  /** Creates an attribute column. */
  private void createColumn( String tableName, DbPrimaryKeyColumn column ) {
    // no additional code for primary key
  }
}
