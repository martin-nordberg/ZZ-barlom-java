
package gov.senate.transaact.domaingen.model;

/** Concrete date type for long integers. */
public class BlobDataType
  extends DataType {

  public BlobDataType() {
    super( "byte[]", "BLOB", true, false );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    throw new UnsupportedOperationException( "Cannot initialize a blob." );
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    throw new UnsupportedOperationException( "Cannot initialize a blob." );
  }
}
