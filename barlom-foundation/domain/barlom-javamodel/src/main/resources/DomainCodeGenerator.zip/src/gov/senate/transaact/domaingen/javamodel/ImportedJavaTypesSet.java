
package gov.senate.transaact.domaingen.javamodel;

import java.util.Comparator;
import java.util.TreeSet;

/**
 * Specialized set type for ordering unique imports.
 */
public class ImportedJavaTypesSet
  extends TreeSet<JavaType> {

  /** TBD */
  private static final long serialVersionUID = 1L;

  public ImportedJavaTypesSet() {
    super( new Comparator<JavaType>() {
      @Override
      public int compare(
          JavaType t1, JavaType t2
      ) {
        String tname1 = t1.getFullyQualifiedJavaName();
        String tname2 = t2.getFullyQualifiedJavaName();

        if ( tname1.startsWith( "gov" ) ) {
          if ( !tname2.startsWith( "gov" ) ) {
            return 1;
          }
        }
        else if ( tname2.startsWith( "gov" ) ) {
          return -1;
        }
        return tname1.compareTo( tname2 );
      }
    } );
  }

  @Override
  public boolean add( JavaType javaType ) {
    if ( javaType.getIsImplicitlyImported() ) {
      return true;
    }

    return super.add( javaType );
  }

}
