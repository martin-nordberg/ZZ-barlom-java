
package gov.senate.transaact.domaingen.model;

/** A relationship between two entities (a SQL foreign key) that has its changes kept track of. */
public class TemporalRelationship
  extends Relationship {

  /** Whether changes to this relationship over time are stored for later recall. */
  @Override
  public boolean isTemporal() {
    return true;
  }

  /** Validates this relationship. */
  @Override
  public void validate() {
    super.validate();
    assert this.getParent().isTemporal() : "Temporal relationship " + this.getName()
        + " must be in a temporal entity.";
  }
}
