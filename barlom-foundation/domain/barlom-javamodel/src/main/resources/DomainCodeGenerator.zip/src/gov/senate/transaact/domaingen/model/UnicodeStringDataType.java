
package gov.senate.transaact.domaingen.model;

/** Concrete date type for strings. */
public class UnicodeStringDataType
  extends DataType {

  public UnicodeStringDataType() {
    super( "String", "'NVARCHAR2", false, false );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    return '"' + value.toString() + '"';
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    return "'" + value.toString() + "'";
  }
}
