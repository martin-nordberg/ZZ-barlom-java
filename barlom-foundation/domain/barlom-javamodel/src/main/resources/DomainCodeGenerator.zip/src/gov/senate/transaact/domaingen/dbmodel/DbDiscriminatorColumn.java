
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbDiscriminatorColumn
  extends DbTableColumn {

  /**
   * Constructs a new
   * @param parent
   * @param name
   */
  DbDiscriminatorColumn( DbTable parent, String defaultValue ) {
    super(
        parent,
        "Discriminator",
        "A flag indicating what type of object this is (for joins to inheriting tables)",
        EDbDataType.VARCHAR2,
        2,
        0,
        false,
        defaultValue );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public DbTable getParent() {
    return (DbTable) super.getParent();
  }

}
