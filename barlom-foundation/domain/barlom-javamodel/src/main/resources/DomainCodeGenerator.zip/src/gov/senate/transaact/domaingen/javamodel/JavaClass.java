
package gov.senate.transaact.domaingen.javamodel;

import java.util.Set;

/**
 * @author GDIT, Inc.
 */
public class JavaClass
  extends JavaConcreteComponent {

  /**
   * Constructs a new class.
   * @param parent
   * @param name
   * @param description
   */
  JavaClass(
      JavaPackage parent,
      String name,
      String description,
      Boolean isExternal,
      Boolean isAbstract,
      Boolean isFinal,
      JavaClass baseClass,
      Boolean isTestCode ) {
    super( parent, name, description, isExternal );

    this.isAbstract = isAbstract;
    this.isFinal = isFinal;
    this.baseClass = baseClass;
    this.isTestCode = isTestCode;

    parent.onAddChild( this );
  }

  /** @return the baseClass. */
  public JavaClass getBaseClass() {
    return this.baseClass;
  }

  @Override
  public Set<JavaType> getImports() {
    Set<JavaType> result = super.getImports();

    if ( this.baseClass != null ) {
      result.add( this.baseClass.makeJavaType() );
    }

    return result;
  }

  /** @return whether this is an abstract class. */
  public Boolean getIsAbstract() {
    return this.isAbstract;
  }

  /** @return whether this is a final class. */
  public Boolean getIsFinal() {
    return this.isFinal;
  }

  /** Returns the isTestCode. */
  public Boolean getIsTestCode() {
    return this.isTestCode;
  }

  /** Sets the base class. */
  public void setBaseClass( JavaClass baseClass ) {
    assert this.baseClass == null;
    this.baseClass = baseClass;
  }

  private JavaClass baseClass;

  private Boolean isAbstract;

  private Boolean isFinal;

  private Boolean isTestCode;
}
