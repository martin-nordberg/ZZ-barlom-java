
package gov.senate.transaact.domaingen.dbmodel;

/**
 * @author Vangent, Inc.
 */
public class DbView
  extends DbRelation {

  /**
   * Constructs a new view.
   * @param parent
   * @param name
   */
  DbView( DbDomain parent, String name, String description ) {
    super( parent, name, description );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( "V", this.getName() );
  }

}
