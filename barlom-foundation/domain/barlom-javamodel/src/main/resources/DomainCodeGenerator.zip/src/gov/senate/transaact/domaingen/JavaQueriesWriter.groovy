
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

/** Class to write Java code for the basic queries of a domain. */
class JavaQueriesWriter
extends JavaCodeWriter {

  /** Returns the name for a basic service class for a given entity. */
  private String getBasicServiceName( ModelElement element ) {
    return element.javaName.implementationClass + "QueryService";
  }

  /** Returns the name for the natural sort JPQL fragment for an entity. */
  private String getBuildReferenceValueMapName( Entity entity ) {
    return "build" + entity.javaName.asIdentifier + "ReferenceValueMap";
  }

  /** Returns the name for the natural sort JPQL fragment for an entity. */
  private String getMakeQueryName( Entity entity ) {
    return "make" + entity.javaName.asIdentifier + "Query";
  }

  /** Returns the name for the natural sort JPQL fragment for an entity. */
  private String getNaturalSortName( Entity entity ) {
    return entity.sqlName.asIdentifier + "_NATURAL_SORT_CRITERIA";
  }

  /** Returns the list of imports needed by the entire domain. */
  private List<String> getImportedPackages( Domain domain ) {

    Set result = new HashSet();

    domain.entities.each { entity ->
      if ( !entity.enumerated ) {
        result.addAll( getImportedPackages( entity ) );
      }
    }

    return result.sort();
  }

  /** Returns the list of imports needed by an entity's interface. */
  private List<String> getImportedPackages( Entity entity ) {

    Set result = new HashSet();

    result.add( 'java.util.List' );

    result.add( 'gov.senate.transaact.common.datamodel.IEntityManager' );
    result.add( 'gov.senate.transaact.common.dynamicservice.AbstractServiceImplementation' );

    if ( entity.hasReferenceValuesOnly ) {
      result.add( 'gov.senate.transaact.common.dynamicservice.IReferenceValueMap' );
      result.add( 'gov.senate.transaact.common.dynamicservice.ReferenceValueMap' );
    }

    result.add( 'java.util.HashMap' );
    result.add( 'java.util.Map' );
    result.add( 'gov.senate.transaact.common.util.StringUtil' );

    // java.util.Date, if needed
    if ( entity.attributes.find { it.unique && it.dataType.isDateType } ) {
      result.add( 'java.util.Date' );
    }

    result.add( entity.javaName.implementationClassFullyQualified );

    return result.sort();
  }

  /** Pluralizes a given identifier. */
  private String getPlural( String identifier ) {
    if ( identifier.getAt( identifier.length()-1 ) == 's' ) {
      return identifier + "es";
    }
    if ( identifier.getAt( identifier.length()-1 ) == 'y' ) {
      return identifier.substring(0,identifier.length()-1) + "ies";
    }

    return identifier + "s";
  }

  /** Returns the natural sort criteria (as JPQL) for the given entity. */
  private String getSortCriteria( Entity entity ) {

    String result = "";
    String delimiter = "";

    def sortAttributes = entity.naturalSort.split( "," );
    if ( "uniqueId".equals( sortAttributes[0] ) ) {
      sortAttributes[0] = entity.javaName.uniqueId;
    }

    sortAttributes.each {
      result += delimiter + "x." + it.trim();
      delimiter = ", ";
    }

    return result;
  }

  /** Whether the given entity has an attribute with given name. */
  private boolean hasAttribute( Entity entity, String attributeName ) {
    return entity.attributes.find {
      attributeName.equals( it.name );
    }
  }

  /** Writes the Java code for entities in a given domain. */
  void writeDomain( Domain domain ) {

    // write a distinct query service for each entity ...
    domain.entities.each { entity ->
      if ( !entity.enumerated ) {
        // open the source file
        File srcFile = new File( sourceFolder, getBasicServiceName( entity ) + ".java" )
        setOutput( new FileRewriter( srcFile ) );

        // write the output
        writeEntity( entity );

        // close the output
        closeOutput();
      }
    }
  }

  private void writeBuildReferenceValueMapMethod( Entity entity ) {
    String interfaceName = entity.javaName.implementationClass;

    nextLine() << '/**';
    nextLine() << ' * Converts a result list into a reference value map.';
    nextLine() << ' * @param objects The plain list of objects.';
    nextLine() << ' * @return A reference value map indexed by unique ID and name.';
    nextLine() << ' */';
    nextLine() << 'public IReferenceValueMap<' << interfaceName << '> ' << getBuildReferenceValueMapName(entity) << '(';
    nextLine() << '    List<' << interfaceName << '> objects ) {';
    nextLine();
    ++indent;
    nextLine() << 'IReferenceValueMap<' << interfaceName << '> result = new ReferenceValueMap<' << interfaceName << '>();';
    nextLine();
    nextLine() << 'for ( ' << interfaceName << ' object : objects ) {';
    ++indent;
    entity.attributes.each{ attribute ->
      if ( attribute.unique && attribute.dataType == DataType.stringDataType ) {
        nextLine() << 'result.put( object.' << attribute.javaName.getter << '(), object );';
      }
      else if ( attribute.unique ) {
        nextLine() << 'result.put( object.' << attribute.javaName.getter << '().toString(), object );';
      }
    }
    nextLine() << 'result.put( object.getUniqueId().toString(), object );';
    --indent;
    nextLine() << '}';
    nextLine();
    nextLine() << 'return result;';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes the constructor for the service. */
  private void writeConstructor( ModelElement element ) {
    nextLine() << '/**';
    nextLine() << ' * Constructs a new service implementation.';
    nextLine() << ' * @param entityManager The entity manager for use by calls to this service.';
    nextLine() << ' */';
    nextLine() << 'public ' << getBasicServiceName(element) << '( IEntityManager entityManager ) {';
    nextLine() << '  super( entityManager );';
    nextLine() << '}';
    nextLine();
  }

  /** Writes the code for the basic services for one entity. */
  private void writeEntity( Entity entity ) {

    // package
    nextLine() << 'package ' << entity.parent.javaName.basicServicePackage << ';';
    nextLine();

    // imports
    getImportedPackages( entity ).each {
      nextLine() << 'import ' << it << ';';
    }

    // class declaration
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Basic data access services for ' << entity.javaName.asDescription << ' objects.';
    nextLine() << ' * @author Vangent, Inc. (NOTE: SCRIPT-GENERATED CODE; DO NOT HAND EDIT)';
    nextLine() << ' */';
    nextLine() << 'public final class ' << getBasicServiceName( entity );
    ++indent;
    nextLine() << 'extends AbstractServiceImplementation {';
    nextLine();

    // constructor
    writeConstructor( entity );

    // query methods
    writeEntityMethods( entity );

    // end of class
    --indent;
    nextLine() << "}";
    nextLine();
  }

  private void writeEntityMethods( Entity entity ) {

    // make query
    writeMakeQueryMethod( entity );

    // find one
    writeFindOneMethod( entity );

    // find one by unique ID
    writeFindByIdMethod( entity );

    // find by unique attribute value
    entity.attributes.each { attribute ->
      if ( attribute.unique ) {
        writeFindByAttributeMethod( attribute );
      }
    }

    // find many
    writeFindManyMethod( entity );

    // find all
    writeFindAllMethod( entity );

    // find by relationship
    entity.relationships.each { relationship ->
      writeFindByRelationship( relationship );
    }

    if ( entity.hasReferenceValuesOnly ) {
      // build reference values map
      writeBuildReferenceValueMapMethod( entity );

      // find reference values
      writeFindReferenceValuesMethod( entity );
    }

    // natural sort order
    writeNaturalSortCriteria( entity );

  }

  /** Writes the method to build a query for this entity. */
  private void writeMakeQueryMethod( Entity entity ) {

    String className = entity.javaName.implementationClass;

    nextLine() << '/**';
    nextLine() << ' * Builds a basic query for ' << entity.javaName.asDescription << '.';
    nextLine() << ' * @param jpqlSelectionCriteria The JPQL fragment for the selection criteria (where clause). This';
    nextLine() << ' *          fragment needs to use "x" as the base variable being queried.';
    nextLine() << ' * @return The full JPQL query built from its fragments.';
    nextLine() << ' */';
    nextLine() << 'private String ' << getMakeQueryName(entity) << '( String jpqlSelectionCriteria ) {';
    nextLine();
    ++indent;
    nextLine() << 'String result = "SELECT x FROM ' << className << ' x";';
    nextLine();
    nextLine() << 'if ( StringUtil.hasValue( jpqlSelectionCriteria ) ) {';
    nextLine() << indent() << 'result += " WHERE " + jpqlSelectionCriteria;';
    nextLine() << '}';
    nextLine();
    nextLine() << 'return result;';
    --indent;
    nextLine() << '}';
  }

  /** Writes the find many method for the service. */
  private void writeFindManyMethod( Entity entity ) {

    String className = entity.javaName.implementationClass;
    String plural = getPlural( className );

    nextLine() << '/**';
    nextLine() << ' * Finds specified instances of ' << entity.javaName.asDescription << ' sorted in natural order.';
    nextLine() << ' * @param jpqlSelectionCriteria The JPQL fragment for the selection criteria (where clause). This';
    nextLine() << ' *          fragment needs to use "x" as the base variable being queried.';
    nextLine() << ' * @param parameters The parameters to substitute into the query.';
    nextLine() << ' * @return a list of the entities found.';
    nextLine() << ' */';
    nextLine() << 'public List<' << className << '> find' << plural << '(';
    nextLine() << '    String jpqlSelectionCriteria,';
    nextLine() << '    Map<String, Object> parameters ) {';
    nextLine();
    nextLine() << indent() << 'return ' << 'find' << plural << '( jpqlSelectionCriteria, ' << getNaturalSortName(entity) << ', parameters );';
    nextLine() << '}';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * Finds specified instances of ' << entity.javaName.asDescription << '.';
    nextLine() << ' * @param jpqlSelectionCriteria The JPQL fragment for the selection criteria (where clause). This';
    nextLine() << ' *          fragment needs to use "x" as the base variable being queried.';
    nextLine() << ' * @param jpqlSortCriteria The JPQL fragment for the sort criteria. This fragment needs to use "x"';
    nextLine() << ' *          as the base variable being queried.';
    nextLine() << ' * @param parameters The parameters to substitute into the query.';
    nextLine() << ' * @return a list of the entities found.';
    nextLine() << ' */';
    nextLine() << 'public List<' << className << '> find' << plural << '(';
    nextLine() << '    String jpqlSelectionCriteria,';
    nextLine() << '    String jpqlSortCriteria,';
    nextLine() << '    Map<String, Object> parameters ) {';
    nextLine();
    ++indent;
    nextLine() << 'String jpqlQuery = ' << getMakeQueryName(entity) << '( jpqlSelectionCriteria );';
    nextLine();
    nextLine() << 'if ( StringUtil.hasValue( jpqlSortCriteria ) ) {';
    nextLine() << indent() << 'jpqlQuery += " ORDER BY " + jpqlSortCriteria;';
    nextLine() << '}';
    nextLine() << 'else {';
    nextLine() << indent() << 'jpqlQuery += " ORDER BY " + ' << getNaturalSortName(entity) << ';';
    nextLine() << '}'
    nextLine();
    nextLine() << 'return getEntityManager().findMultiple( ' << className << '.class, jpqlQuery, parameters );';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes the find all method for the service. */
  private void writeFindAllMethod( Entity entity ) {
    String className = entity.javaName.implementationClass;
    String plural = getPlural( className );

    nextLine() << '/**';
    nextLine() << ' * Finds all instances of ' << entity.javaName.asDescription << '.';
    nextLine() << ' * @return a list of the entities found.';
    nextLine() << ' */';
    nextLine() << 'public List<' << className << '> findAll' << plural << '() {';
    nextLine() << indent() << 'return find' << plural << '( null, NO_PARAMETERS );';
    nextLine() << '}';
    nextLine();
  }

  /** Writes the natural sort order as a constant. */
  private void writeNaturalSortCriteria( Entity entity ) {
    String sortCriteria = getSortCriteria( entity );

    nextLine() << '/** The JPQL fragment representing the natural sort order for this entity. */';
    nextLine() << 'private static final String ' << getNaturalSortName(entity) << ' = "' << sortCriteria << '";';
    nextLine();
  }

  /** Writes the find reference values method for the service. */
  private void writeFindReferenceValuesMethod( Entity entity ) {
    String className = entity.javaName.implementationClass;
    String plural = getPlural( className );

    nextLine() << '/**';
    nextLine() << ' * Finds all instances of ' << entity.javaName.asDescription << '.';
    nextLine() << ' * @return A reference value map indexed by unique ID and name.';
    nextLine() << ' */';
    nextLine() << 'public IReferenceValueMap<' << className << '> find' << plural << '() {';
    ++indent;
    nextLine();
    nextLine() << 'List<' << className << '> objects = getEntityManager().findAll( ' << className << '.class );';
    nextLine();
    nextLine() << 'return this.' << getBuildReferenceValueMapName(entity) << '( objects );';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes the method to find objects related to a given object. */
  private void writeFindByRelationship( Relationship relationship ) {

    Entity entity = relationship.parent;
    Entity relatedEntity = relationship.relatedEntity;

    String className = entity.javaName.implementationClass;
    String plural = getPlural( className );

    String relationshipName = relationship.javaName.field;

    String relatedId = relatedEntity.javaName.uniqueId;
    if ( relatedEntity.baseClass != null ) {
      relatedId = relatedEntity.baseClass.javaName.uniqueId;
    }

    nextLine() << '/**';
    nextLine() << ' * Finds all ' << entity.javaName.asDescription << ' instances related to a given ' << relatedEntity.javaName.asDescription << '.';
    nextLine() << ' * @param ' << relatedId << ' the unique ID of the related ' << relatedEntity.javaName.asDescription << '.';
    nextLine() << ' * @return a list of the entities found.';
    nextLine() << ' */';
    nextLine() << 'public List<' << className << '> find' << plural << 'By' << relationship.javaName.implementationClass << '( Long ' << relatedId << ' ) {';
    nextLine();
    ++indent;
    nextLine() << 'HashMap<String, Object> parameters = new HashMap<>();';
    nextLine() << 'parameters.put( "' << relatedId << '", ' << relatedId << ' );';
    nextLine();
    if ( relatedEntity.isEnumerated() ) {
      nextLine() << 'return find' << plural << '( "x.' << relationship.javaName.field << 'Id = :' << relatedId << '", parameters );';
    }
    else {
      nextLine() << 'return find' << plural << '( "x.' << relationshipName << '.' << relatedId << ' = :' << relatedId << '", parameters );';
    }
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes the find one method for the service. */
  private void writeFindOneMethod( Entity entity ) {
    String className = entity.javaName.implementationClass;

    nextLine() << '/**';
    nextLine() << ' * Finds the ' << entity.javaName.asDescription << ' matching a given selection criteria';
    nextLine() << ' * @param jpqlSelectionCriteria The JPQL fragment for the selection criteria (where clause). This';
    nextLine() << ' *          fragment needs to use "x" as the base variable being queried.';
    nextLine() << ' * @param parameters The parameters to substitute into the query.';
    nextLine() << ' * @return the entity found or null if none exists.';
    nextLine() << ' */';
    nextLine() << 'public ' << className << ' find' << className << '(';
    nextLine() << '    String jpqlSelectionCriteria,';
    nextLine() << '    Map<String, Object> parameters ) {';
    ++indent;
    nextLine();
    nextLine() << 'String jpqlQuery = ' << getMakeQueryName(entity) << '( jpqlSelectionCriteria );';
    nextLine();
    nextLine() << 'return getEntityManager().findOne( ' << className << '.class, jpqlQuery, parameters );';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes the find one method for the service. */
  private void writeFindByIdMethod( Entity entity ) {
    String className = entity.javaName.implementationClass;

    String uniqueId = entity.javaName.uniqueId;
    if ( entity.baseClass != null ) {
      uniqueId = entity.baseClass.javaName.uniqueId;
    }

    nextLine() << '/**';
    nextLine() << ' * Finds the ' << entity.javaName.asDescription << ' with given unique ID.';
    nextLine() << ' * @param uniqueId The unique ID of the object to be retrieved from the database.';
    nextLine() << ' * @return the entity found or null if none exists.';
    nextLine() << ' */';
    nextLine() << 'public ' << className << ' find' << className << '( Long uniqueId ) {';
    ++indent;
    nextLine();
    nextLine() << 'HashMap<String, Object> parameters = new HashMap<>();';
    nextLine() << 'parameters.put( "uniqueId", uniqueId );';
    nextLine();
    nextLine() << 'return find' << className << '( "x.' << uniqueId << ' = :uniqueId", parameters );';
    --indent;
    nextLine() << '}';
    nextLine();
  }

  /** Writes a find by attribute method for the service. */
  private void writeFindByAttributeMethod( Attribute attribute ) {

    String attributeName = attribute.javaName.field;
    String attributeTypeName = attribute.dataType.javaName.asIdentifier;

    Entity entity = attribute.parent;

    String className = entity.javaName.implementationClass;

    nextLine() << '/**';
    nextLine() << ' * Finds the ' << entity.javaName.asDescription << ' with given ' << attribute.javaName.asDescription << '.';
    nextLine() << ' * @param ' << attributeName << ' The ' << attribute.javaName.asDescription << ' of the object to be retrieved from the database.';
    nextLine() << ' * @return the entity found or null if none exists.';
    nextLine() << ' */';
    nextLine() << 'public ' << className << ' find' << className << 'By' << attribute.javaName.asIdentifier << '( ' << attributeTypeName << ' ' << attributeName << ' ) {';
    ++indent;
    nextLine();
    nextLine() << 'HashMap<String, Object> parameters = new HashMap<>();';
    nextLine() << 'parameters.put( "' << attributeName << '", ' << attributeName << ' );';
    nextLine();
    nextLine() << 'return find' << className << '( "x.' << attributeName << ' = :' << attributeName << '", parameters );';
    --indent;
    nextLine() << '}';
    nextLine();
  }
}