
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaRootPackage
  extends JavaAbstractPackage {

  /**
   * Constructs a new Java package.
   * @param name
   * @param description
   */
  public JavaRootPackage() {
    super( null, "$", "(Top level Java package)" );
  }

  /** {@inheritDoc} */
  @Override
  public String getFullyQualifiedJavaName() {
    return "";
  }

  /** {@inheritDoc} */
  @Override
  public String getJavaName() {
    return "";
  }

  /**
   * @return The highest root package containing this model element.
   */
  @Override
  public JavaRootPackage getRootPackage() {
    return this;
  }

}
