
package gov.senate.transaact.domaingen.model;

/** Concrete date type for time stamps. */
public class TimeStampDataType
  extends DataType {

  public TimeStampDataType() {
    super( "Date", "TIMESTAMP", false, true );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    throw new UnsupportedOperationException( "TBD: Needs DateFormat, imports, etc." );
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    throw new UnsupportedOperationException( "TBD: Needs DateFormat, TO_DATE, etc." );
  }
}
