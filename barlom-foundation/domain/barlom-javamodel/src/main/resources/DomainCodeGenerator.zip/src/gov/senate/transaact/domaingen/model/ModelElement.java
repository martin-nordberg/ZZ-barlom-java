
package gov.senate.transaact.domaingen.model;

/**
 * Model Element is an abstract base class for all model elements in the code generation model.
 */
public abstract class ModelElement {

  /** Processes elements after the domain has been loaded */
  public void afterLoad() {
  }

  /** Returns the Java name of this element. */
  public JavaName getJavaName() {
    if ( this.javaName == null ) {
      this.javaName = new JavaName( this );
    }
    return this.javaName;
  }

  public String getName() {
    return this.name;
  }

  public abstract ModelElement getParent();

  /** Returns the SQL name of this element. */
  public SqlName getSqlName() {
    if ( this.sqlName == null ) {
      return this.sqlName = new SqlName( this.name );
    }
    return this.sqlName;
  }

  public void setName( String name ) {
    this.name = name;
  }

  /** Sets the SQL name of this element (to override the default). */
  public void setSqlName( String sqlName ) {
    assert this.sqlName == null : "A custom SQL name should be set only during model construction.";
    this.sqlName = new SqlName( sqlName );
  }

  /** Tests this model element and its children for self-consistency. */
  public abstract void validate();

  /** The Java name of this element. */
  private JavaName javaName;

  /** The name of this element. */
  private String name;

  /** The SQL name of this element. */
  private SqlName sqlName;
}
