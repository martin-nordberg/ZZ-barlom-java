
package gov.senate.transaact.domaingen.dbmodel;

import java.util.List;

/**
 * @author Vangent, Inc.
 */
public class DbUniquenessConstraint
  extends DbConstraint {

  /**
   * Constructs a new uniqueness constraint.
   */
  DbUniquenessConstraint(
      DbTable parent,
      String name,
      String description,
      List<DbTableColumn> uniqueColumns ) {
    super( parent, name, description, uniqueColumns );

    parent.onAddChild( this );
  }

  /** {@inheritDoc} */
  @Override
  public String getSqlName() {
    return DbNamedModelElement.makeSqlName( "UQ", this.getName() );
  }
}
