package gov.senate.transaact.domaingen
import gov.senate.transaact.domaingen.dbgen.DbModelGenerator
import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbSchema
import gov.senate.transaact.domaingen.dbwriters.*
import gov.senate.transaact.domaingen.javagen.JavaModelGenerator
import gov.senate.transaact.domaingen.javamodel.JavaRootPackage
import gov.senate.transaact.domaingen.model.Domain
import org.codehaus.groovy.control.CompilerConfiguration

class DomainCodeGenerator {

  /** Generates domain model code for TranSAAct. */
  static void main(String[] args) {

    def binding = new Binding();

    String rootFolder = "..\\..\\Code\\DomainModelLayer\\";

    def dbSchema = new DbSchema( "TRANSAACT", "TranSAAct application schema" );

    JavaRootPackage javaRootPackage = JavaModelGenerator.generateRootPackageAndJavaLibs();

    // Common Organization
    String sqlFolder = "..\\..\\DataModel\\Schemas\\CommonOrganization\\";
    String domainName = "Common Organization";
    binding.commonOrgDomain = loadDomain( rootFolder, domainName, binding );
    binding.commonOrgDomain.afterLoad();
    binding.commonOrgDomain.validate();
    generateJavaDomainModelCode( rootFolder, binding.commonOrgDomain );
    generateJavaQueriesCode( rootFolder, binding.commonOrgDomain );
    generateDataDictionary( sqlFolder, binding.commonOrgDomain );

    def dbCommonOrgDomain = DbModelGenerator.generateDomain( dbSchema, binding.commonOrgDomain );
    generateDbCode( sqlFolder, dbCommonOrgDomain );

    JavaModelGenerator.generateDomain( binding.commonOrgDomain, javaRootPackage );
    //TBD: in progress
    //new JavaWriter( rootFolder + "src-CommonOrganization" ).writeCode( javaRootPackage, "gov.senate.transaact.common" );

    // Assets
    sqlFolder = "..\\..\\DataModel\\Schemas\\Assets\\";
    domainName = "Assets";
    binding.assetsDomain = loadDomain( rootFolder, domainName, binding );
    binding.assetsDomain.afterLoad();
    binding.assetsDomain.validate();
    generateJavaDomainModelCode( rootFolder, binding.assetsDomain );
    generateJavaQueriesCode( rootFolder, binding.assetsDomain );
    generateDataDictionary( sqlFolder, binding.assetsDomain );

    def dbAssetsDomain = DbModelGenerator.generateDomain( dbSchema, binding.assetsDomain );
    generateDbCode( sqlFolder, dbAssetsDomain );

    JavaModelGenerator.generateDomain( binding.assetsDomain, javaRootPackage );

    // Authorizations
    sqlFolder = "..\\..\\DataModel\\Schemas\\Authorizations\\";
    domainName = "Authorizations";
    binding.authorizationsDomain = loadDomain( rootFolder, domainName, binding );
    binding.authorizationsDomain.afterLoad();
    binding.authorizationsDomain.validate();
    generateJavaDomainModelCode( rootFolder, binding.authorizationsDomain );
    generateJavaQueriesCode( rootFolder, binding.authorizationsDomain );
    generateDataDictionary( sqlFolder, binding.authorizationsDomain );

    def dbAuthorizationsDomain = DbModelGenerator.generateDomain( dbSchema, binding.authorizationsDomain );
    generateDbCode( sqlFolder, dbAuthorizationsDomain );

    JavaModelGenerator.generateDomain( binding.authorizationsDomain, javaRootPackage );

    // Billing
    sqlFolder = "..\\..\\DataModel\\Schemas\\Billing\\Generated\\";
    domainName = "Billing";
    binding.billingDomain = loadDomain( rootFolder, domainName, binding );
    binding.billingDomain.afterLoad();
    binding.billingDomain.validate();
    generateDataDictionary( sqlFolder, binding.billingDomain );

    def dbBillingDomain = DbModelGenerator.generateDomain( dbSchema, binding.billingDomain );
    generateDbCode( sqlFolder, dbBillingDomain );

    // External Applications
    sqlFolder = "..\\..\\DataModel\\Schemas\\ExternalApplications\\";
    domainName = "External Applications";
    binding.externalApplicationsDomain = loadDomain( rootFolder, domainName, binding );
    binding.externalApplicationsDomain.afterLoad();
    binding.externalApplicationsDomain.validate();
    generateJavaDomainModelCode( rootFolder, binding.externalApplicationsDomain );
    generateJavaQueriesCode( rootFolder, binding.externalApplicationsDomain );
    generateDataDictionary( sqlFolder, binding.externalApplicationsDomain );

    def dbExternalApplicationsDomain = DbModelGenerator.generateDomain( dbSchema, binding.externalApplicationsDomain );
    generateDbCode( sqlFolder, dbExternalApplicationsDomain );

    JavaModelGenerator.generateDomain( binding.externalApplicationsDomain, javaRootPackage );

    // Office Resources
    sqlFolder = "..\\..\\DataModel\\Schemas\\OfficeResources\\";
    domainName = "Office Resources";
    binding.officeResourcesDomain = loadDomain( rootFolder, domainName, binding );
    binding.officeResourcesDomain.afterLoad();
    binding.officeResourcesDomain.validate();
    generateJavaDomainModelCode( rootFolder, binding.officeResourcesDomain );
    generateJavaQueriesCode( rootFolder, binding.officeResourcesDomain );
    generateDataDictionary( sqlFolder, binding.officeResourcesDomain );

    def dbOfficeResourcesDomain = DbModelGenerator.generateDomain( dbSchema, binding.officeResourcesDomain );
    generateDbCode( sqlFolder, dbOfficeResourcesDomain );

    JavaModelGenerator.generateDomain( binding.officeResourcesDomain, javaRootPackage );

    // Service Requests
    sqlFolder = "..\\..\\DataModel\\Schemas\\ServiceRequests\\";
    domainName = "ServiceRequests";
    binding.serviceRequestsDomain = loadDomain( rootFolder, domainName, binding );
    binding.serviceRequestsDomain.afterLoad();
    binding.serviceRequestsDomain.validate();
    generateJavaDomainModelCode( rootFolder, binding.serviceRequestsDomain );
    generateJavaQueriesCode( rootFolder, binding.serviceRequestsDomain );
    generateDataDictionary( sqlFolder, binding.serviceRequestsDomain );

    def dbServiceRequestsDomain = DbModelGenerator.generateDomain( dbSchema, binding.serviceRequestsDomain );
    generateDbCode( sqlFolder, dbServiceRequestsDomain );

    JavaModelGenerator.generateDomain( binding.serviceRequestsDomain, javaRootPackage );

    // Whole System
    println 'Overall Schema'
    sqlFolder = "..\\..\\DataModel\\Schemas\\TranSAAct\\";
    generateDbSchemaCode( sqlFolder, dbCommonOrgDomain );

    generatePersistenceXmlForJunit( rootFolder,
        "transaact",
        [
          binding.commonOrgDomain,
          binding.assetsDomain,
          binding.authorizationsDomain,
          binding.externalApplicationsDomain,
          binding.officeResourcesDomain,
          binding.serviceRequestsDomain ]
        )

    rootFolder = "..\\..\\Build\\";
    generatePersistenceXmlForOc4j( rootFolder,
        "transaact",
        [
          binding.commonOrgDomain,
          binding.assetsDomain,
          binding.authorizationsDomain,
          binding.externalApplicationsDomain,
          binding.officeResourcesDomain,
          binding.serviceRequestsDomain ]
        )


    println 'Code Generation Complete.';
  }

  private static String srcFolder( String rootFolder, String domainName ) {
    return rootFolder + "src-" + domainName.replaceAll( " ", "" )
  }

  private static String testFolder( String rootFolder, String domainName ) {
    return rootFolder + "test-" + domainName.replaceAll( " ", "" )
  }

  /** Loads one domain and generates its code. */
  private static Domain loadDomain( String rootFolder, String domainName, Binding binding ) {

    def configuration = new CompilerConfiguration();
    configuration.setClasspath( rootFolder + "bin-groovy" );

    def shell = new GroovyShell( binding, configuration );

    File scriptFile = new File( srcFolder( rootFolder, domainName ) + "\\gov\\senate\\transaact\\" +
        domainName.toLowerCase().replaceAll( " ", "\\\\" ) +
        "\\datamodel\\" + domainName.replaceAll( " ", "" ) +
        "CodeGenerator.groovyScript"               );
    shell.evaluate( scriptFile );

    Domain domain = binding.domain;

    assert domain.name == domainName;

    return domain;
  }

  /** Generates the Java code for one domain. */
  private static void generateJavaDomainModelCode( String rootFolder, Domain domain ) {

    String srcRoot = srcFolder( rootFolder, domain.name ) + "\\gov\\senate\\transaact\\" + domain.javaName.asPackage.replaceAll("\\.","\\\\") + "\\";
    String testRoot = testFolder( rootFolder, domain.name ) + "\\gov\\senate\\transaact\\" + domain.javaName.asPackage.replaceAll("\\.","\\\\") + "\\";

    // Java implementation
    println '  Generating Java Classes ...'
    File outFolder = new File( srcRoot + "domainmodel" );

    def writer = new JavaImplementationWriter( sourceFolder: outFolder );
    writer.writeDomain( domain );

    // Java data model factory
    writer = new JavaDataModelFactoryWriter( sourceFolder: outFolder );
    writer.writeDomain( domain );

    // Java change implementation
    outFolder = new File( srcRoot + "domainmodel\\history" );

    writer = new JavaChangeImplementationWriter( sourceFolder: outFolder );
    writer.writeDomain( domain );

    // Java CRUD unit tests
    println '  Generating Java CRUD Unit Tests ...'
    outFolder = new File( testRoot + "domainmodel" );

    writer = new JavaCrudTestWriter( sourceFolder: outFolder );
    writer.writeDomain( domain );

  }

  /** Generates the Java basic service code for one domain. */
  private static void generateJavaQueriesCode( String rootFolder, Domain domain ) {

    String srcRoot = srcFolder( rootFolder, domain.name ) + "\\gov\\senate\\transaact\\" + domain.javaName.asPackage.replaceAll("\\.","\\\\") + "\\";
    String testRoot = testFolder( rootFolder, domain.name ) + "\\gov\\senate\\transaact\\" + domain.javaName.asPackage.replaceAll("\\.","\\\\") + "\\";

    // Java basic service
    println '  Generating Java Services ...'
    File outFolder = new File( srcRoot + "queries" );

    def writer = new JavaQueriesWriter( sourceFolder: outFolder );
    writer.writeDomain( domain );
  }

  /** Generates the unit test persistence.xml for unit testing. */
  private static void generatePersistenceXmlForJunit( String rootFolder,
      String jpaPersistenceUnit,
      List<Domain> domains ) {

    String filePath = rootFolder + "src\\META-INF\\persistence.xml";

    // Java basic service
    println '  Generating persistence.xml ...'
    File outFile = new File( filePath );
    FileRewriter fileWriter = new FileRewriter( outFile );

    def writer = new PersistenceXmlJunitWriter( output: fileWriter );
    writer.writeDomains( jpaPersistenceUnit, domains );
    writer.closeOutput();
  }

  /** Generates the unit test persistence.xml for the EAR file. */
  private static void generatePersistenceXmlForOc4j( String rootFolder,
      String jpaPersistenceUnit,
      List<Domain> domains ) {

    String filePath = rootFolder + "META-INF\\persistence.xml";

    // Java basic service
    println '  Generating EAR persistence.xml ...'
    File outFile = new File( filePath );
    FileRewriter fileWriter = new FileRewriter( outFile );

    def writer = new PersistenceXmlOc4jWriter( output: fileWriter );
    writer.writeDomains( jpaPersistenceUnit, domains );
    writer.closeOutput();
  }

  /** Generates the data dictionary for one domain. */
  private static void generateDataDictionary( String sqlFolder, Domain domain ) {

    println '  Generating Data Dictionary ...'

    String domainName = domain.name.replaceAll( " ", "" );

    // Data dictionary
    File outFile = new File( sqlFolder + domainName + ".csv" );
    FileRewriter fileWriter = new FileRewriter( outFile );

    def writer = new DataDictionaryWriter( output : fileWriter );
    writer.writeDomain( domain );
    writer.closeOutput();
  }

  /** Generates the database code for one domain. */
  private static void generateDbCode( String sqlFolder, DbDomain domain ) {

    println '  Generating SQL ...'

    String domainName = domain.name.replaceAll( " ", "" );

    // SQL Tables DDL
    File outFile = new File( sqlFolder + domainName + "Tables.sql" );
    FileRewriter fileWriter = new FileRewriter( outFile );

    def writer = new DbTablesDdlWriter( output : fileWriter );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL Table Drops DDL
    outFile = new File( sqlFolder + domainName + "TableDrops.sql" );
    fileWriter = new FileRewriter( outFile );

    writer = new DbTableDropsDdlWriter( output : fileWriter );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL sequence resets
    outFile = new File( sqlFolder + domainName + "SequenceResets.sql" );
    fileWriter = new FileRewriter( outFile );
    writer = new DbResetSequencesDdlWriter( output : fileWriter );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL Constraints DDL
    outFile = new File( sqlFolder + domainName + "Constraints.sql" );
    fileWriter = new FileRewriter( outFile );
    writer = new DbConstraintsDdlWriter( output : fileWriter );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL Behavior DDL
    outFile = new File( sqlFolder + domainName + "Behavior.sql" );
    fileWriter = new FileRewriter( outFile );
    writer = new DbBehaviorDdlWriter( output : fileWriter );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL DML for reference tables
    outFile = new File( sqlFolder + domainName + "RefValues.sql" );
    fileWriter = new FileRewriter( outFile );
    writer = new DbRecordsDmlWriter( output : fileWriter, writeUnitTestValues: false );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL DML for unit test records
    outFile = new File( sqlFolder + domainName + "TestValues.sql" );
    fileWriter = new FileRewriter( outFile );
    writer = new DbRecordsDmlWriter( output : fileWriter, writeUnitTestValues: true );
    writer.writeDomain( domain );
    writer.closeOutput();

  }

  /** Generates the database code for the whole schema. */
  private static void generateDbSchemaCode( String sqlFolder, DbDomain domain ) {

    println '  Generating SQL ...'

    // SQL Tables DDL
    File outFile = new File( sqlFolder + "ReplaceTranSAActSchema.sql" );
    FileRewriter fileWriter = new FileRewriter( outFile );

    def writer = new DbCreateSchemaWriter( output : fileWriter, password: 'senate2' );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL Tables DDL for DEV
    outFile = new File( sqlFolder + "ReplaceTranSAActSchemaDEV.sql" );
    fileWriter = new FileRewriter( outFile );

    writer = new DbCreateSchemaWriter( output : fileWriter, password: 'pass4Transaact' );
    writer.writeDomain( domain );
    writer.closeOutput();

    // SQL Tables DDL for TEST/PROD
    outFile = new File( sqlFolder + "ReplaceTranSAActSchemaTESTPROD.sql" );
    fileWriter = new FileRewriter( outFile );

    writer = new DbCreateSchemaWriter( output : fileWriter, password: 'pass4Transaact', useSharedLog: false );
    writer.writeDomain( domain );
    writer.closeOutput();
  }
}
