package gov.senate.transaact.domaingen.dbwriters;

import gov.senate.transaact.domaingen.dbmodel.DbDomain
import gov.senate.transaact.domaingen.dbmodel.DbTable
import gov.senate.transaact.domaingen.dbmodel.DbUniquenessConstraint
import gov.senate.transaact.domaingen.model.*

/**
 * @author Vangent, Inc.
 */
public class DbConstraintsDdlWriter
extends DbWriter {

  /** Writes a schema definition to the writer's output. */
  void writeDomain( DbDomain domain ) {

    boolean generateDrops = "Common Organization".equals( domain.name );

    String title = 'SCHEMA TABLES DEFINITION FOR ' + domain.sqlName;
    String purpose = 'Defines the ' + domain.sqlName + ' schema tables.'

    writeFileHeader( title, purpose, true );

    nextLine() << '------------------------------';
    nextLine() << '-- Create Table Constraints --';
    nextLine() << '------------------------------';
    nextLine();
    domain.tables.each { table ->
      createConstraints( table );
    }
    nextLine();

    writeFileFooter();
  }

  /** Creates the constraints for a table */
  private void createConstraints( DbTable table ) {
    nextLine() << 'BEGIN';
    ++indent;

    String tableName = table.sqlName;

    // optionality
    table.columns.each { column ->
      this.setColumnOptionality( tableName, column.sqlName, column.isNullable );
    }
    nextLine();

    // primary key
    setPrimaryKey( tableName, table.primaryKeyColumn.sqlName, table.primaryKeyConstraint.sqlName );
    nextLine();

    // foreign keys
    table.foreignKeyConstraints.each { constraint ->
      this.setForeignKey( tableName, constraint.constrainedColumns[0].sqlName, constraint.relatedTable.sqlName, constraint.sqlName, constraint.isCascadeDelete );
    }
    nextLine();

    // uniqueness
    table.uniquenessConstraints.each { constraint ->
      this.setUnique( tableName, constraint );
    }
    nextLine();

    --indent;
    nextLine() << 'END;';
    nextLine() << '/';
    nextLine();
  }

  /** Writes one line of column optionality. */
  private void setColumnOptionality( String tableName, String columnName, Boolean isNullable ) {
    nextLine() << "DATAMODEL.SET_COLUMN_OPTIONALITY( '" << tableName << "', '" << columnName << "', '";
    if ( !isNullable ) {
      sameLine() << "NOT ";
    }
    sameLine() << "NULL' );";
  }

  /** Writes one line of column optionality. */
  private void setForeignKey( String tableName, String columnName, String tableName2,  String keyName, Boolean cascadeDelete ) {
    String deleteText = cascadeDelete ? 'ON DELETE CASCADE' : ' ';
    nextLine() << "DATAMODEL.SET_FOREIGN_KEY( '" << tableName << "', '" << columnName <<
        "', '" << tableName2 << "', '" << keyName << "', '" << deleteText << "' );";
  }

  /** Writes one line of column optionality. */
  private void setPrimaryKey( String tableName, String columnName, String keyName ) {
    nextLine() << "DATAMODEL.SET_PRIMARY_KEY( '" << tableName << "', '" << columnName <<
        "', '" << keyName << "' );";
  }

  /** Writes one line of column optionality. */
  private void setUnique( String tableName, DbUniquenessConstraint constraint ) {
    nextLine() << "-- " << constraint.description;
    nextLine() << "DATAMODEL.SET_UNIQUE( '" << tableName << "', '";
    def delimiter = "";
    constraint.constrainedColumns.each { column ->
      sameLine() << delimiter << column.sqlName;
      delimiter = ", ";
    }
    sameLine() << "', '" << constraint.sqlName << "' );";
  }

}
