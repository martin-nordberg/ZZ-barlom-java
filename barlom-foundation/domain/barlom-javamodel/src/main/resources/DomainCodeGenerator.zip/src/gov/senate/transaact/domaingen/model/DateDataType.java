
package gov.senate.transaact.domaingen.model;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/** Concrete date type for dates. */
public class DateDataType
  extends DataType {

  public DateDataType() {
    super( "Date", "DATE", false, true );
  }

  /** Converts a given value of this type to Java. */
  @Override
  public String valueForJava( Object value ) {
    if ( value == null ) {
      return null;
    }
    return "new SimpleDateFormat( \"MM-dd-yyyy\" ).parse( \"" + this.dateMmDdYyyy( value )
        + "\" )";
  }

  /** Converts a given value of this type to SQL. */
  @Override
  public String valueForSql( Object value ) {
    if ( value == null ) {
      return null;
    }
    return "TO_DATE( '" + this.dateMmDdYyyy( value ) + "', 'MM-DD-YYYY' )";
  }

  private String dateMmDdYyyy( Object value ) {
    DateFormat dateFormat = new SimpleDateFormat( "MM-dd-yyyy" );
    return dateFormat.format( (Date) value );
  }
}
