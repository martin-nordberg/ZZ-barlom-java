package gov.senate.transaact.domaingen.javawriters

import gov.senate.transaact.domaingen.javamodel.*

/**
 * @author GDIT, Inc.
 */
class JavaWriter {

    JavaWriter( String sourcePath ) {
        this.sourcePath = sourcePath;
        this.classWriter = new JavaClassWriter( sourcePath );
        this.enumerationWriter = new JavaEnumerationWriter( sourcePath );
    }

    void writeCode( JavaRootPackage rootPackage, String packageName ) {
        this.writePackage( rootPackage.findOrCreatePackage( packageName ) );
    }

    private void writePackage( JavaAbstractPackage abstractPackage ) {
        if ( abstractPackage instanceof JavaPackage ) {
            for ( JavaClass clazz : ((JavaPackage)abstractPackage).classes ) {
                this.classWriter.writeClass( clazz );
            }
            for ( JavaEnumeration enumeration : ((JavaPackage)abstractPackage).enumerations ) {
                this.enumerationWriter.writeEnumeration( enumeration );
            }
        }

        for ( JavaPackage subPackage : abstractPackage.packages ) {
          this.writePackage( subPackage );
        }
    }

    private JavaClassWriter classWriter;

    private JavaEnumerationWriter enumerationWriter;

    private String sourcePath;

}
