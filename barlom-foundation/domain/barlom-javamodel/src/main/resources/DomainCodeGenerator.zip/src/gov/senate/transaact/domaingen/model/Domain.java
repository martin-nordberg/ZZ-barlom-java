
package gov.senate.transaact.domaingen.model;

import java.util.ArrayList;
import java.util.List;

/** A Java domain package or SQL schema. */
public class Domain
  extends ModelElement {

  /** Processes elements after the domain has been loaded */
  @Override
  public void afterLoad() {
    for ( Entity entity : this.entities ) {
      entity.afterLoad();
    }
  }

  /** Finds the entity in this domain with the given name. */
  public Entity findEntity( String name ) {
    for ( Entity entity : this.entities ) {
      if ( name.equals( entity.getJavaName().getAsIdentifier() ) ) {
        return entity;
      }
    }
    assert false : name;
    return null;
  }

  /** Returns the entities. */
  public List<Entity> getEntities() {
    return this.entities;
  }

  /** Returns the entitiesUsed. */
  public List<Entity> getEntitiesUsed() {
    return this.entitiesUsed;
  }

  /** Returns the hasSqlCustomizations. */
  public Boolean getHasSqlCustomizations() {
    return this.hasSqlCustomizations;
  }

  @Override
  public ModelElement getParent() {
    return null;
  }

  /** Returns the temporal entities within this domain. */
  public List<Entity> getTemporalEntities() {
    List<Entity> result = new ArrayList<>();
    for ( Entity entity : this.entities ) {
      if ( entity.isTemporal() ) {
        result.add( entity );
      }
    }
    return result;
  }

  /**
   * Sets the entities.
   * @param entities The new value for entities.
   */
  public void setEntities( List<Entity> entities ) {
    this.entities = entities;
  }

  /**
   * Sets the entitiesUsed.
   * @param entitiesUsed The new value for entitiesUsed.
   */
  public void setEntitiesUsed( List<Entity> entitiesUsed ) {
    this.entitiesUsed = entitiesUsed;
  }

  /**
   * Sets the hasSqlCustomizations.
   * @param hasSqlCustomizations The new value for hasSqlCustomizations.
   */
  public void setHasSqlCustomizations( Boolean hasSqlCustomizations ) {
    this.hasSqlCustomizations = hasSqlCustomizations;
  }

  /** Validates this domain. */
  @Override
  public void validate() {
    assert !this.getName().isEmpty() : "Domain has no name.";
    assert this.entities.size() > 0 : "Domain " + this.getName() + " has no entities.";

    for ( Entity entity : this.entities ) {
      entity.validate();
    }
  }

  /** The entities in this domain. */
  List<Entity> entities = new ArrayList<>();

  /** Entities from other domains referenced from this one. */
  List<Entity> entitiesUsed = new ArrayList<>();

  /** Whether the SQL schema definition needs to include a hand-written customizations script. */
  Boolean hasSqlCustomizations = false;
}
