
package gov.senate.transaact.domaingen.javamodel;

/**
 * @author GDIT, Inc.
 */
public class JavaAnnotationType
  extends JavaType {

  /**
   * Constructs a new type reference.
   * @param annotationInterface The referenced annotation interface defining this type
   */
  JavaAnnotationType( JavaAnnotationInterface annotationInterface ) {
    super();

    this.annotationInterface = annotationInterface;
  }

  /** {@inheritDoc} */
  @Override
  public String getFullyQualifiedJavaName() {
    return this.annotationInterface.getFullyQualifiedJavaName();
  }

  @Override
  public boolean getIsImplicitlyImported() {
    return this.annotationInterface.getParent().getIsImplicitlyImported();
  }

  /** {@inheritDoc} */
  @Override
  public String getJavaName() {
    return this.annotationInterface.getJavaName();
  }

  private JavaAnnotationInterface annotationInterface;

}
