
package gov.senate.transaact.domaingen.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * A single object instance or the corresponding database record for a constant value. Holds its
 * field values in a map structure.
 */
public class Instance
  extends TreeMap<String, Object> {

  /** Constructs a new instance with given attribute values. */
  public Instance( Map<String, Object> properties ) {

    // store all the attribute values
    this.putAll( properties );

    // initialize list of instances related to this one through many-to-many tables
    this.put( "relatedInstances", new ArrayList<>() );

    // set the default way of naming this instance if needed
    if ( properties.get( "nameAttributeName" ) == null ) {
      if ( properties.get( "javaName" ) != null ) {
        this.put( "nameAttributeName", "javaName" );
      }
      else {
        this.put( "nameAttributeName", "Name" );
      }
    }

    // set this instance to reference data by default
    if ( properties.get( "isUnitTestInstance" ) == null ) {
      this.put( "isUnitTestInstance", false );
    }
  }

  /** Returns the instance name as a Java name. */
  public JavaName getJavaName() {
    String nameAttributeName = (String) this.get( "nameAttributeName" );
    assert this.get( nameAttributeName ) != null : "No instance name: " + this.parent.getName()
        + "\n" + this;
    assert this.get( nameAttributeName ) instanceof String : "Non-string instance name: " + this.parent.getName()
        + "\n" + this;
    return new JavaName( (String) this.get( nameAttributeName ) );
  }

  /** Returns the parent of this instance. */
  public Entity getParent() {
    return this.parent;
  }

  /** Returns the reference constant prefix for this instance. */
  public String getReferencePrefix() {
    if ( this.get( "referencePrefix" ) != null ) {
      return (String) this.get( "referencePrefix" );
    }

    if ( this.get( "javaName" ) != null ) {
      return this.getJavaName().getReferencePrefix();
    }

    return null;
  }

  /**
   * @return
   */
  public List<RelatedInstance> getRelatedInstances() {
    return (List<RelatedInstance>) this.get( "relatedInstances" );
  }

  /** Validates this instance. */
  public void validate() {
    Boolean isUnitTestInstance = (Boolean) this.get( "isUnitTestInstance" );
    assert this.get( "UniqueId" ) != null || isUnitTestInstance : "Instance in "
        + this.parent.getName() + " has no unique ID.";

    if ( this.parent.isEnumerated() ) {
      assert this.get( "Name" ) != null : "Instance is missing name: " + this;
      assert ( (String) this.get( "Name" ) ).matches( "^[A-Za-z0-9_ ]+$" ) : "Invalid instance name: "
          + this;
    }

    for ( RelatedInstance relatedInstance : this.getRelatedInstances() ) {
      relatedInstance.validate();
    }
  }

  /** Processes elements after the domain has been loaded. */
  void afterLoad() {
    for ( RelatedInstance relatedInstance : this.getRelatedInstances() ) {
      relatedInstance.afterLoad();
    }
  }

  /**
   * Sets the parent entity of this instance (also adds the instance to the entity's list of
   * instances).
   */
  void setParent( Entity parent ) {
    assert this.parent == null : "Can not change the parent of an instance.";
    this.parent = parent;
    parent.getInstances().add( this );
  }

  /** Serialization version */
  private static final long serialVersionUID = 1L;

  /** The parent entity of which this is an instance. */
  private Entity parent;
}
