
package gov.senate.transaact.domaingen.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** A Java class and corresponding SQL table. */
public class Entity
  extends ModelElement {

  /** Adds a new instance of this entity. */
  public Entity addInstance( Map<String, Object> properties ) {
    new Instance( properties ).setParent( this );
    return this;
  }

  /** Processes elements after the domain has been loaded */
  @Override
  public void afterLoad() {
    for ( Attribute attribute : this.attributes ) {
      attribute.afterLoad();
    }

    for ( Relationship relationship : this.relationships ) {
      relationship.afterLoad();
    }

    for ( Instance instance : this.instances ) {
      instance.afterLoad();
    }
  }

  public List<Relationship> getAggregations() {
    return this.aggregations;
  }

  /** Returns the attributes of this class and its base class. */
  public List<Attribute> getAllAttributes() {
    List result = new ArrayList<>();
    result.addAll( this.attributes );
    if ( this.baseClass != null ) {
      result.addAll( this.baseClass.getAllAttributes() );
    }
    return result;
  }

  /** Returns the relationships of this class and its base class. */
  public List<Relationship> getAllRelationships() {
    List result = new ArrayList<>();
    result.addAll( this.relationships );
    if ( this.baseClass != null ) {
      result.addAll( this.baseClass.getAllRelationships() );
    }
    return result;
  }

  public List<Attribute> getAttributes() {
    return this.attributes;
  }

  public Entity getBaseClass() {
    return this.baseClass;
  }

  public List<Constraint> getConstraints() {
    return this.constraints;
  }

  public String getDescription() {
    return this.description;
  }

  public String getDiscriminator() {
    return this.discriminator;
  }

  public Boolean getHasReferenceValuesOnly() {
    return this.hasReferenceValuesOnly;
  }

  public Boolean getHasValidator() {
    return this.hasValidator;
  }

  public List<Instance> getInstances() {
    return this.instances;
  }

  public String getNaturalSort() {
    return this.naturalSort;
  }

  public Boolean getNeedsHandWrittenCrudTest() {
    return this.needsHandWrittenCrudTest;
  }

  public int getNextUniqueId() {
    return this.nextUniqueId;
  }

  @Override
  public Domain getParent() {
    return this.parent;
  }

  public List<Relationship> getRelationships() {
    return this.relationships;
  }

  /** Returns whether this is an abstract class. */
  public boolean isAbztract() {
    return this.isInheritanceRoot() || this.abztract;
  }

  /** Whether this entity can be cached by EclispeLink. */
  public boolean isCachedByJpa() {
    return this.isCachedByJpa || this.getHasReferenceValuesOnly();
  }

  /** Whether this entity is an enumeration. */
  public boolean isEnumerated() {
    return false;
  }

  /** Returns whether this is a root class for an inheritance hierarchy. */
  public boolean isInheritanceRoot() {
    return this.discriminator != null && !this.discriminator.isEmpty()
        && this.baseClass == null;
  }

  /** Whether this entity maintains a history of its changes over time. */
  public boolean isTemporal() {
    return false;
  }

  /** Returns whether this is an abstract class. */
  public void setAbztract( boolean abztract ) {
    this.abztract = abztract;
  }

  public void setAggregations( List<Relationship> aggregations ) {
    this.aggregations = aggregations;
  }

  public void setAttributes( List<Attribute> attributes ) {
    this.attributes = attributes;
  }

  public void setBaseClass( Entity baseClass ) {
    this.baseClass = baseClass;
  }

  public void setConstraints( List<Constraint> constraints ) {
    this.constraints = constraints;
  }

  public void setDescription( String description ) {
    this.description = description;
  }

  public void setDiscriminator( String discriminator ) {
    this.discriminator = discriminator;
  }

  public void setHasReferenceValuesOnly( Boolean hasReferenceValuesOnly ) {
    this.hasReferenceValuesOnly = hasReferenceValuesOnly;
  }

  public void setHasValidator( Boolean hasValidator ) {
    this.hasValidator = hasValidator;
  }

  public void setInstances( List<Instance> instances ) {
    this.instances = instances;
  }

  public void setIsCachedByJpa( Boolean cachedByJpa ) {
    this.isCachedByJpa = cachedByJpa;
  }

  public void setNaturalSort( String naturalSort ) {
    this.naturalSort = naturalSort;
  }

  public void setNeedsHandWrittenCrudTest( Boolean needsHandWrittenCrudTest ) {
    this.needsHandWrittenCrudTest = needsHandWrittenCrudTest;
  }

  public void setNextUniqueId( int nextUniqueId ) {
    this.nextUniqueId = nextUniqueId;
  }

  public void setRelationships( List<Relationship> relationships ) {
    this.relationships = relationships;
  }

  /** Validates this entity. */
  @Override
  public void validate() {
    String name = this.getName();

    assert name != null && !name.isEmpty() : "Entity has no name.";
    assert this.description != null && !this.description.isEmpty() : "Entity " + name
        + " has no description.";

    if ( this.abztract || this.baseClass != null ) {
      assert this.discriminator != null && !this.discriminator.isEmpty() : "Entity " + name
          + " needs an inheritance discriminator.";
    }

    if ( this.baseClass != null ) {
      assert !this.baseClass.isTemporal() : "Entity " + name
          + " must not have a temporal base class.";
    }

    if ( this.getHasReferenceValuesOnly() ) {
      assert !this.instances.isEmpty() : "Reference entity " + name + " has no instances.";
      for ( Relationship relationship : this.relationships ) {
        assert relationship.getRelatedEntity().getHasReferenceValuesOnly() : "Reference entity "
            + name
            + " can not reference non-reference entity "
            + relationship.getRelatedEntity().getName();
      }
    }

    assert this.naturalSort != null && !this.naturalSort.isEmpty() : "Entity " + name
        + " needs a natural sort criteria.";

    for ( Attribute attribute : this.attributes ) {
      attribute.validate();
    }

    for ( Relationship relationship : this.relationships ) {
      relationship.validate();
    }

    for ( Constraint constraint : this.constraints ) {
      constraint.validate();
    }

    for ( Instance instance : this.instances ) {
      instance.validate();
    }
  }

  /** Returns a unique ID available to be assigned to child instances of this entity */
  int getNewUniqueId() {
    return this.nextUniqueId++;
  }

  /**
   * Sets the parent domain of this entity (also adds this entity to the domain's list of entities).
   */
  void setParent( Domain parent ) {
    assert this.parent == null : "Can not change the parent of an entity";
    this.parent = parent;
    parent.getEntities().add( this );
  }

  private boolean abztract = false;

  /** The aggregated relationships of this entity. */
  private List<Relationship> aggregations = new ArrayList<>();

  /** The attributes of this entity. */
  private List<Attribute> attributes = new ArrayList<>();

  /** The base class of this entity. */
  private Entity baseClass;

  /** The constraints of this entity. */
  private List<Constraint> constraints = new ArrayList<>();

  /** A short description of this entity. */
  private String description;

  /** A flag for the type of this entity for use in an inheritance hierarchy across joined tables. */
  private String discriminator;

  /** Whether this class has only pre-defined reference values. */
  private boolean hasReferenceValuesOnly = false;

  /** Whether this class has a custom validator. */
  private boolean hasValidator = false;

  /** The enumerated instances of this entity. */
  private List<Instance> instances = new ArrayList<>();

  /** Whether this class' instances are cacheable by EclipseLink. */
  private boolean isCachedByJpa = false;

  /** A comma-separated list of the attributes to sort by, by default. */
  private String naturalSort = "uniqueId";

  /** Whether this class requires its CRUD test to be hand-written. */
  private boolean needsHandWrittenCrudTest = false;

  /** The next UniqueID to be assigned. */
  private int nextUniqueId = 1000;

  /** The parent domain (Java package or SQL schema) for this entity. */
  private Domain parent;

  /** The relationships of this entity. */
  private List<Relationship> relationships = new ArrayList<>();
}
