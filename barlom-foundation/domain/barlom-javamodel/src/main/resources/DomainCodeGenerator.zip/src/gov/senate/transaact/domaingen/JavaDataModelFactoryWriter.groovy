
package gov.senate.transaact.domaingen;

import gov.senate.transaact.domaingen.model.*

class JavaDataModelFactoryWriter
extends JavaCodeWriter {

  /** Writes the code for the entities in the domain and for the domain as a whole */
  void writeDomain( Domain domain ) {
    File srcFile = new File( sourceFolder, domain.javaName.dataModelFactoryClass + ".java" )
    setOutput( new FileRewriter( srcFile ) );

    writeDataModelFactory( domain );

    closeOutput();
  }

  private void writeDataModelFactory( Domain domain ) {

    String pkgPath = domain.javaName.implementationPackage.replaceAll( "\\.", "/" );

    nextLine() << 'package ' << domain.javaName.implementationPackage << ';';
    nextLine();
    nextLine() << 'import java.util.ResourceBundle;';
    nextLine();
    nextLine() << '/**';
    nextLine() << ' * The concrete data model factory for the ' << domain.javaName.asDescription << ' domain.';
    nextLine() << ' * @author Vangent, Inc. (NOTE: SCRIPT-GENERATED CODE; DO NOT HAND EDIT)';
    nextLine() << ' */';
    nextLine() << 'public final class ' << domain.javaName.dataModelFactoryClass << ' {';
    ++indent;
    nextLine();
    nextLine() << '/** @return the custom queries for the ' << domain.javaName.asDescription << ' domain. */';
    nextLine() << 'public static ResourceBundle getQueriesBundle() {';
    nextLine() << indent() << 'return ResourceBundle.getBundle( "' << pkgPath << '/SqlQueries" );';
    nextLine() << '}';
    nextLine();
    --indent;
    nextLine() << '}';
    nextLine();

  }

}
