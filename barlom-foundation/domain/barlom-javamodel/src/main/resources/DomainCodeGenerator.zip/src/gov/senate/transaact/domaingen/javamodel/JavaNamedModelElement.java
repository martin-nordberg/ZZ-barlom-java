
package gov.senate.transaact.domaingen.javamodel;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GDIT, Inc.
 */
public abstract class JavaNamedModelElement
  extends JavaModelElement
  implements Comparable<JavaNamedModelElement> {

  /**
   * Constructs a new named model element.
   * @param parent The parent of the element.
   * @param name The name of the element.
   * @param description A description of the element
   */
  protected JavaNamedModelElement( JavaNamedModelElement parent, String name, String description ) {
    super( parent, description );

    assert name != null && name.length() > 0;

    this.name = name;

    this.children = new ArrayList<JavaModelElement>();
  }

  /** @return A Java name from the given model element name. */
  static String makeJavaName( String name ) {
    return name.replaceAll( " ", "" );
  }

  @Override
  public int compareTo( JavaNamedModelElement that ) {
    return this.getJavaName().compareTo( that.getJavaName() );
  }

  /** @return the children of this model element. */
  public List<JavaModelElement> getChildren() {
    return this.children;
  }

  /** @return the name of this element for Java code purposes. */
  public String getJavaName() {
    return JavaNamedModelElement.makeJavaName( this.name );
  }

  /** @return the name. */
  public String getName() {
    return this.name;
  }

  /** Responds to the event of adding a child to this model element. */
  void onAddChild( JavaModelElement child ) {
    this.children.add( child );
  }

  private List<JavaModelElement> children;

  private String name;

}
